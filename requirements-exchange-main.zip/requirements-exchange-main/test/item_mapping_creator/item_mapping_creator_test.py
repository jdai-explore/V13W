"""
This module provides test for ItemMappingCreator
"""
import unittest
import shutil
import os
from pathlib import Path
import pandas as pd
from src.mapping.item_mapping_creator import ItemMappingCreator


class TestItemMappingCreator(unittest.TestCase):
    """
    Class for testing the ItemMappingCreator
    """

    def __get_test_config_path(self, test_name: str) -> Path:
        """
        Returns config path for given test

        :param test_name: name of test
        :type test_name: str
        :return: path to configs for given test
        :type Path
        """
        return self._test_data_base_path / ('test_' + str(test_name)) / 'configs'

    def __get_test_data_path(self, test_name: str) -> Path:
        """
        Returns data path for given test

        :param test_name: name of test
        :type test_name: str
        :return: path to data for given test
        :type Path
        """
        return self._test_data_base_path / ('test_' + str(test_name)) / 'data'

    def __get_test_output_path(self, test_name: str) -> Path:
        """
        Returns output path for given test

        :param test_name: name of test
        :type test_name: str
        :return: path to output for given test
        :type Path
        """
        return self._test_data_base_path / ('test_' + str(test_name)) / 'output'

    def __clean_output_path(self, test_name: str):
        """
        Removes all outputs created for specified tests

        :param test_name: name of test
        :type test_name: str
        """
        # remove output folder
        shutil.rmtree(self.__get_test_output_path(test_name=test_name))
        # create the folder
        os.makedirs(self.__get_test_output_path(test_name=test_name),
                    exist_ok=True)

    def __get_row_count(self, worksheet) -> int:
        """
        Returns number of filled rows in a openpyxl worksheet

        :param worksheet: name of test
        :type worksheet: str
        """
        return 1

    def setUp(self):
        """
        Initialize any variables or resources needed for the tests.
        """
        self._cb_instance = 'Prod'
        self._test_data_base_path = Path(
            './test/test_data/item_mapping_creator')

    def test_create_item_mapping(self):
        """
        This test case tests the creation of items mapping
        """
        test_name = 'CREATE_ITEM_MAPPING'

        # initialize codebeamer exporter
        item_mapping_creator = ItemMappingCreator(cb_server=self._cb_instance,
                                                  tracker_mapping=self.__get_test_config_path(
                                                      test_name=test_name) / 'test.json',
                                                  field_mapping='config/change_log/sv62_to_ch63_field_mapping.json',
                                                  output_dir=self.__get_test_output_path(
                                                      test_name=test_name),
                                                  baseline_instance1='141509108',
                                                  baseline_instance2='143333714',
                                                  )

        # create item mappings
        output_dir = item_mapping_creator.create_item_mappings()

        # check amount of results/reports
        self.assertEqual(3, len(os.listdir(output_dir)))

        # load worksheets for 01 BT-LAH
        report = 'CH63-01_SV62-01_Foreign ID_DOORS_pe.xlsx'
        cnt_empty_ch63_01 = 0
        cnt_empty_sv63_01 = 74
        cnt_non_empty_no_mapping_ch63_01 = 0
        cnt_non_empty_no_mapping_sv62_01 = 1
        cnt_mapping_01 = 2976

        ws_empty_ch63 = pd.read_excel(output_dir / report,
                                      sheet_name='EMPTY_CH63')
        ws_empty_sv62 = pd.read_excel(output_dir / report,
                                      sheet_name='EMPTY_SV62')
        ws_non_empty_no_mapping_ch63 = pd.read_excel(output_dir / report,
                                                     sheet_name='NON_EMPTY_NO_MAPPING_CH63')
        ws_non_empty_no_mapping_sv62 = pd.read_excel(output_dir / report,
                                                     sheet_name='NON_EMPTY_NO_MAPPING_SV62')
        ws_mapping = pd.read_excel(output_dir / report,
                                   sheet_name='MAPPING_CH63_SV62')

        # check data
        self.assertEqual(ws_empty_ch63.shape[0],
                         cnt_empty_ch63_01)
        self.assertEqual(ws_empty_sv62.shape[0],
                         cnt_empty_sv63_01)
        self.assertEqual(ws_non_empty_no_mapping_ch63.shape[0],
                         cnt_non_empty_no_mapping_ch63_01)
        self.assertEqual(ws_non_empty_no_mapping_sv62.shape[0],
                         cnt_non_empty_no_mapping_sv62_01)
        self.assertEqual(ws_mapping.shape[0],
                         cnt_mapping_01)

        # load worksheets for 02 BT-LAH
        report = 'CH63-02_SV62-02_Foreign ID_DOORS_pe.xlsx'
        cnt_empty_ch63_02 = 2
        cnt_empty_sv63_02 = 17
        cnt_non_empty_no_mapping_ch63_02 = 243
        cnt_non_empty_no_mapping_sv62_02 = 358
        cnt_mapping_02 = 2057

        ws_empty_ch63 = pd.read_excel(output_dir / report,
                                      sheet_name='EMPTY_CH63')
        ws_empty_sv62 = pd.read_excel(output_dir / report,
                                      sheet_name='EMPTY_SV62')
        ws_non_empty_no_mapping_ch63 = pd.read_excel(output_dir / report,
                                                     sheet_name='NON_EMPTY_NO_MAPPING_CH63')
        ws_non_empty_no_mapping_sv62 = pd.read_excel(output_dir / report,
                                                     sheet_name='NON_EMPTY_NO_MAPPING_SV62')
        ws_mapping = pd.read_excel(output_dir / report,
                                   sheet_name='MAPPING_CH63_SV62')

        # check data
        self.assertEqual(ws_empty_ch63.shape[0],
                         cnt_empty_ch63_02)
        self.assertEqual(ws_empty_sv62.shape[0],
                         cnt_empty_sv63_02)
        self.assertEqual(ws_non_empty_no_mapping_ch63.shape[0],
                         cnt_non_empty_no_mapping_ch63_02)
        self.assertEqual(ws_non_empty_no_mapping_sv62.shape[0],
                         cnt_non_empty_no_mapping_sv62_02)
        self.assertEqual(ws_mapping.shape[0],
                         cnt_mapping_02)

        # load over all worksheets
        report = 'Overall_CH63-XX_SV62-XX_Foreign ID_DOORS_pe.xlsx'
        ws_empty_ch63 = pd.read_excel(output_dir / report,
                                      sheet_name='EMPTY_CH63')
        ws_empty_sv62 = pd.read_excel(output_dir / report,
                                      sheet_name='EMPTY_SV62')
        ws_non_empty_no_mapping_ch63 = pd.read_excel(output_dir / report,
                                                     sheet_name='NON_EMPTY_NO_MAPPING_CH63')
        ws_non_empty_no_mapping_sv62 = pd.read_excel(output_dir / report,
                                                     sheet_name='NON_EMPTY_NO_MAPPING_SV62')
        ws_mapping = pd.read_excel(output_dir / report,
                                   sheet_name='MAPPING_CH63_SV62')

        # check data
        self.assertEqual(ws_empty_ch63.shape[0],
                         cnt_empty_ch63_01 + cnt_empty_ch63_02)
        self.assertEqual(ws_empty_sv62.shape[0],
                         cnt_empty_sv63_01 + cnt_empty_sv63_02)
        self.assertEqual(ws_non_empty_no_mapping_ch63.shape[0],
                         cnt_non_empty_no_mapping_ch63_01 + cnt_non_empty_no_mapping_ch63_02)
        self.assertEqual(ws_non_empty_no_mapping_sv62.shape[0],
                         cnt_non_empty_no_mapping_sv62_01 + cnt_non_empty_no_mapping_sv62_02)
        self.assertEqual(ws_mapping.shape[0],
                         cnt_mapping_01 + cnt_mapping_02)

        # clean up test artifacts
        self.__clean_output_path(test_name=test_name)


if __name__ == '__main__':
    unittest.main()
