﻿# Test Cases:
## 1. Decide on New Items


>### Test Case 1.1 - "Warning - Mandatory fields not filled - CCB Participants":
>#### Test Steps:
>1. Upload test\test_data\ccb_gui\input_file\Test-AutoModifieditems.xlsx
>2. Select “CCB Participants” in "Participants" section
>3. Select “New Items” tab
>4. Press "Record CCB Decision" button
>#### Expected Results:
>- GUI:
>    - Following errors occur:
>        1. "ERROR: Please update the CCB Decision-Making Body field."
>        2. "ERROR: Please select at least one Module Variant_pe."
>        3. "ERROR: Please provide destination reference.")
>- Output File:
>    - No change

>### Test Case 1.2 - "Warning - Mandatory fields not filled - Audi Participants":
>#### Test Steps:
>1. Upload test\test_data\ccb_gui\input_file\Test-AutoModifieditems.xlsx
>2. Select Audi Participants” in "Participants" section
>3. Select “New Items” tab
>4. Press "Record CCB Decision" button
>#### Expected Results:
>- GUI:
>    - Following errors occur:
>        1. "ERROR: Please update the Audi Participant field."
>        2. "ERROR: Please select at least one Module Variant_pe."
>        3. "ERROR: Please provide destination reference."
>- Output File:
>    - No change

>### Test Case 1.3 - "Successfull Decision Recorded - CCB Participants":
>#### Test Steps:
>1. Upload test\test_data\ccb_gui\input_file\Test-AutoModifieditems.xlsx
>1. Select “CCB Participants” in "Participants" section
>1. Fill “CCB Decision-Making Body” in "Participants" section with "Test Decision Body"
>1. Select “New Items” tab
>1. Fill field "Module Variant_pe (MANDATORY)" with "None"
>1. Fill field "Type" in section "Destination" with "Parent"
>1. Fill field "Reference Item ID (MANDATORY)" in section "Destination" with "123456"
>1. Fill field "Comment / Reason" with "Test Comment"
>1. Press "Record CCB Decision" button
>#### Expected Results:
>- GUI:
>    - Following Information occur:
>        1. "CCB Decision recorded successfully."
>- Output File:
>   - If this was the first decision, a new output file will be created e.g. [timestamp]-AutoCCBDecisions_Test-AutoModifieditems.xlsx
>   - A new line in [timestamp]-AutoCCBDecisions_Test-AutoModifieditems.xlsx will be added:
>       | CCB Decision | CCB Participants | CCB Rational| Item Data ... |
>       |------|------|------|------|
>       |module_variant=None;destination_type=Parent;destination_reference=123456|CCB Decision-Making Body: Test Decision Body|Test Comment|...|

>### Test Case 1.4 - "Successfull Decision Recorded - Audi Participants":
>#### Test Steps:
>1. Upload test\test_data\ccb_gui\input_file\Test-AutoModifieditems.xlsx
>1. Select “Audi Participant” in "Participants" section
>1. Fill “Audi Participant” in "Participants" section with "Test Participant"
>1. Select “New Items” tab
>1. Fill field "Module Variant_pe (MANDATORY)" with "None"
>1. Fill field "Type" in section "Destination" with "Parent"
>1. Fill field "Reference Item ID (MANDATORY)" in section "Destination" with "123456"
>1. Fill field "Comment / Reason" with "Test Comment"
>1. Press "Record CCB Decision" button
>#### Expected Results:
>- GUI:
>    - Following Information occur:
>        1. "CCB Decision recorded successfully."
>- Output File:
>   - If this was the first decision, a new output file will be created e.g. [timestamp]-AutoCCBDecisions_Test-AutoModifieditems.xlsx
>   - A new line in [timestamp]-AutoCCBDecisions_Test-AutoModifieditems.xlsx will be added:
>       | CCB Decision | CCB Participants | CCB Rational| Item Data ... |
>       |------|------|------|------|
>       |module_variant=None;destination_type=Parent;destination_reference=123456
|Audi Participant: Test Participant|Test Comment|...|


>### Test Case 1.5 - "Empty New Items":
>#### Test Steps:
>1. Upload test\test_data\ccb_gui\input_file\Test-AutoModifieditems_Empty.xlsx
>1. Select “New Items” tab
>#### Expected Results:
>- GUI:
>    - Following Information occur:
>        1. "There are no new items in prodivded input file"
>- Output File:
>   - No changes

>### Test Case 1.6 - "Button - Next Item":
>#### Test Steps:
>1. Upload test\test_data\ccb_gui\input_file\Test-AutoModifieditems.xlsx
>1. Select “New Items” tab
>1. Press “Next Item” button
>#### Expected Results:
>- GUI:
>   - The ID will change to next item (ID: 24341740) and data of next item will be shown
>- Output File:
>   - No changes

>### Test Case 1.7 - "Button - Next Tracker":
>#### Test Steps:
>1. Upload test\test_data\ccb_gui\input_file\Test-AutoModifieditems.xlsx
>1. Select “New Items” tab
>1. Press “Next Tracker button
>#### Expected Results:
>- GUI:
>   - The Tracker will change to next tracker name (12_SV62-SECU_IDC...)
>   - The ID will change to first item (29674244) and data will be updated
>- Output File:
>   - No changes