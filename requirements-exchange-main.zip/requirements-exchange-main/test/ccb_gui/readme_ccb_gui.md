# How to create and open executable file


## Steps to record a CCB decision:
1. Double-click on CCB_GUI.exe. (https://jfrog.hub.vwgroup.com/artifactory/checu-reqex-generic-internal/ccb_gui/CCB_GUI.zip)
2. It will redirect to the browser. Once the page opens, upload the output file from , as this output file is the input file for app.exe. (https://jfrog.hub.vwgroup.com/artifactory/checu-reqex-generic-internal/change_log/)
3. Click on the 'Browse files' option and upload the file.
4. Click on the New Items tab.
5. It will load the new items, attributes, and values.
6. Choose the Tracker Name and Item ID you want to update the decision for.
7. Use the 'Next Item' and 'Next Tracker' buttons of Tracker Name and ID or the drop down menue to navigate through the Tracker Name and Item ID.
8. Update fields marked as mandatory
9. Click on the 'Record CCB Decision' button. The CCB decision will be recorded in an .xlsx file created in the current working directory.


## Steps to create the app.exe:
Based on script: https://git.hub.vwgroup.com/CH-ECU/requirements-exchange/blob/main/src/ccb_gui/app.py

0. Install dependencies (requirement.txt, streamlit, pyinstaller)
0. Open terminal
0. Change directory to src/ccb_gui
0. Build the executable with following command:
	```python -m PyInstaller --onefile --add-data "app.py;." --collect-all streamlit launch_app.py --name CCB_GUI```
0. The executable will be placed as *CCB_GUI.exe* in folder *dist*