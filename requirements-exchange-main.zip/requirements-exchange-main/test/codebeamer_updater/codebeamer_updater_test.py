"""
This module provides test for DecisionExecutor
"""
import unittest
import shutil
import os
import calmpy
import re
import json
from openpyxl import load_workbook
import calmpy.exceptions
from typing import Dict
import pandas as pd
from pathlib import Path
from datetime import datetime
from src.helper.codebeamer_updater import CodebeamerUpdater


class TestCodebeamerUpdater(unittest.TestCase):
    """
    Class for testing the CodebeamerUpdater
    """

    def __get_test_config_path(self, test_name: str) -> Path:
        """
        Returns config path for given test

        :param test_name: name of test
        :type test_name: str
        :return: path to configs for given test
        :type Path
        """
        return self._test_data_base_path / ('test_' + str(test_name)) / 'configs'

    def __get_test_data_path(self, test_name: str) -> Path:
        """
        Returns data path for given test

        :param test_name: name of test
        :type test_name: str
        :return: path to data for given test
        :type Path
        """
        return self._test_data_base_path / ('test_' + str(test_name)) / 'data'

    def __get_test_output_path(self, test_name: str) -> Path:
        """
        Returns output path for given test

        :param test_name: name of test
        :type test_name: str
        :return: path to output for given test
        :type Path
        """
        return self._test_data_base_path / ('test_' + str(test_name)) / 'output'

    def __clean_output_path(self, test_name: str):
        """
        Removes all outputs created for specified tests

        :param test_name: name of test
        :type test_name: str
        """
        # remove output folder
        shutil.rmtree(self.__get_test_output_path(test_name=test_name))
        # create the folder
        os.makedirs(self.__get_test_output_path(test_name=test_name),
                    exist_ok=True)

    def __update_parent(self, parent_id: int, item_id: int) -> bool:
        """
        Updates parent item that specified id is child

        :param parent_id: id of item to insert child to
        :type parent_id: str
        :param item_id: child to add
        :type item_id: str
        :return: status of execution (True if success, else False)
        :type bool
        """
        # url of children for parent
        children_url = f'{self._cb_server.query.SWAGGER_URL_V3}/items/' + \
            f'{int(parent_id)}/children'

        # get all current item children
        response = self._cb_server.session.make_paged_requests(request_url=children_url,
                                                               request_type='GET',
                                                               is_readonly_operation=True,
                                                               entries=500)

        # check if its more than 1 page
        if response.total > 1:
            print(f'parent {parent_id} has more than 500 children.' +
                  f' Hierarchy of item {item_id} will be ignored')
            return False

        # extract children list
        parent_child_refs = response.all[0].content['itemRefs']

        # convert to list of children ids
        existing_children_ids = [children['id']
                                 for children in parent_child_refs]

        # check if item is already a child
        if item_id not in existing_children_ids:
            # insert child
            parent_child_refs.append(
                {'id': int(item_id), 'type': 'TrackerItemReference'})

            # transform to query data
            children_data = {'children': parent_child_refs}

            # update hierarchy
            try:
                response = self._cb_server.session.make_single_request(request_url=children_url,
                                                                       request_type='PUT',
                                                                       data=children_data)
            except ...:
                return False
            return True
        return True

    def __load_xlsx(self, data_file_path: Path, sheet_name: str = None) -> pd.DataFrame:
        """
        Loads xlsx file and returns pandas Dataframe

        :param data_file_path: Path of xlsx file
        :type data_file_path: Path
        :return: xlsx data
        :type data_file_path: pd.DataFrame
        """
        if data_file_path.suffix == ".xlsx":
            return pd.read_excel(data_file_path) if sheet_name is None else pd.read_excel(data_file_path, sheet_name=sheet_name)
        else:
            print('Requested requirement input format not accepted!')
            return None

    def __insert_item_for_parent(self, parent_id: int, item_dict: dict) -> calmpy.Item:
        """
        Creates item with provided data for a specified parent id

        :param parent_id: id of item to insert child to
        :type parent_id: str
        :param item_dict: data of item to add
        :type item_dict: dict
        :return: item that got added
        :type calmpy.Item
        """
        parent = self._cb_server.get_item(parent_id)

        try:
            new_item = self._cb_server.get_tracker(
                int(parent.tracker.id)).create_item(fields=item_dict)
        except calmpy.exceptions.ServerError as e:
            print(e)
            print(f'Problem in creating item for parent {
                  parent_id} with data: {item_dict}')

        status = self.__update_parent(parent_id=parent_id, item_id=new_item.id)

        return new_item if status else None

    def __get_test_parent_id(self) -> calmpy.Item:
        """
        Returns test parent (item in codebeamer where data will get added), if it does not exists it will create it

        :return: test parent item in codebeamer
        :type calmpy.Item
        """
        test_parent_id = next((item for item in self._cb_server.get_tracker(self._test_tracker_id).get_items()
                               if item.name == 'FOR INTERNAL TESTS ONLY - SHALL BE DELETED' and item['Type'] == 'Folder'), None)
        # check if test parent item exists
        if test_parent_id is None:
            # create test parent item
            test_parent_id = self._cb_server.get_tracker(self._test_tracker_id).create_item(fields={'Summary': 'FOR INTERNAL TESTS ONLY - SHALL BE DELETED',
                                                                                                    'Type': 'Folder'})
        return test_parent_id

    def __get_last_idx_valid_row(self, worksheet, col_idx: int) -> int:
        """
        Returns number of non empty

        :param worksheet: worksheet
        :type worksheet: worksheet
        :param col_idx: index of column to detect last valid row idx for
        :type col_idx: int
        :return: last valid row index
        :type int
        """
        last_non_empty_row = 0
        for row in range(1, worksheet.max_row + 1):  # +1 because ws.max_row is inclusive
            print(worksheet.cell(row=row, column=col_idx).value)
            if worksheet.cell(row=row, column=col_idx).value is not None:
                last_non_empty_row = row
        return last_non_empty_row

    def setUp(self):
        """
        Initialize any variables or resources needed for the tests.
        """
        self._cb_instance = 'QS'
        self._cb_server = calmpy.Server(url=self._cb_instance, readonly=False)
        self._test_data_base_path = Path('./test/test_data/codebeamer_updater')
        self._test_tracker_id = 92348129
        self._test_parent_item = self.__get_test_parent_id()
        self._test_execution_data = datetime.today().strftime('%Y-%m-%d %H:%M')

    def test_ADD(self):
        """
        This test case tests the update "ADD"
        """
        test_name = 'ADD'

        # create output folder if it does not exist yet
        if not self.__get_test_output_path(test_name=test_name).exists():
            self.__get_test_output_path(test_name=test_name).mkdir(
                parents=True, exist_ok=True)

        # prepare paths
        test_data_modification = self.__get_test_data_path(
            test_name=test_name) / 'Requirement_Modification_Template.xlsx'

        test_data_modification_updated = self.__get_test_output_path(
            test_name=test_name) / f'Requirement_Modification_Template_{test_name}.xlsx'

        # prepare minimal data for items
        item_dict = {
            'Module Variant_pe': ['SV62-1Box', 'SV62-2Box', 'CH63_Main', 'CH63_Fallback'],
            'Safety Relevance according to ASIL_ct': 'No',
            'Security Relevance_ct': 'no',
            'Relevance for Author_ct': 'To edit by Author',
            'BsM-O_ct': 'Not rated'
        }

        # prepare test run folder
        test_run_parent_item = self.__insert_item_for_parent(parent_id=self._test_parent_item.id,
                                                             item_dict=dict(item_dict, **{'Type': 'Folder',
                                                                                          'Summary': f'Test - CodebeamerUpdater - {test_name} - {self._test_execution_data}'}))
        # prepare test run input data
        wb = load_workbook(test_data_modification)
        ws_add = wb['ADD_ITEM']

        # update add sheet
        added_items = []
        max_row_idx = self.__get_last_idx_valid_row(worksheet=ws_add,
                                                    col_idx=CodebeamerUpdater.ADD_TYPE_IDX+1) + 1
        for row_idx in range(2, max_row_idx):
            # add an item that will work as parent
            parent_item = self.__insert_item_for_parent(parent_id=test_run_parent_item.id,
                                                        item_dict=dict(item_dict,
                                                                       **{'Type': 'Folder',
                                                                          'Summary': f'Parent for test "{test_name} - row {row_idx}" - {self._test_execution_data}'}))
            child_item = self.__insert_item_for_parent(parent_id=parent_item.id,
                                                       item_dict=dict(item_dict,
                                                                      **{'Type': 'Folder',
                                                                                 'Summary': f'Child for test "{test_name}" - {self._test_execution_data}'}))
            added_items.append({'row_idx': row_idx,
                                'Type':  ws_add.cell(row=row_idx, column=CodebeamerUpdater.ADD_TYPE_IDX+1).value,
                                'Safety Relevance according to ASIL_ct':  ws_add.cell(row=row_idx, column=CodebeamerUpdater.ADD_SAFETY_RELEVANCE_IDX+1).value,
                                'parent_item': parent_item,
                                'child_item': child_item,
                                })

            # add data to input excel
            ws_add.cell(row=row_idx,
                        column=CodebeamerUpdater.ADD_TRACKER_ID_IDX+1).value = child_item.tracker.id
            # update data as predecessor reference
            ws_add.cell(row=row_idx,
                        column=CodebeamerUpdater.ADD_PREDECESSOR_ITEM_ID_IDX+1).value = child_item.id

            # insert same request as successor reference
            insert_idx = self.__get_last_idx_valid_row(worksheet=ws_add,
                                                       col_idx=CodebeamerUpdater.ADD_TYPE_IDX+1)+1
            # copy row data
            row_to_copy = list(ws_add.iter_rows(min_row=row_idx,
                                                max_row=row_idx,
                                                values_only=True))[0]
            # insert new empty row
            ws_add.insert_rows(insert_idx)

            # copy data
            for col, value in enumerate(row_to_copy, start=1):
                ws_add.cell(row=insert_idx, column=col, value=value)

            # add successor data
            ws_add.cell(row=insert_idx,
                        column=CodebeamerUpdater.ADD_SUCCESSOR_ITEM_ID_IDX+1).value = child_item.id

            # remove predecessor data
            ws_add.cell(row=insert_idx,
                        column=CodebeamerUpdater.ADD_PREDECESSOR_ITEM_ID_IDX+1).value = None

            # update descriptions
            description = ws_add.cell(
                row=row_idx, column=CodebeamerUpdater.ADD_DESCRIPTION_IDX+1).value
            ws_add.cell(row=row_idx, column=CodebeamerUpdater.ADD_DESCRIPTION_IDX +
                        1).value = description + ' - ' + 'SUCCESSOR'

            ws_add.cell(row=insert_idx, column=CodebeamerUpdater.ADD_DESCRIPTION_IDX +
                        1).value = description + ' - ' + 'PREDECESSOR'

        # save updated data input
        wb.save(test_data_modification_updated)

        # prepare test (adds test items, prepares codebeamer updater object, ...)
        codebeamer_updater = CodebeamerUpdater(cb_instance=self._cb_instance,
                                               update_template=test_data_modification_updated,
                                               output_dir_base=self.__get_test_output_path(test_name=test_name))

        # execute add modifications
        add_report_path = codebeamer_updater.execute_adds()

        # load report
        add_report = self.__load_xlsx(data_file_path=add_report_path)

        # check status
        for _, row in add_report.iterrows():
            self.assertEqual(row['Status'], 'Status.SUCCESS')

        # check children hierarchy
        add_1_successor = add_report.iloc[0]
        add_1_predecessor = add_report.iloc[2]
        add_2_successor = add_report.iloc[1]
        add_2_predecessor = add_report.iloc[3]

        parent_add1 = self._cb_server.get_item(item_id=self._cb_server.get_item(
            item_id=add_1_successor['Item ID']).parent.id)

        parent_add2 = self._cb_server.get_item(item_id=self._cb_server.get_item(
            item_id=add_2_successor['Item ID']).parent.id)

        self.assertEqual(parent_add1.children.components[0].id,
                         add_1_predecessor['Item ID'])
        self.assertEqual(parent_add1.children.components[1].id,
                         added_items[0]['child_item'].id)
        self.assertEqual(parent_add1.children.components[2].id,
                         add_1_successor['Item ID'])

        self.assertEqual(parent_add2.children.components[0].id,
                         add_2_predecessor['Item ID'])
        self.assertEqual(parent_add2.children.components[1].id,
                         added_items[1]['child_item'].id)
        self.assertEqual(parent_add2.children.components[2].id,
                         add_2_successor['Item ID'])

        # check content
        add_1_successor_item = self._cb_server.get_item(
            item_id=add_1_successor['Item ID'])
        add_1_predecessor_item = self._cb_server.get_item(
            item_id=add_1_predecessor['Item ID'])
        add_2_successor_item = self._cb_server.get_item(
            item_id=add_2_successor['Item ID'])
        add_2_predecessor_item = self._cb_server.get_item(
            item_id=add_2_predecessor['Item ID'])

        for field in ['Type', 'Safety Relevance according to ASIL_ct']:
            self.assertEqual(
                add_1_successor_item[field], added_items[0][field])
            self.assertEqual(
                add_1_predecessor_item[field], added_items[0][field])
            self.assertEqual(
                add_2_successor_item[field], added_items[1][field])
            self.assertEqual(
                add_2_predecessor_item[field], added_items[1][field])

        # clean up test artifacts
        self.__clean_output_path(test_name=test_name)

    def test_UPDATE_ADD_VALUE(self):
        """
        This test case tests the update with "ADD_VALUE"
        """
        test_name = 'UPDATE_ADD_VALUE'

        # create output folder if it does not exist yet
        if not self.__get_test_output_path(test_name=test_name).exists():
            self.__get_test_output_path(test_name=test_name).mkdir(
                parents=True, exist_ok=True)

        # prepare paths
        test_data_modification = self.__get_test_data_path(
            test_name=test_name) / 'Requirement_Modification_Template.xlsx'

        test_data_modification_updated = self.__get_test_output_path(
            test_name=test_name) / f'Requirement_Modification_Template_{test_name}.xlsx'

        # prepare minimal data for items
        item_dict = {
            'Module Variant_pe': ['SV62-1Box', 'SV62-2Box', 'CH63_Fallback'],
            'Description': f'Test description for test {test_name}',
            'Supplier': ['all'],
            'Safety Relevance according to ASIL_ct': 'No',
            'Security Relevance_ct': 'no',
            'Relevance for Author_ct': 'To edit by Author',
            'BsM-O_ct': 'Not rated'
        }

        # prepare test run folder
        test_run_parent_item = self.__insert_item_for_parent(parent_id=self._test_parent_item.id,
                                                             item_dict=dict(item_dict, **{'Type': 'Folder',
                                                                                          'Summary': f'Test - CodebeamerUpdater - {test_name} - {self._test_execution_data}'}))
        # prepare test run input data
        wb = load_workbook(test_data_modification)
        ws_updates = wb['FIELD_UPDATE']

        # add an item that will work as test item
        child_item = self.__insert_item_for_parent(parent_id=test_run_parent_item.id,
                                                   item_dict=dict(item_dict,
                                                                  **{'Type': 'Folder',
                                                                     'Summary': f'Child for test "{test_name}" - {self._test_execution_data}'}))
        # check that no comment exists
        self.assertTrue(len(child_item.comments.components) == 0)

        # add data to input excel
        ws_updates.cell(row=2,
                        column=CodebeamerUpdater.UPDATE_TRACKER_ID_IDX+1).value = child_item.tracker.id
        ws_updates.cell(row=2,
                        column=CodebeamerUpdater.UPDATE_ITEM_ID_IDX+1).value = child_item.id

        # add data for duplicate
        ws_updates.cell(row=3,
                        column=CodebeamerUpdater.UPDATE_TRACKER_ID_IDX+1).value = child_item.tracker.id
        ws_updates.cell(row=3,
                        column=CodebeamerUpdater.UPDATE_ITEM_ID_IDX+1).value = child_item.id

        # save updated data input
        wb.save(test_data_modification_updated)

        # prepare test
        codebeamer_updater = CodebeamerUpdater(cb_instance=self._cb_instance,
                                               update_template=test_data_modification_updated,
                                               output_dir_base=self.__get_test_output_path(test_name=test_name))

        # execute update modifications
        update_report_path = codebeamer_updater.execute_updates()

        # load report
        update_report = self.__load_xlsx(data_file_path=update_report_path)

        # prepare check
        updated_child_item = self._cb_server.get_item(item_id=child_item.id)

        # check status
        for _, row in update_report.iterrows():
            self.assertEqual(row['Status'], 'Status.SUCCESS')

        # check data
        self.assertEqual(child_item['Description'] + ws_updates['G2'].value,
                         updated_child_item['Description'])
        self.assertEqual((child_item['Module Variant_pe'] + ws_updates['I2'].value.split('\n')).sort(),
                         updated_child_item['Module Variant_pe'].sort())
        self.assertEqual((child_item['Supplier'] + ws_updates['M2'].value.split('\n')).sort(),
                         updated_child_item['Supplier'].sort())
        self.assertTrue(len(updated_child_item.comments.components) == 1)

        # clean up test artifacts
        self.__clean_output_path(test_name=test_name)

    def test_UPDATE_ALL_ITEM_FILTER(self):
        """
        This test case tests the update with "UPDATE_ALL_ITEM_FILTER"
        """
        test_name = 'UPDATE_ALL_ITEM_FILTER'

        # create output folder if it does not exist yet
        if not self.__get_test_output_path(test_name=test_name).exists():
            self.__get_test_output_path(test_name=test_name).mkdir(
                parents=True, exist_ok=True)

        # prepare paths
        test_data_modification = self.__get_test_data_path(
            test_name=test_name) / 'Requirement_Modification_Template.xlsx'

        test_data_modification_updated = self.__get_test_output_path(
            test_name=test_name) / f'Requirement_Modification_Template_{test_name}.xlsx'

        # prepare minimal data for items
        item_dict = {
            'Description': f'TEST_FILTER_DESCRIPTION',
            'Supplier': ['all'],
            'Safety Relevance according to ASIL_ct': 'No',
            'Security Relevance_ct': 'no',
            'Relevance for Author_ct': 'To edit by Author',
            'BsM-O_ct': 'Not rated'
        }

        # prepare test run folder
        test_run_parent_item = self.__insert_item_for_parent(parent_id=self._test_parent_item.id,
                                                             item_dict=dict(item_dict, **{'Type': 'Folder',
                                                                                          'Summary': f'Test - CodebeamerUpdater - {test_name} - {self._test_execution_data}'}))
        # add an item that will work as test item
        item_dict['Module Variant_pe'] = ['TBD']
        item_to_update_1 = self.__insert_item_for_parent(parent_id=test_run_parent_item.id,
                                                         item_dict=dict(item_dict,
                                                                        **{'Type': 'Folder',
                                                                           'Summary': f'Child for test "{test_name}" - {self._test_execution_data} - to be updated'}))
        item_to_update_2 = self.__insert_item_for_parent(parent_id=test_run_parent_item.id,
                                                         item_dict=dict(item_dict,
                                                                        **{'Type': 'Folder',
                                                                           'Summary': f'Child for test "{test_name}" - {self._test_execution_data} - to be updated'}))
        item_dict['Module Variant_pe'] = ['CH63_Main']
        item_to_filter = self.__insert_item_for_parent(parent_id=test_run_parent_item.id,
                                                       item_dict=dict(item_dict,
                                                                      **{'Type': 'Folder',
                                                                         'Summary': f'Child for test "{test_name}" - {self._test_execution_data} - to be ignored'}))
        # prepare test run input data
        wb = load_workbook(test_data_modification)
        ws_updates = wb['FIELD_UPDATE']

        # check that no comment exists
        self.assertTrue(len(item_to_update_1.comments.components) == 0)
        self.assertTrue(len(item_to_update_2.comments.components) == 0)
        self.assertTrue(len(item_to_filter.comments.components) == 0)

        # add data to input excel
        ws_updates.cell(row=2,
                        column=CodebeamerUpdater.UPDATE_TRACKER_ID_IDX+1).value = test_run_parent_item.tracker.id

        # save updated data input
        wb.save(test_data_modification_updated)

        # prepare test
        codebeamer_updater = CodebeamerUpdater(cb_instance=self._cb_instance,
                                               update_template=test_data_modification_updated,
                                               output_dir_base=self.__get_test_output_path(test_name=test_name))

        # execute update modifications
        update_report_path = codebeamer_updater.execute_updates()

        # load report
        update_report = self.__load_xlsx(data_file_path=update_report_path)

        # check status
        for _, row in update_report.iterrows():
            self.assertEqual(row['Status'], 'Status.SUCCESS')

        # check report: contain 2 rows -> updated items
        self.assertEqual(update_report.shape[0], 2)

        # prepare check
        updated_item_to_update_1 = self._cb_server.get_item(
            item_id=item_to_update_1.id)
        updated_item_to_update_2 = self._cb_server.get_item(
            item_id=item_to_update_2.id)
        updated_item_to_filter = self._cb_server.get_item(
            item_id=item_to_filter.id)

        # check data
        # check that (no) comment exists
        self.assertTrue(len(updated_item_to_update_1.comments.components) == 1)
        self.assertTrue(len(updated_item_to_update_2.comments.components) == 1)
        self.assertTrue(len(updated_item_to_filter.comments.components) == 0)

        # clean up test artifacts
        self.__clean_output_path(test_name=test_name)

    def test_UPDATE_REMOVE_VALUE(self):
        """
        This test case tests the update with "UPDATE_REMOVE_VALUE"
        """
        test_name = 'UPDATE_REMOVE_VALUE'

        # create output folder if it does not exist yet
        if not self.__get_test_output_path(test_name=test_name).exists():
            self.__get_test_output_path(test_name=test_name).mkdir(
                parents=True, exist_ok=True)

        # prepare paths
        test_data_modification = self.__get_test_data_path(
            test_name=test_name) / 'Requirement_Modification_Template.xlsx'

        test_data_modification_updated = self.__get_test_output_path(
            test_name=test_name) / f'Requirement_Modification_Template_{test_name}.xlsx'

        # prepare minimal data for items
        item_dict = {
            'Description': f'TEST_FILTER_DESCRIPTION',
            'Module Variant_pe': ['TBD'],
            'Supplier': ['all'],
            'Safety Relevance according to ASIL_ct': 'No',
            'Security Relevance_ct': 'no',
            'Relevance for Author_ct': 'To edit by Author',
            'BsM-O_ct': 'Not rated'
        }

        # prepare test run folder
        test_run_parent_item = self.__insert_item_for_parent(parent_id=self._test_parent_item.id,
                                                             item_dict=dict(item_dict, **{'Type': 'Folder',
                                                                                          'Summary': f'Test - CodebeamerUpdater - {test_name} - {self._test_execution_data}'}))
        # add an item that will work as test item
        item_to_update = self.__insert_item_for_parent(parent_id=test_run_parent_item.id,
                                                       item_dict=dict(item_dict,
                                                                      **{'Type': 'Folder',
                                                                         'Summary': f'Child for test "{test_name}" - {self._test_execution_data} - to be updated'}))

        # prepare test run input data
        wb = load_workbook(test_data_modification)
        ws_updates = wb['FIELD_UPDATE']

        # check that no comment exists
        self.assertTrue(len(item_to_update.comments.components) == 0)

        # add data to input excel
        ws_updates.cell(row=2,
                        column=CodebeamerUpdater.UPDATE_TRACKER_ID_IDX+1).value = test_run_parent_item.tracker.id
        ws_updates.cell(row=2,
                        column=CodebeamerUpdater.UPDATE_ITEM_ID_IDX+1).value = item_to_update.id

        # save updated data input
        wb.save(test_data_modification_updated)

        # prepare test
        codebeamer_updater = CodebeamerUpdater(cb_instance=self._cb_instance,
                                               update_template=test_data_modification_updated,
                                               output_dir_base=self.__get_test_output_path(test_name=test_name))

        # execute update modifications
        update_report_path = codebeamer_updater.execute_updates()

        # load report
        update_report = self.__load_xlsx(data_file_path=update_report_path)

        # check status
        for _, row in update_report.iterrows():
            self.assertEqual(row['Status'], 'Status.SUCCESS')

        # check report: contain 2 rows -> updated items
        self.assertEqual(update_report.shape[0], 2)

        # prepare check
        updated_item_to_update = self._cb_server.get_item(
            item_id=item_to_update.id)

        # check data
        # check that comment exists
        self.assertTrue(len(updated_item_to_update.comments.components) == 1)

        self.assertEqual(updated_item_to_update['Module Variant_pe'], None)
        self.assertEqual(updated_item_to_update['Supplier'], None)

        # clean up test artifacts
        self.__clean_output_path(test_name=test_name)

    def test_UPDATE_SET_VALUE(self):
        """
        This test case tests the update with "UPDATE_SET_VALUE"
        """
        test_name = 'UPDATE_SET_VALUE'

        # create output folder if it does not exist yet
        if not self.__get_test_output_path(test_name=test_name).exists():
            self.__get_test_output_path(test_name=test_name).mkdir(
                parents=True, exist_ok=True)

        # prepare paths
        test_data_modification = self.__get_test_data_path(
            test_name=test_name) / 'Requirement_Modification_Template.xlsx'

        test_data_modification_updated = self.__get_test_output_path(
            test_name=test_name) / f'Requirement_Modification_Template_{test_name}.xlsx'

        # prepare minimal data for items
        item_dict = {
            'Relevance for Author_ct': 'To edit by Author',
            'BsM-O_ct': 'Not rated'
        }

        # prepare test run folder
        test_run_parent_item = self.__insert_item_for_parent(parent_id=self._test_parent_item.id,
                                                             item_dict=dict(item_dict, **{'Type': 'Folder',
                                                                                          'Summary': f'Test - CodebeamerUpdater - {test_name} - {self._test_execution_data}'}))
        # add an item that will work as test item
        item_to_update = self.__insert_item_for_parent(parent_id=test_run_parent_item.id,
                                                       item_dict=dict(item_dict,
                                                                      **{'Type': 'Functional',
                                                                         'Summary': f'Child for test "{test_name}" - {self._test_execution_data} - to be updated'}))

        # prepare test run input data
        wb = load_workbook(test_data_modification)
        ws_updates = wb['FIELD_UPDATE']

        # check that no comment exists
        self.assertTrue(len(item_to_update.comments.components) == 0)

        # add data to input excel
        ws_updates.cell(row=2,
                        column=CodebeamerUpdater.UPDATE_TRACKER_ID_IDX+1).value = test_run_parent_item.tracker.id
        ws_updates.cell(row=2,
                        column=CodebeamerUpdater.UPDATE_ITEM_ID_IDX+1).value = item_to_update.id

        # save updated data input
        wb.save(test_data_modification_updated)

        # prepare test
        codebeamer_updater = CodebeamerUpdater(cb_instance=self._cb_instance,
                                               update_template=test_data_modification_updated,
                                               output_dir_base=self.__get_test_output_path(test_name=test_name))

        # execute update modifications
        update_report_path = codebeamer_updater.execute_updates()

        # load report
        update_report = self.__load_xlsx(data_file_path=update_report_path)

        # check status
        for _, row in update_report.iterrows():
            self.assertEqual(row['Status'], 'Status.SUCCESS')

        # check report: contain 7 rows -> updated items
        self.assertEqual(update_report.shape[0], 6)

        # prepare check
        updated_item_to_update = self._cb_server.get_item(
            item_id=item_to_update.id)

        # check data
        # check that comment exists
        self.assertTrue(len(updated_item_to_update.comments.components) == 1)

        self.assertEqual(updated_item_to_update['Module Variant_pe'], ['TBD'])
        self.assertEqual(updated_item_to_update['Supplier'], ['tbd'])
        self.assertEqual(
            updated_item_to_update['Security Relevance_ct'], 'tbd')
        self.assertEqual(
            updated_item_to_update['Safety Relevance according to ASIL_ct'], 'tbd')
        self.assertEqual(
            updated_item_to_update['Description'], 'ADD_DESCRIPTION_TEST_TEXT')
        self.assertEqual(updated_item_to_update['Type'], 'Non-functional')
        self.assertEqual(updated_item_to_update['Status'], 'in Progress')

        # clean up test artifacts
        self.__clean_output_path(test_name=test_name)

    def test_UPDATE_SUBSTITUTE_VALUE(self):
        """
        This test case tests the update with "UPDATE_SUBSTITUTE_VALUE"
        """
        test_name = 'UPDATE_SUBSTITUTE_VALUE'

        # create output folder if it does not exist yet
        if not self.__get_test_output_path(test_name=test_name).exists():
            self.__get_test_output_path(test_name=test_name).mkdir(
                parents=True, exist_ok=True)

        # prepare paths
        test_data_modification = self.__get_test_data_path(
            test_name=test_name) / 'Requirement_Modification_Template.xlsx'

        test_data_modification_updated = self.__get_test_output_path(
            test_name=test_name) / f'Requirement_Modification_Template_{test_name}.xlsx'

        # prepare minimal data for items
        item_dict = {
            'Description': f'ADD_DESCRIPTION_TEST_TEXT_ORIG_VALUE_END',
            'Module Variant_pe': ['TBD'],
            'Supplier': ['all'],
            'Safety Relevance according to ASIL_ct': 'No',
            'Security Relevance_ct': 'no',
            'Relevance for Author_ct': 'To edit by Author',
            'BsM-O_ct': 'Not rated'
        }

        # prepare test run folder
        test_run_parent_item = self.__insert_item_for_parent(parent_id=self._test_parent_item.id,
                                                             item_dict=dict(item_dict, **{'Type': 'Folder',
                                                                                          'Summary': f'Test - CodebeamerUpdater - {test_name} - {self._test_execution_data}'}))
        # add an item that will work as test item
        item_to_update = self.__insert_item_for_parent(parent_id=test_run_parent_item.id,
                                                       item_dict=dict(item_dict,
                                                                      **{'Type': 'Functional',
                                                                         'Summary': f'Child for test "{test_name}" - {self._test_execution_data} - to be updated'}))

        # prepare test run input data
        wb = load_workbook(test_data_modification)
        ws_updates = wb['FIELD_UPDATE']

        # check that no comment exists
        self.assertTrue(len(item_to_update.comments.components) == 0)

        # add data to input excel
        ws_updates.cell(row=2,
                        column=CodebeamerUpdater.UPDATE_TRACKER_ID_IDX+1).value = test_run_parent_item.tracker.id
        ws_updates.cell(row=2,
                        column=CodebeamerUpdater.UPDATE_ITEM_ID_IDX+1).value = item_to_update.id

        # save updated data input
        wb.save(test_data_modification_updated)

        # prepare test
        codebeamer_updater = CodebeamerUpdater(cb_instance=self._cb_instance,
                                               update_template=test_data_modification_updated,
                                               output_dir_base=self.__get_test_output_path(test_name=test_name))

        # execute update modifications
        update_report_path = codebeamer_updater.execute_updates()

        # load report
        update_report = self.__load_xlsx(data_file_path=update_report_path)

        # check status
        for _, row in update_report.iterrows():
            self.assertEqual(row['Status'], 'Status.SUCCESS')

        # prepare check
        updated_item_to_update = self._cb_server.get_item(
            item_id=item_to_update.id)

        # check data
        # check that comment exists
        self.assertTrue(len(updated_item_to_update.comments.components) == 1)

        # check substituted data
        self.assertEqual(
            updated_item_to_update['Module Variant_pe'], ['CH63_Main'])
        self.assertEqual(updated_item_to_update['Supplier'], ['tbd'])
        self.assertEqual(
            updated_item_to_update['Description'], 'ADD_DESCRIPTION_TEST_TEXT_SUBSTITUE_VALUE_END')

        # clean up test artifacts
        self.__clean_output_path(test_name=test_name)


if __name__ == '__main__':
    unittest.main()
