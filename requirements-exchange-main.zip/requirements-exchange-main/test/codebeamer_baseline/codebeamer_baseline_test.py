import unittest
from argparse import ArgumentParser

from src.baseline.codebeamer_baseline import CodebeamerBaseline, parse_baseline_data

# Function to print baseline details
def print_baseline_details(result):
    print("Baseline Name:", result.name)
    print("Baseline Description:", result.description)

# Unit test class for Codebeamer Baseline functionality
class TestCodebeamerBaseline(unittest.TestCase):

    # Test method to validate create baseline functionality
    def test_create_baseline(self):
        # Test data
        cb_instance = 'QS'
        project_id = 1329
        baseline_name = "CH63-testing_Pre cleanup - Internal to Audi 2024-CW49.5"
        baseline_description = "Creating baselines for script testing"

        # Parse baseline data
        baseline_data = parse_baseline_data(baseline_name, baseline_description, project_id, None)
        # Create Codebeamer Baseline instance
        codebeamer_baseline = CodebeamerBaseline(cb_instance, project_id, None, baseline_data)
        
        try:
            # Attempt to create baseline
            result = codebeamer_baseline.create_baseline()
            # Validate result is not None
            self.assertIsNotNone(result)
            # Print object name and description
            print_baseline_details(result)
            # Check values
            self.assertEqual(result.name, baseline_name)
            self.assertEqual(result.description, baseline_description)
        except Exception as e:
            # Print error message if exception occurs
            print(f"Error: {e}")

    # Test method to validate create tracker baseline functionality
    def test_create_tracker_baseline(self):
        # Test data
        cb_instance = 'QS'
        project_id = 1329
        tracker_id = 92348129
        baseline_name = "CH63-testing_Pre cleanup - Internal to Audi 2024-CW49.5_tracker"
        baseline_description = "Creating baselines for script testing for tracker"

        # Parse baseline data
        baseline_data = parse_baseline_data(baseline_name, baseline_description, project_id, tracker_id)
        # Create Codebeamer Baseline instance
        codebeamer_baseline = CodebeamerBaseline(cb_instance, project_id, tracker_id, baseline_data)
        
        try:
            # Create tracker baseline
            result = codebeamer_baseline.create_tracker_baseline()
            # Validate result is not None
            self.assertIsNotNone(result)
            # Print object name and description
            print_baseline_details(result)
            # Check values
            self.assertEqual(result.name, baseline_name)
            self.assertEqual(result.description, baseline_description)
        except Exception as e:
            # Print error message if exception occurs
            print(f"Error: {e}")

if __name__ == '__main__':
    unittest.main()
