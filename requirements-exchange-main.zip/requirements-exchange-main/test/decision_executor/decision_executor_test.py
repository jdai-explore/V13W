"""
This module provides test for DecisionExecutor
"""
import unittest
import shutil
import os
import calmpy
import re
import json
import calmpy.exceptions
from typing import Dict
import pandas as pd
from pathlib import Path
from datetime import datetime
from src.decision_executor.decision_executor import DecisionExecutor


class TestDecisionExecutor(unittest.TestCase):
    """
    Class for testing the DecisionExecutor
    """

    def __get_test_config_path(self, test_name: str) -> Path:
        """
        Returns config path for given test
        :param test_name: name of test
        :type test_name: str
        :return: path to configs for given test
        :type Path
        """
        return self._test_data_base_path / ('test_' + str(test_name)) / 'configs'

    def __get_test_data_path(self, test_name: str) -> Path:
        """
        Returns data path for given test
        :param test_name: name of test
        :type test_name: str
        :return: path to data for given test
        :type Path
        """
        return self._test_data_base_path / ('test_' + str(test_name)) / 'data'

    def __get_test_output_path(self, test_name: str) -> Path:
        """
        Returns output path for given test
        :param test_name: name of test
        :type test_name: str
        :return: path to output for given test
        :type Path
        """
        return self._test_data_base_path / ('test_' + str(test_name)) / 'output'

    def __clean_output_path(self, test_name: str):
        """
        Removes all outputs created for specified tests
        :param test_name: name of test
        :type test_name: str
        """
        # remove output folder
        shutil.rmtree(self.__get_test_output_path(test_name=test_name))
        # create the folder
        os.makedirs(self.__get_test_output_path(test_name=test_name),
                    exist_ok=True)

    def __update_parent(self, parent_id: int, item_id: int) -> bool:
        """
        Updates parent item that specified id is child
        :param parent_id: id of item to insert child to
        :type parent_id: str
        :param item_id: child to add
        :type item_id: str
        :return: status of execution (True if success, else False)
        :type bool
        """
        # url of children for parent
        children_url = f'{self._cb_server.query.SWAGGER_URL_V3}/items/' + \
                       f'{int(parent_id)}/children'

        # get all current item children
        response = self._cb_server.session.make_paged_requests(request_url=children_url,
                                                               request_type='GET',
                                                               is_readonly_operation=True,
                                                               entries=500)

        # check if its more than 1 page
        if response.total > 1:
            print(f'parent {parent_id} has more than 500 children.' +
                  f' Hierarchy of item {item_id} will be ignored')
            return False

        # extract children list
        parent_child_refs = response.all[0].content['itemRefs']

        # convert to list of children ids
        existing_children_ids = [children['id']
                                 for children in parent_child_refs]

        # check if item is already a child
        if item_id not in existing_children_ids:
            # insert child
            parent_child_refs.append(
                {'id': int(item_id), 'type': 'TrackerItemReference'})

            # transform to query data
            children_data = {'children': parent_child_refs}

            # update hierarchy
            try:
                response = self._cb_server.session.make_single_request(request_url=children_url,
                                                                       request_type='PUT',
                                                                       data=children_data)
            except ...:
                return False
            return True
        return True

    def __load_xlsx(self, data_file_path: Path) -> pd.DataFrame:
        """
        Loads xlsx file and returns pandas Dataframe
        :param data_file_path: Path of xlsx file
        :type data_file_path: Path
        :return: xlsx data
        :type data_file_path: pd.DataFrame
        """
        if data_file_path.suffix == ".xlsx":
            return pd.read_excel(data_file_path)
        else:
            print('Requested requirement input format not accepted!')
            return None

    def __load_json(self, config_file_path: Path) -> Dict:
        """
        Loads JSON file.
        :param config_file_path: path to .json file
        :type config_file_path: Path
        :return: Json data
        :type Dict
        """
        with open(config_file_path, 'r', encoding='utf-8') as file:
            return json.load(file)

    def __save_df_as_xlsx(self, df: pd.DataFrame, data_file_path: Path):
        """
        Saves Dataframe in given path
        :param df: Dataframe to save
        :type df: pd.DataFrame
        :param data_file_path: Path where Dataframe should be saved
        :type data_file_path: Path
        """
        writer = pd.ExcelWriter(data_file_path, engine='xlsxwriter')
        df.to_excel(writer, sheet_name='Updates', index=False)

        for column in df:
            column_length = max(df[column].astype(
                str).map(len).max(), len(column)) + 5
            col_idx = df.columns.get_loc(column)
            writer.sheets['Updates'].set_column(
                col_idx, col_idx, column_length)

        writer.close()

    def __insert_item_for_parent(self, parent_id: int, item_dict: dict) -> calmpy.Item:
        """
        Creates item with provided data for a specified parent id
        :param parent_id: id of item to insert child to
        :type parent_id: str
        :param item_dict: data of item to add
        :type item_dict: dict
        :return: item that got added
        :type calmpy.Item
        """
        parent = self._cb_server.get_item(parent_id)

        try:
            new_item = self._cb_server.get_tracker(
                int(parent.tracker.id)).create_item(fields=item_dict)
        except calmpy.exceptions.ServerError as e:
            print(e)
            print(f'Problem in creating item for parent {
            parent_id} with data: {item_dict}')

        status = self.__update_parent(parent_id=parent_id, item_id=new_item.id)

        return new_item if status else None

    def __update_field(self, item_id: int, field_name: str, field_value):
        """
        Updates the specified field in Codebeamer with provided value
        :param item_id: id of item which field will get updated
        :type item_id: int
        :param field_name: name of the field to update
        :type field_name: str
        :param field_value: value to update item field to
        :type field_value: int/str/list
        :return: status of the update operation (True if success, else False)
        :type bool
        """
        # execute step
        try:
            item = calmpy.Item(server=self._cb_server, item_id=item_id)
            item[field_name] = field_value
            item.update_fields()

            # verify update
            item = calmpy.Item(server=self._cb_server, item_id=item_id)

            if field_name in item:
                if item[field_name] == field_value:
                    return True
            return False
        except calmpy.exceptions.ServerError as e:
            return False

    def __create_decision_executor(self, test_name: str) -> DecisionExecutor:
        """
        Creates decision executor object and prepares test data (creating items in codebeamer, ...)
        :param test_name: name of test to prepare data for
        :type test_name: str
        :return: decision executor object
        :type DecisionExecutor
        """
        # create output folder if it does not exist yet
        if not self.__get_test_output_path(test_name=test_name).exists():
            self.__get_test_output_path(test_name=test_name).mkdir(
                parents=True, exist_ok=True)

        # prepare paths
        test_data_decision = self.__get_test_data_path(
            test_name=test_name) / 'Test-AutoCCBDecisions.xlsx'

        test_data_decision_updated = self.__get_test_output_path(
            test_name=test_name) / f'Test-AutoCCBDecisions_{test_name}.xlsx'

        test_data_synch = self.__get_test_data_path(
            test_name=test_name) / 'SyncExecutionState.json'
        test_data_synch_updated = self.__get_test_output_path(
            test_name=test_name) / 'SyncExecutionState.json'

        # prepare minimal data for items
        item_dict = {
            'Module Variant_pe': ['SV62-1Box', 'SV62-2Box', 'CH63_Main', 'CH63_Fallback'],
            'Safety Relevance according to ASIL_ct': 'No',
            'Security Relevance_ct': 'no'
        }

        # prepare test run folder
        test_run_parent_item = self.__insert_item_for_parent(parent_id=self._test_parent_item.id,
                                                             item_dict=dict(item_dict, **{'Type': 'Folder',
                                                                                          'Summary': f'Test {test_name} - {self._test_execution_data}'}))

        # prepare test run input data
        ccb_decision_df = self.__load_xlsx(data_file_path=test_data_decision)

        # prepare updated decision input
        updated_decisions_df = pd.DataFrame(
            columns=(list(ccb_decision_df.columns)))

        # Check if there are decisions
        added_items = {}
        if not ccb_decision_df.empty:
            # Iterate over all entries
            for _, row in ccb_decision_df.iterrows():
                ch63_item_name = row['CH63-ItemName']

                if ch63_item_name in added_items:
                    # update items
                    self.__update_field(item_id=added_items[ch63_item_name]['ch63_item'].id,
                                        field_name=row['CH63-FieldName'],
                                        field_value=row['CH63-FieldValue'])
                    self.__update_field(item_id=added_items[ch63_item_name]['sv62_item'].id,
                                        field_name=row['SV62-FieldName'],
                                        field_value=row['SV62-FieldValue'])
                else:
                    # create CH63 item
                    ch63_item = self.__insert_item_for_parent(parent_id=test_run_parent_item.id,
                                                              item_dict=dict(item_dict, **{
                                                                  'Type': 'Functional',
                                                                  'Description': f'CH63 - Req {row['CH63-ItemName']} for Test "{test_name}" - {self._test_execution_data}',
                                                                  row['CH63-FieldName']: row['CH63-FieldValue']}))
                    # create corresponding SV62 item
                    sv62_item = self.__insert_item_for_parent(parent_id=test_run_parent_item.id,
                                                              item_dict=dict(item_dict, **{
                                                                  'Type': 'Functional',
                                                                  'Description': f'SV62 - Req {row['SV62-ItemName']} for Test "{test_name}" - {self._test_execution_data}',
                                                                  row['SV62-FieldName']: row['SV62-FieldValue']}))
                    added_items[ch63_item_name] = {
                        'ch63_item': ch63_item,
                        'sv62_item': sv62_item
                    }

                # Execute decision
                updated_decision_dict = row.to_dict()

                if updated_decision_dict is not None:
                    # Add ch63 item data
                    updated_decision_dict['CH63-TrackerID'] = ch63_item.tracker.id
                    updated_decision_dict['CH63-TrackerName'] = ch63_item.tracker.name
                    updated_decision_dict['CH63-ItemId'] = ch63_item.id
                    updated_decision_dict['CH63-ItemName'] = ch63_item.name

                    # Add sv62 item data
                    updated_decision_dict['SV62-TrackerID'] = sv62_item.tracker.id
                    updated_decision_dict['SV62-TrackerName'] = sv62_item.tracker.name
                    updated_decision_dict['SV62-ItemId'] = sv62_item.id
                    updated_decision_dict['SV62-ItemName'] = sv62_item.name

                # Add updated decision
                updated_decisions_df.loc[len(
                    updated_decisions_df)] = updated_decision_dict

                # Save executed decision dataframe
                self.__save_df_as_xlsx(df=updated_decisions_df,
                                       data_file_path=test_data_decision_updated)

        # copy 'SyncExecutionState.json' from data to output
        shutil.copy2(test_data_synch, test_data_synch_updated)

        # initialize DecisionExecutor
        return DecisionExecutor(
            cb_server=self._cb_server.URL,
            ccb_decisions_path=test_data_decision_updated,
            execution_state_path=test_data_synch_updated,
            output_dir=self.__get_test_output_path(test_name=test_name),
            sv62_to_ch63_field_mapping_path=self.__get_test_config_path(
                test_name=test_name) / 'mappings' / 'SV62_to_CH63_field_mapping.json')

    def __get_test_parent_id(self) -> calmpy.Item:
        """
        Returns test parent (item in codebeamer where data will get added), if it does not exists it will create it
        :return: test parent item in codebeamer
        :type calmpy.Item
        """
        test_parent_id = next((item for item in self._cb_server.get_tracker(self._test_tracker_id).get_items()
                               if
                               item.name == 'FOR INTERNAL TESTS ONLY - SHALL BE DELETED' and item['Type'] == 'Folder'),
                              None)
        # check if test parent item exists
        if test_parent_id is None:
            # create test parent item
            test_parent_id = self._cb_server.get_tracker(self._test_tracker_id).create_item(
                fields={'Summary': 'FOR INTERNAL TESTS ONLY - SHALL BE DELETED',
                        'Type': 'Folder'})
        return test_parent_id

    def __check_sync_execution_state(self, test_name: str):
        """
        Checks if the decision executor of specified test incremented the SyncExecutionState.json as intended
        """
        pre_test_sync_exe_state = self.__load_json(
            config_file_path=self.__get_test_data_path(test_name=test_name) / 'SyncExecutionState.json')
        post_test_sync_exe_state = self.__load_json(
            config_file_path=self.__get_test_output_path(test_name=test_name) / 'SyncExecutionState.json')

        pre_last_execution = int(
            max(pre_test_sync_exe_state, key=lambda x: int(x['Iteration']))['Iteration'])
        post_last_execution = int(
            max(post_test_sync_exe_state, key=lambda x: int(x['Iteration']))['Iteration'])

        self.assertTrue((pre_last_execution + 1) == post_last_execution)

    def setUp(self):
        """
        Initialize any variables or resources needed for the tests.
        """
        self._cb_server = calmpy.Server(url='QS', readonly=False)
        self._test_data_base_path = Path('./test/test_data/decision_executor')
        self._test_tracker_id = 92348129
        self._test_parent_item = self.__get_test_parent_id()
        self._test_execution_data = datetime.today().strftime('%Y-%m-%d %H:%M')

    def test_new_items_decisions(self):
        """
        Tests new items creation from CCB decisions.
        This test validates:
        - item creation
        - field update
        - correct parent/predecessor/Successor/Last item (Top level) relationship
        """
        ccb_decisions_path = self._test_data_base_path / 'test_new_items_ccb_decisions' / 'Test-New_Items_CCBDecisions.xlsx'
        # create reference item
        reference_item = self.__insert_item_for_parent(parent_id=self._test_parent_item.id,
                                                       item_dict={'Type': 'Functional',
                                                                  'Summary': f'Test New Items CCB Decisions - Reference Item'})
        reference_id = reference_item.id
        # load excel and update only destination_reference
        df = pd.read_excel(ccb_decisions_path)
        df['CCB Decision'] = df['CCB Decision'].apply(
            lambda cell: ';'.join(
                [f'destination_reference={reference_id}' if part.strip().startswith(
                    'destination_reference') else part.strip()
                 for part in str(cell).split(';')]
            )
        )
        # save excel
        df.to_excel(ccb_decisions_path, index=False, sheet_name="new_items")
        execution_state_path = self.__get_test_data_path(
            test_name="new_items_ccb_decisions") / 'SyncExecutionState.json'
        sv62_to_ch63_field_mapping_path = self.__get_test_config_path(
            test_name="new_items_ccb_decisions") / 'mappings' / 'SV62_to_CH63_field_mapping.json'
        executor = DecisionExecutor(cb_server=self._cb_server.URL, ccb_decisions_path=ccb_decisions_path,
                                    sv62_to_ch63_field_mapping_path=sv62_to_ch63_field_mapping_path,
                                    execution_state_path=execution_state_path,
                                    output_dir=Path(''))
        new_items = executor.execute_new_items_decisions()

        df = pd.read_excel(ccb_decisions_path, sheet_name="new_items")
        df.columns = df.columns.str.strip()
        for created_item_id, (_, row) in zip(new_items, df.iterrows()):
            item = calmpy.Item(server=self._cb_server, item_id=created_item_id)
            ccb_decision = row.get("CCB Decision", "")
            parsed_ccb = {}
            for entry in ccb_decision.split(";"):
                if "=" in entry:
                    key, value = entry.split("=", 1)
                    parsed_ccb[key.strip()] = value.strip()
            module_variant = parsed_ccb.get('module_variant')
            # prepare tracker and item order context for position validation
            reference_item = calmpy.Item(server=self._cb_server, item_id=parsed_ccb.get('destination_reference'))
            destination_type = parsed_ccb.get('destination_type')
            tracker_id = reference_item.tracker.id
            tracker = self._cb_server.get_tracker(tracker_id=tracker_id)
            all_items = tracker.get_items()
            item_ids = [item.id for item in all_items]
            self.assertIn(created_item_id, item_ids)
            ref_index = item_ids.index(reference_item.id)
            created_index = item_ids.index(created_item_id)
            # test item hierarchical position using destination_type
            if "Parent" == destination_type:
                # created item should be in children list
                child_items = self._cb_server.get_item(reference_item.id).children
                child_ids = [child.id for child in child_items]
                self.assertIn(created_item_id, child_ids)
            elif destination_type in ("Predecessor", "Successor"):
                if destination_type == "Predecessor":
                    self.assertTrue(created_index > ref_index,
                                    f"Created item should be after reference. Got {created_index} > {ref_index}")
                elif destination_type == "Successor":
                    self.assertTrue(created_index < ref_index,
                                    f"Created item should be before reference. Got {created_index} < {ref_index}")
            elif destination_type == "Last item (Top Level)":
                # check it's the last item in tracker
                self.assertEqual(created_item_id, item_ids[-1])
            else:
                self.fail(f"Unsupported destination type: {destination_type}")

            # test for field name 'Module Variant_pe'
            if module_variant == "None" or pd.isna(module_variant):
                self.assertEqual(item['Module Variant_pe'], None)
            elif isinstance(module_variant, str):
                mod_var_list = [mod_var.strip() for mod_var in module_variant.split(",")]
                if any("Take over from other instance" in mod_var for mod_var in mod_var_list):
                    base_value = row.get("Module Variant_pe")
                    base_values = [v.strip() for v in base_value.split(",")] if (pd.notna(base_value) and
                                                                                 isinstance(base_value, str)) else []
                    additional_values = [mod_var for mod_var in mod_var_list if
                                         "Take over from other instance" not in mod_var]
                    expected_values = base_values + additional_values
                else:
                    expected_values = mod_var_list
                self.assertEqual(item['Module Variant_pe'], expected_values)
            else:
                self.fail(f"unsupported module variant_pe type: {module_variant}")
            # test for other fields
            for col in executor.NEW_ITEM_COLUMNS:
                if col == "Functional Safety Classification (according ISO26262)_ct":
                    if pd.isna(row.get("Functional Safety Classification (according ISO26262)_ct")):
                        self.assertEqual(item['Safety Relevance according to ASIL_ct'], None)
                    else:
                        self.assertEqual(item['Safety Relevance according to ASIL_ct'], row[col])

                elif col == "BsM-E.D_ct":
                    if pd.isna(row.get("BsM-E.D_ct")):
                        self.assertEqual(item['BsM-E.D_ct'], None)
                    else:
                        self.assertEqual(item['BsM-E.D_ct'], row[col])

    def test_execute_decision_SV62_TO_CH63(self):
        """
        This test case tests the decision "SV62_TO_CH63"
        """
        test_name = 'SV62_TO_CH63'

        # prepare test (adds test items, prepares decision executor object, ...)
        decision_executor = self.__create_decision_executor(
            test_name=test_name)

        # execute decisions
        decision_executor.execute_decisions()

        # check results (ch63 item was updated with sv62 value)
        ccb_decision_df = self.__load_xlsx(
            data_file_path=(self.__get_test_output_path(test_name=test_name) /
                            f'Test-AutoCCBDecisions_{test_name}_processed.xlsx'))

        item_updated = self._cb_server.get_item(
            int(ccb_decision_df.iloc[0]['CH63-ItemId']))

        # check if field was set correctly
        self.assertEqual(item_updated[ccb_decision_df.iloc[0]['CH63-FieldName']],
                         ccb_decision_df.iloc[0]['SV62-FieldValue'])

        # check if comment contains required information
        self.assertTrue(
            ccb_decision_df.iloc[0]['CCB Participants'] in item_updated['CCB_Decision'])
        self.assertTrue(
            ccb_decision_df.iloc[0]['CCB Rational'] in item_updated['CCB_Decision'])

        # check if status is success
        self.assertEqual('SUCCESS', ccb_decision_df.iloc[0]['Status'])

        # check sync execution state changes
        self.__check_sync_execution_state(test_name=test_name)

        # clean up test artifacts
        self.__clean_output_path(test_name=test_name)

    def test_execute_decision_CH63_TO_SV62(self):
        """
        This test case tests the decision "CH63_TO_SV62"
        """
        test_name = 'CH63_TO_SV62'

        # prepare test
        decision_executor = self.__create_decision_executor(
            test_name=test_name)

        # execute decisions
        decision_executor.execute_decisions()

        # check results
        ccb_decision_df = self.__load_xlsx(
            data_file_path=(self.__get_test_output_path(test_name=test_name) /
                            f'Test-AutoCCBDecisions_{test_name}_processed.xlsx'))

        # check if status is skipped (TODO for now)
        self.assertEqual('SKIPPED', ccb_decision_df.iloc[0]['Status'])

        # check sync execution state changes
        self.__check_sync_execution_state(test_name=test_name)

        # clean up test artifacts
        self.__clean_output_path(test_name=test_name)

    def test_execute_decision_OBSOLETE(self):
        """
        This test case tests the decision "OBSOLETE"
        """
        test_name = 'OBSOLETE'

        # prepare test
        decision_executor = self.__create_decision_executor(
            test_name=test_name)

        # execute decisions
        decision_executor.execute_decisions()

        # check results (ch63 item was updated with sv62 value)
        ccb_decision_df = self.__load_xlsx(
            data_file_path=(self.__get_test_output_path(test_name=test_name) /
                            f'Test-AutoCCBDecisions_{test_name}_processed.xlsx'))

        item_ch63 = self._cb_server.get_item(
            int(ccb_decision_df.iloc[0]['CH63-ItemId']))

        # check if field was set correctly
        self.assertEqual(item_ch63.status, 'Obsolete')

        # check if comment contains required information
        self.assertTrue(
            ccb_decision_df.iloc[0]['CCB Participants'] in item_ch63['CCB_Decision'])
        self.assertTrue(
            ccb_decision_df.iloc[0]['CCB Rational'] in item_ch63['CCB_Decision'])

        # check if status is success
        self.assertEqual('SUCCESS', ccb_decision_df.iloc[0]['Status'])

        # check sync execution state changes
        self.__check_sync_execution_state(test_name=test_name)

        # clean up test artifacts
        self.__clean_output_path(test_name=test_name)

    def test_execute_decision_DEVIATE(self):
        """
        This test case tests the decision "DEVIATE"
        """
        test_name = 'DEVIATE'

        # prepare test
        decision_executor = self.__create_decision_executor(
            test_name=test_name)

        # execute decisions
        decision_executor.execute_decisions()

        # check results (ch63 item was updated with sv62 value)
        ccb_decision_df = self.__load_xlsx(
            data_file_path=(self.__get_test_output_path(test_name=test_name) /
                            f'Test-AutoCCBDecisions_{test_name}_processed.xlsx'))

        # extract deviated item data
        item_id_deviated_re = re.search(
            r'New item id:\s*\"(\d+)\"', ccb_decision_df.iloc[0]['Executed Steps'])

        # check if new item id was found in executed steps
        self.assertTrue(item_id_deviated_re)

        # get items
        item_deviated = self._cb_server.get_item(
            int(item_id_deviated_re.group(1)))
        item_ch63 = self._cb_server.get_item(
            int(ccb_decision_df.iloc[0]['CH63-ItemId']))

        # check if item and deviated item contain correct module variants
        self.assertTrue(
            all('CH63' in module_variant
                for module_variant in item_ch63['Module Variant_pe']))
        self.assertTrue(
            all('SV62' in module_variant
                for module_variant in item_deviated['Module Variant_pe']))

        # check if comment contains required information
        self.assertTrue(
            ccb_decision_df.iloc[0]['CCB Participants'] in item_ch63['CCB_Decision'])
        self.assertTrue(
            ccb_decision_df.iloc[0]['CCB Rational'] in item_ch63['CCB_Decision'])

        # check if status is success
        self.assertEqual('SUCCESS', ccb_decision_df.iloc[0]['Status'])

        # check sync execution state changes
        self.__check_sync_execution_state(test_name=test_name)

        # clean up test artifacts
        self.__clean_output_path(test_name=test_name)

    def test_execute_decision_MULTIPLE_DECISIONS(self):
        """
        This test case tests the decision "MULTIPLE_DECISIONS"
        """
        test_name = 'MULTIPLE_DECISIONS'

        # prepare test
        decision_executor = self.__create_decision_executor(
            test_name=test_name)

        # execute decisions
        decision_executor.execute_decisions()

        # check results (ch63 item was updated with sv62 value)
        ccb_decision_df = self.__load_xlsx(
            data_file_path=(self.__get_test_output_path(test_name=test_name) /
                            f'Test-AutoCCBDecisions_{test_name}_processed.xlsx'))

        # information: CCB_Decision will not get checked for multiple decisions due to overwriting of this field.
        #              This will be checked in separate single decision tests.
        ######## CHECK DECISION 1: Sync with Porsche Database ########
        decision_idx = 0
        #   check if field was set correctly
        item_updated = self._cb_server.get_item(
            int(ccb_decision_df.iloc[decision_idx]['CH63-ItemId']))
        self.assertEqual(item_updated[ccb_decision_df.iloc[decision_idx]['CH63-FieldName']],
                         ccb_decision_df.iloc[decision_idx]['SV62-FieldValue'])

        #   check if status is success
        self.assertEqual(
            'SUCCESS', ccb_decision_df.iloc[decision_idx]['Status'])

        ######## CHECK DECISION 2: Sync with Porsche Database ########
        decision_idx = 1
        #   check if field was set correctly
        item_updated = self._cb_server.get_item(
            int(ccb_decision_df.iloc[decision_idx]['CH63-ItemId']))
        self.assertEqual(item_updated[ccb_decision_df.iloc[decision_idx]['CH63-FieldName']],
                         ccb_decision_df.iloc[decision_idx]['SV62-FieldValue'])

        #   check if status is success
        self.assertEqual(
            'SUCCESS', ccb_decision_df.iloc[decision_idx]['Status'])

        ######## CHECK DECISION 3: Sync with Porsche Database ########
        decision_idx = 2
        #   check if field was set correctly
        item_updated = self._cb_server.get_item(
            int(ccb_decision_df.iloc[decision_idx]['CH63-ItemId']))
        self.assertEqual(item_updated[ccb_decision_df.iloc[decision_idx]['CH63-FieldName']],
                         ccb_decision_df.iloc[decision_idx]['SV62-FieldValue'])

        #   check if status is success
        self.assertEqual(
            'SUCCESS', ccb_decision_df.iloc[decision_idx]['Status'])

        ######## CHECK DECISION 4: Mark entire requirement as Obsolete ########
        decision_idx = 3
        #   check if field was set correctly
        item_ch63 = self._cb_server.get_item(
            int(ccb_decision_df.iloc[decision_idx]['CH63-ItemId']))
        self.assertEqual(item_ch63.status, 'Obsolete')

        #   check if status is success
        self.assertEqual(
            'SUCCESS', ccb_decision_df.iloc[decision_idx]['Status'])

        ######## CHECK DECISION 5: Sync with Porsche Database ########
        decision_idx = 4
        #   check if field was set correctly
        item_updated = self._cb_server.get_item(
            int(ccb_decision_df.iloc[decision_idx]['CH63-ItemId']))
        self.assertEqual(item_updated[ccb_decision_df.iloc[decision_idx]['CH63-FieldName']],
                         ccb_decision_df.iloc[decision_idx]['SV62-FieldValue'])

        #   check if status is success
        self.assertEqual(
            'SUCCESS', ccb_decision_df.iloc[decision_idx]['Status'])

        ######## CHECK DECISION 6: Audi to deviate current requirement and create a new requirement ########
        decision_idx = 5
        # extract deviated item data
        item_id_deviated_re = re.search(
            r'New item id:\s*\"(\d+)\"', ccb_decision_df.iloc[decision_idx]['Executed Steps'])

        # check if new item id was found in executed steps
        self.assertTrue(item_id_deviated_re)

        # get items
        item_deviated = self._cb_server.get_item(
            int(item_id_deviated_re.group(1)))
        item_ch63 = self._cb_server.get_item(
            int(ccb_decision_df.iloc[decision_idx]['CH63-ItemId']))

        # check if item and deviated item contain correct module variants
        self.assertTrue(
            all('CH63' in module_variant
                for module_variant in item_ch63['Module Variant_pe']))
        self.assertTrue(
            all('SV62' in module_variant
                for module_variant in item_deviated['Module Variant_pe']))

        # check if status is success
        self.assertEqual('SUCCESS', ccb_decision_df.iloc[0]['Status'])

        ######## CHECK DECISION 7: Mark entire requirement as Obsolete ########
        decision_idx = 6
        #   check if field was set correctly
        item_ch63 = self._cb_server.get_item(
            int(ccb_decision_df.iloc[decision_idx]['CH63-ItemId']))
        self.assertEqual(item_ch63.status, 'Obsolete')

        #   check if status is success
        self.assertEqual(
            'SUCCESS', ccb_decision_df.iloc[decision_idx]['Status'])

        ######## CHECK DECISION 8: Sync with Porsche Database ########
        decision_idx = 7
        #   check if field was set correctly
        item_updated = self._cb_server.get_item(
            int(ccb_decision_df.iloc[decision_idx]['CH63-ItemId']))
        self.assertEqual(item_updated[ccb_decision_df.iloc[decision_idx]['CH63-FieldName']],
                         ccb_decision_df.iloc[decision_idx]['SV62-FieldValue'])

        #   check if status is success
        self.assertEqual(
            'SUCCESS', ccb_decision_df.iloc[decision_idx]['Status'])

        ######## CHECK DECISION 9: Sync with Audi-CH63-DAS-PROD-ECUS ########
        decision_idx = 8
        # check if status is skipped (TODO for now)
        self.assertEqual(
            'SKIPPED', ccb_decision_df.iloc[decision_idx]['Status'])

        # clean up test artifacts
        self.__clean_output_path(test_name=test_name)


if __name__ == '__main__':
    unittest.main()
