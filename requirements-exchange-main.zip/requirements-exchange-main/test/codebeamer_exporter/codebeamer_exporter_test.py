"""
This module provides test for CodebeamerExporter
"""
import unittest
import shutil
import os
import calmpy
from pathlib import Path
from openpyxl import load_workbook
from src.export.codebeamer_exporter import CodebeamerExporter
from src.export.codebeamer_exporter import EXPORT_TYPE

class TestCodebeamerExporter(unittest.TestCase):
    """
    Class for testing the CodebeamerExporter
    """

    def __get_test_config_path(self, test_name: str) -> Path:
        """
        Returns config path for given test

        :param test_name: name of test
        :type test_name: str
        :return: path to configs for given test
        :type Path
        """
        return self._test_data_base_path / ('test_' + str(test_name)) / 'configs'

    def __get_test_data_path(self, test_name: str) -> Path:
        """
        Returns data path for given test

        :param test_name: name of test
        :type test_name: str
        :return: path to data for given test
        :type Path
        """
        return self._test_data_base_path / ('test_' + str(test_name)) / 'data'

    def __get_test_output_path(self, test_name: str) -> Path:
        """
        Returns output path for given test

        :param test_name: name of test
        :type test_name: str
        :return: path to output for given test
        :type Path
        """
        return self._test_data_base_path / ('test_' + str(test_name)) / 'output'

    def __clean_output_path(self, test_name: str):
        """
        Removes all outputs created for specified tests

        :param test_name: name of test
        :type test_name: str
        """
        # remove output folder
        shutil.rmtree(self.__get_test_output_path(test_name=test_name))
        # create the folder
        os.makedirs(self.__get_test_output_path(test_name=test_name),
                    exist_ok=True)

    def setUp(self):
        """
        Initialize any variables or resources needed for the tests.
        """
        self._cb_instance = 'QS'
        self._test_data_base_path = Path(
            './test/test_data/codebeamer_exporter')

    def test_export_baseline_153648191(self):
        """
        This test case tests the codebeamer export of baseline with id 153648191
        """
        accuracy = 10000
        baseline = 153648191
        test_name = f'baseline_{baseline}'

        # initialize codebeamer exporter
        codebeamer_exporter = CodebeamerExporter(cb_instance=self._cb_instance,
                                                 tracker_ids_json=self.__get_test_config_path(
                                                     test_name=test_name) / 'tracker_ids_packaged.json',
                                                 export_report_template='data/export_report_template/Template_Export_Report.xlsx',
                                                 baseline=baseline,
                                                 output_dir_base=self.__get_test_output_path(test_name=test_name))

        # execute export
        output_dir = codebeamer_exporter.export()

        # extract time string
        time_str = str(output_dir.name).replace('export_', '')

        # check results - report
        # get name of files
        report_file = f'DAS-PROD-ECUS-ExportForME_{time_str}.xlsx'
        package_files = [
            {'file_path': output_dir / codebeamer_exporter.get_bundle_name_str(time_str=time_str,
                                                                               bundle=1),
             'size': int(40928746 / accuracy)},
            {'file_path': output_dir / codebeamer_exporter.get_bundle_name_str(time_str=time_str,
                                                                               bundle=2),
             'size': int(126438 / accuracy)},
            {'file_path': output_dir / codebeamer_exporter.get_bundle_name_str(time_str=time_str,
                                                                               bundle=3),
             'size': int(10569715 / accuracy)}
        ]

        # load the report template
        wb = load_workbook(output_dir / report_file)
        ws = wb.active

        # check baseline
        self.assertEqual(ws['C5'].value, baseline)

        # check dates
        self.assertEqual(ws['C6'].value, time_str)
        self.assertEqual(ws['C16'].value, time_str)
        self.assertEqual(ws['C26'].value, time_str)

        # check names
        self.assertEqual(ws['C7'].value, package_files[0]['file_path'].name)
        self.assertEqual(ws['C17'].value, package_files[1]['file_path'].name)
        self.assertEqual(ws['C27'].value, package_files[2]['file_path'].name)

        # check (all) item counts
        self.assertEqual(ws['D10'].value, 3012)
        self.assertEqual(ws['D11'].value, 2321)
        self.assertEqual(ws['D12'].value, 1010)
        self.assertEqual(ws['D13'].value, 179)
        self.assertEqual(ws['D14'].value, 381)

        self.assertEqual(ws['D20'].value, 220)
        self.assertEqual(ws['D21'].value, 300)
        self.assertEqual(ws['D22'].value, 593)
        self.assertEqual(ws['D23'].value, 515)
        self.assertEqual(ws['D24'].value, 81)

        self.assertEqual(ws['D30'].value, 262)
        self.assertEqual(ws['D31'].value, 809)
        self.assertEqual(ws['D32'].value, 189)
        self.assertEqual(ws['D33'].value, 489)
        self.assertEqual(ws['D34'].value, 193)
        self.assertEqual(ws['D35'].value, 26)

        # check (ch63) item counts
        self.assertEqual(ws['E10'].value, 80)
        self.assertEqual(ws['E11'].value, 2319)
        self.assertEqual(ws['E12'].value, 34)
        self.assertEqual(ws['E13'].value, 11)
        self.assertEqual(ws['E14'].value, 172)

        self.assertEqual(ws['E20'].value, 1)
        self.assertEqual(ws['E21'].value, 0)
        self.assertEqual(ws['E22'].value, 86)
        self.assertEqual(ws['E23'].value, 2)
        self.assertEqual(ws['E24'].value, 18)

        self.assertEqual(ws['E30'].value, 203)
        self.assertEqual(ws['E31'].value, 378)
        self.assertEqual(ws['E32'].value, 189)
        self.assertEqual(ws['E33'].value, 0)
        self.assertEqual(ws['E34'].value, 192)
        self.assertEqual(ws['E35'].value, 0)

        # check results - exports / .regifz
        # check sizes of exports
        for package_file in package_files:
            self.assertEqual(package_file['size'], int(
                os.path.getsize(package_file['file_path']) / accuracy))

        # clean up test artifacts
        self.__clean_output_path(test_name=test_name)

    def test_remove_supplier_feedback_fields_SUPPLIER_MOBILEYE(self):
        """
        This test case tests the function "remove_supplier_feedback_fields" of codebeamer export for export type SUPPLIER_MOBILEYE
        """
        test_name = f'remove_supplier_feedback_fields_SUPPLIER_MOBILEYE'

        supplier_list = ['Valeo', 'Continental', 'Magna', 'Aptiv']

        # initialize codebeamer exporter
        codebeamer_exporter = CodebeamerExporter(cb_instance=self._cb_instance,
                                                 tracker_ids_json=self.__get_test_config_path(
                                                     test_name=test_name) / 'tracker_ids_packaged.json',
                                                 export_report_template='data/export_report_template/Template_Export_Report.xlsx',
                                                 export_type=EXPORT_TYPE.SUPPLIER_MOBILEYE,
                                                 baseline=0,
                                                 output_dir_base=self.__get_test_output_path(test_name=test_name))

        # extract all fields that get exported
        tracker_field_list = codebeamer_exporter.get_tracker_field_list(tracker=calmpy.Server(url=self._cb_instance).get_tracker(tracker_id=92348129))

        # check if other supplier names are included in exported fields
        for supplier in supplier_list:
            for field in tracker_field_list:
                self.assertFalse(supplier in field)

        # clean up test artifacts
        self.__clean_output_path(test_name=test_name)


    def test_remove_supplier_feedback_fields_SUPPLIER_VALEO(self):
        """
        This test case tests the function "remove_supplier_feedback_fields" of codebeamer export for export type SUPPLIER_VALEO
        """
        test_name = f'remove_supplier_feedback_fields_SUPPLIER_VALEO'

        supplier_list = ['MobilEye', 'Continental', 'Magna', 'Aptiv']

        # initialize codebeamer exporter
        codebeamer_exporter = CodebeamerExporter(cb_instance=self._cb_instance,
                                                 tracker_ids_json=self.__get_test_config_path(
                                                     test_name=test_name) / 'tracker_ids_packaged.json',
                                                 export_report_template='data/export_report_template/Template_Export_Report.xlsx',
                                                 export_type=EXPORT_TYPE.SUPPLIER_VALEO,
                                                 baseline=0,
                                                 output_dir_base=self.__get_test_output_path(test_name=test_name))

        # extract all fields that get exported
        tracker_field_list = codebeamer_exporter.get_tracker_field_list(tracker=calmpy.Server(url=self._cb_instance).get_tracker(tracker_id=92348129))

        # check if other supplier names are included in exported fields
        for supplier in supplier_list:
            for field in tracker_field_list:
                self.assertFalse(supplier in field)

        # clean up test artifacts
        self.__clean_output_path(test_name=test_name)

    def test_remove_supplier_feedback_fields_SUPPLIER_CONTINENTAL(self):
        """
        This test case tests the function "remove_supplier_feedback_fields" of codebeamer export for export type SUPPLIER_CONTINENTAL
        """
        test_name = f'remove_supplier_feedback_fields_SUPPLIER_CONTINENTAL'

        supplier_list = ['MobilEye', 'Valeo', 'Magna', 'Aptiv']

        # initialize codebeamer exporter
        codebeamer_exporter = CodebeamerExporter(cb_instance=self._cb_instance,
                                                 tracker_ids_json=self.__get_test_config_path(
                                                     test_name=test_name) / 'tracker_ids_packaged.json',
                                                 export_report_template='data/export_report_template/Template_Export_Report.xlsx',
                                                 export_type=EXPORT_TYPE.SUPPLIER_CONTINENTAL,
                                                 baseline=0,
                                                 output_dir_base=self.__get_test_output_path(test_name=test_name))

        # extract all fields that get exported
        tracker_field_list = codebeamer_exporter.get_tracker_field_list(tracker=calmpy.Server(url=self._cb_instance).get_tracker(tracker_id=92348129))

        # check if other supplier names are included in exported fields
        for supplier in supplier_list:
            for field in tracker_field_list:
                self.assertFalse(supplier in field)

        # clean up test artifacts
        self.__clean_output_path(test_name=test_name)

    def test_remove_supplier_feedback_fields_SUPPLIER_MAGNA(self):
        """
        This test case tests the function "remove_supplier_feedback_fields" of codebeamer export for export type SUPPLIER_MAGNA
        """
        test_name = f'remove_supplier_feedback_fields_SUPPLIER_MAGNA'

        supplier_list = ['MobilEye', 'Valeo', 'Continental', 'Aptiv']

        # initialize codebeamer exporter
        codebeamer_exporter = CodebeamerExporter(cb_instance=self._cb_instance,
                                                 tracker_ids_json=self.__get_test_config_path(
                                                     test_name=test_name) / 'tracker_ids_packaged.json',
                                                 export_report_template='data/export_report_template/Template_Export_Report.xlsx',
                                                 export_type=EXPORT_TYPE.SUPPLIER_MAGNA,
                                                 baseline=0,
                                                 output_dir_base=self.__get_test_output_path(test_name=test_name))

        # extract all fields that get exported
        tracker_field_list = codebeamer_exporter.get_tracker_field_list(tracker=calmpy.Server(url=self._cb_instance).get_tracker(tracker_id=92348129))

        # check if other supplier names are included in exported fields
        for supplier in supplier_list:
            for field in tracker_field_list:
                self.assertFalse(supplier in field)

        # clean up test artifacts
        self.__clean_output_path(test_name=test_name)

    def test_remove_supplier_feedback_fields_SUPPLIER_APTIV(self):
        """
        This test case tests the function "remove_supplier_feedback_fields" of codebeamer export for export type SUPPLIER_APTIV
        """
        test_name = f'remove_supplier_feedback_fields_SUPPLIER_APTIV'

        supplier_list = ['MobilEye', 'Valeo', 'Continental', 'Magna']

        # initialize codebeamer exporter
        codebeamer_exporter = CodebeamerExporter(cb_instance=self._cb_instance,
                                                 tracker_ids_json=self.__get_test_config_path(
                                                     test_name=test_name) / 'tracker_ids_packaged.json',
                                                 export_report_template='data/export_report_template/Template_Export_Report.xlsx',
                                                 export_type=EXPORT_TYPE.SUPPLIER_APTIV,
                                                 baseline=0,
                                                 output_dir_base=self.__get_test_output_path(test_name=test_name))

        # extract all fields that get exported
        tracker_field_list = codebeamer_exporter.get_tracker_field_list(tracker=calmpy.Server(url=self._cb_instance).get_tracker(tracker_id=92348129))

        # check if other supplier names are included in exported fields
        for supplier in supplier_list:
            for field in tracker_field_list:
                self.assertFalse(supplier in field)

        # clean up test artifacts
        self.__clean_output_path(test_name=test_name)

if __name__ == '__main__':
    unittest.main()
