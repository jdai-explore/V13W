import unittest
import os
from pathlib import Path
import pandas as pd
from datetime import date
from openpyxl import load_workbook

# Import the necessary classes from the src.creation_of_change_log module
from src.change_log.creation_of_change_log import CreationOfChangeLog, ItemMappingCreator

class TestCreationOfChangeLogAndItemMappingCreator(unittest.TestCase):

    def setUp(self):
        # Define baselines for testing
        self.cb_server = 'QS'
        self.tracker_input = 'input_files\\tracker_ids.xlsx'
        self.change_log_tracker_mapping = 'input_files\\change_log_tracker_mapping.json'
        self.tracker_mapping = Path('input_files\\ch63_to_sv62_tracker_mapping.json')
        self.field_mapping = Path('input_files\\sv62_to_ch63_field_mapping.json')
        self.change_log_field_mapping = 'input_files\\change_log_field_mapping.json'
        self.output_file = 'AutoModifieditems'
        self.days_before_modification = 14
        self.output_dir = Path('.') / 'testing' / 'test_output'

        # Initialize objects
        self.creation_of_change_log = CreationOfChangeLog(
            cb_server=self.cb_server,
            tracker_input=self.tracker_input,
            change_log_tracker_mapping=self.change_log_tracker_mapping,
            tracker_mapping=self.tracker_mapping,
            field_mapping=self.field_mapping,
            change_log_field_mapping=self.change_log_field_mapping,
            output_file=self.output_file,
            days_before_modification=self.days_before_modification,
            output_dir=self.output_dir)

        self.item_mapping_creator = ItemMappingCreator(
            cb_server=self.cb_server,
            tracker_mapping=self.tracker_mapping,
            field_mapping=self.field_mapping,
            output_dir=self.output_dir,
            baseline_instance1='141509108',
            baseline_instance2='143333714')

        # Run the function
        self.expected_output_path = self.item_mapping_creator.create_item_mappings()

    def tearDown(self):
        self.output_dir = None

    def test_01_create_excel_file(self):
        # Define the file name
        file_name = "AutoModifieditems"

        # Run the function
        self.creation_of_change_log.create_excel_file(file_name)

        # Construct the expected file name with date
        today = date.today()
        expected_file_name = f"{today}-{file_name}.xlsx"

        # Check if the file exists
        self.assertTrue(Path(expected_file_name).exists(), f"Excel file '{expected_file_name}' not found")

        # Load the created Excel file
        df = pd.read_excel(expected_file_name, sheet_name='MODIFIED_ATTRIBUTES')

        # Check if the columns match the expected columns
        expected_columns = [
            "CH63-TrackerID", "CH63-TrackerName", "CH63-Baseline", "CH63-ItemId", "CH63-ItemName",
            "CH63-FieldID", "CH63-FieldName", "CH63-FieldValue", "CH63-Description",
            "SV62-TrackerID", "SV62-TrackerName", "SV62-Baseline", "SV62-ItemId", "SV62-ItemName",
            "SV62-FieldID", "SV62-FieldName", "SV62-FieldValue", "SV62-Description"
        ]
        self.assertListEqual(df.columns.tolist(), expected_columns, "Excel columns do not match expected columns")
    
    def test_02_add_sheets_to_existing_file(self):
        # Define the file name
        file_name = "AutoModifieditems"
        today = date.today()
        expected_file_name = f"{today}-{file_name}.xlsx"

        # Run the function
        self.creation_of_change_log.add_sheets_to_existing_file(expected_file_name, self.output_dir)

        # Load the updated Excel file using pandas
        df_empty_ch63 = pd.read_excel(expected_file_name, sheet_name='EMPTY_CH63')
        df_empty_sv62 = pd.read_excel(expected_file_name, sheet_name='EMPTY_SV62')

        # Check if the new sheets are added
        wb = load_workbook(expected_file_name)
        self.assertIn('EMPTY_CH63', wb.sheetnames, "Sheet 'EMPTY_CH63' not found in the Excel file")
        self.assertIn('EMPTY_SV62', wb.sheetnames, "Sheet 'EMPTY_SV62' not found in the Excel file")

        # Verify that the sheets contain data
        self.assertGreater(df_empty_ch63.shape[0], 1, "Sheet 'EMPTY_CH63' is empty")
        self.assertGreater(df_empty_sv62.shape[0], 1, "Sheet 'EMPTY_SV62' is empty")

        # Check data
        self.assertEqual(df_empty_ch63.shape[0], 431, "Sheet 'EMPTY_CH63' does not have 431 rows")
        self.assertEqual(df_empty_sv62.shape[0], 468, "Sheet 'EMPTY_SV62' does not have 468 rows")

if __name__ == '__main__':
    unittest.main()
