"""
This module provides test for ME_feedback
"""
import calmpy
import calmpy.exceptions
import unittest
from pathlib import Path
import json
from src.update_ME_feedback.update_ME_feedback import UpdateMEFeedback
import sys
import time
from datetime import datetime


# Defined all use cases
USE_CASES = [
    {"name": "UC1_Released->Released_Agreed", "status": "Released", "m2a": "Agreed"},
    {"name": "UC2_Released->Released_NotAgreed", "status": "Released", "m2a": "Not agreed"},
    {"name": "UC3_NotReleased->NotReleased_Agreed", "status": "In Review", "m2a": "Agreed"},
    {"name": "UC4_NotReleased->NotReleased_NotAgreed", "status": "Obsolete", "m2a": "Not agreed"},
    {"name": "UC5_Released->Released_Agreed_Transition", "status": "Released", "m2a": "Agreed"},
    {"name": "UC6_Released->Released_NotAgreed_Transition", "status": "Released", "m2a": "Not agreed"},
    {"name": "UC7_NotReleased->NotReleased_Agreed_Transition", "status": "Re-evaluation", "m2a": "Agreed"},
    {"name": "UC8_NotReleased->NotReleased_NotAgreed_Transition", "status": "Unset", "m2a": "Not agreed"}, #Unset
    {"name": "UC9_NotReleased->Released_Empty", "status": "Re-evaluation", "m2a": "Empty"},
    {"name": "UC10_NotReleased->Released_NotAgreed", "status": "Re-evaluation", "m2a": "Not agreed"},
    {"name": "UC11_Released->NotReleased_Empty", "status": "Released", "m2a": "Empty"},
    {"name": "UC12_Released->NotReleased_NotAgreed", "status": "Released", "m2a": "Not agreed"},
    {"name": "UC13_Released->NotReleased_AgreedWithComment", "status": "Released", "m2a": "Agreed with comment"},
    {"name": "UC14_Released->NotReleased_ToBeClarified", "status": "Released", "m2a": "To be clarified"},
    {"name": "UC15_Released->NotReleased_Discarded", "status": "Released", "m2a": "Discard deployed"},
]


class TestUpdateMEFeedback(unittest.TestCase):
    """
    Class for validating ME feedback to update in codebeamer.
    """
    def setUp(self):
        """
        Setup Codebeamer connection and required input paths for tests.
        """
        self._cb_server = calmpy.Server(url='QS', readonly=False)
        # Tracker id
        self._test_tracker_id = 92348129
        # get parent id
        self._test_parent_item = self.__parent_id()
        # Item ids
        self.created_item_ids = []

    def __parent_id(self) -> calmpy.Item:
        '''
        Returns test parent (item in codebeamer where data will get added), if it does not exists it will create it
        :return: test parent item in codebeamer
        :type calmpy.Item
        '''
        test_parent_id = next((item for item in self._cb_server.get_tracker(self._test_tracker_id).get_items()
                               if
                               item.name == 'FOR INTERNAL TESTS ONLY - SHALL BE DELETED' and item['Type'] == 'Folder'),
                              None)
        # check if test parent item exists
        if test_parent_id is None:
            # create test parent item
            test_parent_id = self._cb_server.get_tracker(self._test_tracker_id).create_item(
                fields={'Summary': 'FOR INTERNAL TESTS ONLY - SHALL BE DELETED',
                        'Type': 'Folder'})
        return test_parent_id

    def __update_parent(self, parent_id: int, item_id: int) -> bool:
        '''
        Updates parent item that specified id is child
        :param parent_id: id of item to insert child to
        :type parent_id: str
        :param item_id: child to add
        :type item_id: str
        :return: status of execution (True if success, else False)
        :type bool
        '''
        # url of children for parent
        children_url = f'{self._cb_server.query.SWAGGER_URL_V3}/items/' + \
                       f'{int(parent_id)}/children'

        # get all current item children
        response = self._cb_server.session.make_paged_requests(request_url=children_url,
                                                               request_type='GET',
                                                               is_readonly_operation=True,
                                                               entries=500)

        # check if its more than 1 page
        if response.total > 1:
            print(f'parent {parent_id} has more than 500 children.' +
                  f' Hierarchy of item {item_id} will be ignored')
            return False

        # extract children list
        parent_child_refs = response.all[0].content['itemRefs']

        # convert to list of children ids
        existing_children_ids = [children['id']
                                 for children in parent_child_refs]

        # check if item is already a child
        if item_id not in existing_children_ids:
            # insert child
            parent_child_refs.append(
                {'id': int(item_id), 'type': 'TrackerItemReference'})

            # transform to query data
            children_data = {'children': parent_child_refs}

            # update hierarchy
            try:
                response = self._cb_server.session.make_single_request(request_url=children_url,
                                                                       request_type='PUT',
                                                                       data=children_data)
            except ...:
                return False
            return True
        return True

    def __insert_item_for_parent(self) -> calmpy.Item:
        '''
        Creates item with provided data for a specified parent id
        :param parent_id: id of item to insert child to
        :type parent_id: str
        :param item_dict: data of item to add
        :type item_dict: dict
        :return: item that got added
        :type calmpy.Item
        '''
        # prepare minimal data for items
        for uc in USE_CASES:
            # for Unset use case - for type information the status would set to Unset (n/a, None)
            if 'UC8_' in uc['name']:
                item_dict = {
                    'Description': uc['name'],
                    'Type': 'Information',
                    'Status Audi to Mobileye_pe': 'To evaluate',
                    'Status Mobileye to Audi_pe': uc['m2a'],
                    'Comment Audi to Mobileye_pe': 'Test comment'
                }
            else:
                item_dict = {
                    'Description': uc['name'],
                    'Status Audi to Mobileye_pe': 'To evaluate',
                    'Status Mobileye to Audi_pe': uc['m2a'],
                    'Comment Audi to Mobileye_pe': 'Test comment'
                }
            parent_id = self._test_parent_item.id
            parent = self._cb_server.get_item(parent_id)

            try:
                new_item = self._cb_server.get_tracker(
                    int(parent.tracker.id)).create_item(fields=item_dict)
                self.created_item_ids.append(new_item.id)
                self.__update_parent(parent_id=parent_id, item_id=new_item.id)
                # State transitions based on use cases
                if uc['status'] == 'Released':
                    new_item['status'] = 'Obsolete'
                    new_item.update_fields()
                    new_item['status'] = 'Re-evaluation'
                    new_item.update_fields()
                    new_item['status'] = 'Released'
                    new_item.update_fields()
                elif uc['status'] == 'In Review':
                    new_item['status'] = 'In Review'
                    new_item.update_fields()
                elif uc['status'] == 'Obsolete':
                    new_item['status'] = 'Obsolete'
                    new_item.update_fields()
                elif uc['status'] == 'Re-evaluation':
                    new_item['status'] = 'Obsolete'
                    new_item.update_fields()
                    new_item['status'] = 'Re-evaluation'
                    new_item.update_fields()

            except calmpy.exceptions.ServerError as e:
                print(e)
                print(f'Problem in creating item for parent {parent_id} with data: {item_dict}')

    def __create_baseline(self):
        """
        Creates a baseline using the provided baseline data.
        """
        try:
            print("Creating baseline....")
            tracker = self._cb_server.get_tracker(self._test_tracker_id)
            # Create a baseline
            baseline = tracker.create_baseline(name="Test update ME feedback Baseline",
                                                       description="Baseline for testing update ME feedback")

            if baseline is not None:
                print("Baseline created successfully.")
                return baseline.id
            else:
                print("Failed to create baseline.")
                sys.exit(1)
        except calmpy.exceptions.ServerError as e:
            print(f"Error creating baseline: {e}")
            sys.exit(1)

    def __create_item_ids_json(self):
        json_path = Path("test_item_ids_json.json")
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump({"item_ids": self.created_item_ids}, f, indent=4)
        return json_path

    def __simulate_items_transitions(self):
        # perform transitions for use cases UC5-UC15
        # no status transition for UC8, when it's an information item, we cannot change status from Unset to any other field value
        for index, item_id in enumerate(self.created_item_ids[4:]): #first 4 items are for use case 1
            uc = USE_CASES[index + 4]
            original_status = uc['status']
            item = self._cb_server.get_item(item_id)

            if original_status == "Released":
                if uc['name'].startswith("UC5") or uc['name'].startswith("UC6"):
                    # Re-released scenario: Released -> in Progress -> Obsolete -> Re-evaluation -> Released
                    item['Status'] = "in Progress"
                    item.update_fields()
                    time.sleep(1)
                    item['Status'] = "Obsolete"
                    item.update_fields()
                    time.sleep(1)
                    item['Status'] = "Re-evaluation"
                    item.update_fields()
                    time.sleep(1)
                    item['Status'] = "Released"
                    item.update_fields()
                    time.sleep(1)
                else:
                    # Released -> Not Released
                    item['Status'] = "in Progress"
                    item.update_fields()
                    time.sleep(1)

            elif original_status == 'Re-evaluation':
                #Not Released -> Released
                item['Status'] = "Released"
                item.update_fields()
                time.sleep(1)

            elif original_status == 'Obsolete':
                # Not Released -> Not Released
                item['Status'] = 'Re-evaluation'
                item.update_fields()
                time.sleep(1)

            elif original_status == 'in Progress':
                # Not Released -> Not Released
                item['Status'] = 'In Review'
                item.update_fields()
                time.sleep(1)

    def __check_transition(self, cb_server, item_id, baseline_date):
        # fetch item history
        history_url = f'{cb_server.query.SWAGGER_URL_V3}/items/{item_id}/history'
        response = cb_server.session.make_single_request(request_url=history_url, request_type='GET',
                                                         is_readonly_operation=True)

        for version in response.get('versions', []):
            modified = version.get("modifiedAt")
            if modified:
                modified = datetime.fromisoformat(modified)
            if modified > baseline_date:
                for change in version.get('changes', []):
                    if change.get('name') == 'Status':
                        return True
        return False

    def test_update_feedback_for_all_status_transitions(self):
        """
        Run update_feedback() and verify:n
        - No transitions (use case 1)
        - Transitions (use case 2)
        Each case splits logic by M2A being 'Agreed' vs other values.
        """
        self.__insert_item_for_parent()
        item_json = self.__create_item_ids_json()
        baseline_id = self.__create_baseline()
        self.__simulate_items_transitions()
        time.sleep(5)

        self.updater = UpdateMEFeedback(
            cb_instance="QS",
            tracker_ids_json=Path('./test_data/ME_feedback_update/tracker_ids_json.json'),  # not used since item_ids_json is given
            item_ids_json=item_json,
            baseline=baseline_id
        )

        self.updater.update_feedback()
        items_state_current = {item.id: item for item in
                                self._cb_server.get_items(item_ids=self.created_item_ids)}
        items_state_baseline = {item.id: item for item in
                                self._cb_server.get_items(item_ids=self.created_item_ids, baseline=baseline_id)}

        for item_id in self.created_item_ids:
            current_item = items_state_current.get(item_id)
            baseline_item = items_state_baseline.get(item_id)

            transitioned = self.__check_transition(self._cb_server, item_id,
                                                         baseline_date=baseline_item.modifiedAt)

            baseline_status = baseline_item['Status']
            current_status = current_item['Status']
            me_to_audi = baseline_item['Status Mobileye to Audi_pe']
            audi_to_me = current_item['Status Audi to Mobileye_pe']
            comment = current_item['Comment Audi to Mobileye_pe']

            if not transitioned:
                # Use case 1: No transition (same as baseline)
                print('No transition ...', item_id)
                if baseline_status == current_status:
                    if baseline_status == 'Released':
                        if me_to_audi == "Agreed":
                            self.assertEqual(audi_to_me, "Accepted")
                            self.assertEqual(comment or "", "")
                        elif me_to_audi == "Not agreed":
                            self.assertEqual(audi_to_me, "To evaluate")
                    elif baseline_status in self.updater.NOT_RELEASED_STATUS:
                        self.assertEqual(audi_to_me, "To evaluate")

            else:
                # Use case 2: Transition - changes in history
                # Released -> Released
                print('transition occurred...', item_id)
                if baseline_status == "Released" and current_status == "Released":
                    if me_to_audi == "Agreed":
                        self.assertEqual(audi_to_me, "To evaluate")
                        self.assertEqual(comment, "To Re-evaluate")
                    elif me_to_audi == "Not agreed":
                        self.assertEqual(comment, "To Re-evaluate")
                # Not Released -> Not Released
                elif baseline_status in self.updater.NOT_RELEASED_STATUS and current_status in self.updater.NOT_RELEASED_STATUS:
                    self.assertEqual(audi_to_me, "To evaluate")
                # Released -> Not Released
                elif baseline_status == "Released" and current_status in self.updater.NOT_RELEASED_STATUS:
                    if me_to_audi in ['Empty', 'Not agreed', 'Agreed with comment', 'To be clarified', 'Discard deployed']:
                        self.assertEqual(audi_to_me, "To evaluate")
                # Not Released -> Released
                elif baseline_status in self.updater.NOT_RELEASED_STATUS and current_status == "Released":
                    if me_to_audi == "Empty":
                        self.assertEqual(comment, "To Re-evaluate")
                    else:
                        self.assertEqual(audi_to_me, "To evaluate")

if __name__ == "__main__":
    unittest.main()

