"""
This module provides test for CodebeamerImport
"""
import unittest
import calmpy
from pathlib import Path
import calmpy.exceptions
import time
import sys
from src.import_reqif.codebeamer_import import CodebeamerImport

class TestCodebeamerImport(unittest.TestCase):
    """
    Class for testing the CodebeamerImport.
    """

    def setUp(self):
        """
        Initialize any variables or resources needed for the tests.
        """
        # Codebeamer instance
        self._cb_server = calmpy.Server(url='QS', readonly=False)
        # Tracker id 
        self._test_tracker_id = 92348129
        # project id
        self.project_id = 1329
        # get parent id
        self._test_parent_item = self.__parent_id()
        # get the current time
        self._current_time = time.localtime()
        # format the current time
        self._formatted_time = time.strftime("%Y-%b-%d", self._current_time)
        self._test_data_base_path = Path('./test_data/codebeamer_import')

    def __get_test_output_path(self):
        """
        Returns output path for given test
        :return: path to output for given import
        :type Path
        """

        parent_dir = Path.cwd().parent
        output_path = parent_dir / self._test_data_base_path
        output_path.mkdir(parents=True, exist_ok=True)
        return output_path

    def __parent_id(self) -> calmpy.Item:
        '''
        Returns test parent (item in codebeamer where data will get added), if it does not exists it will create it
        :return: test parent item in codebeamer
        :type calmpy.Item
        '''
        test_parent_id = next((item for item in self._cb_server.get_tracker(self._test_tracker_id).get_items()
                               if item.name == 'FOR INTERNAL TESTS ONLY - SHALL BE DELETED' and item['Type'] == 'Folder'), None)
        # check if test parent item exists
        if test_parent_id is None:
            # create test parent item
            test_parent_id = self._cb_server.get_tracker(self._test_tracker_id).create_item(fields={'Summary': 'FOR INTERNAL TESTS ONLY - SHALL BE DELETED',
                                                                                                    'Type': 'Folder'})
        return test_parent_id

    def __update_parent(self, parent_id: int, item_id: int) -> bool:
        '''
        Updates parent item that specified id is child
        :param parent_id: id of item to insert child to
        :type parent_id: str
        :param item_id: child to add
        :type item_id: str
        :return: status of execution (True if success, else False)
        :type bool
        '''
        # url of children for parent
        children_url = f'{self._cb_server.query.SWAGGER_URL_V3}/items/' + \
                       f'{int(parent_id)}/children'

        # get all current item children
        response = self._cb_server.session.make_paged_requests(request_url=children_url,
                                                               request_type='GET',
                                                               is_readonly_operation=True,
                                                               entries=500)

        # check if its more than 1 page
        if response.total > 1:
            print(f'parent {parent_id} has more than 500 children.' +
                  f' Hierarchy of item {item_id} will be ignored')
            return False

        # extract children list
        parent_child_refs = response.all[0].content['itemRefs']

        # convert to list of children ids
        existing_children_ids = [children['id']
                                 for children in parent_child_refs]

        # check if item is already a child
        if item_id not in existing_children_ids:
            # insert child
            parent_child_refs.append(
                {'id': int(item_id), 'type': 'TrackerItemReference'})

            # transform to query data
            children_data = {'children': parent_child_refs}

            # update hierarchy
            try:
                response = self._cb_server.session.make_single_request(request_url=children_url,
                                                                       request_type='PUT',
                                                                       data=children_data)
            except ...:
                return False
            return True
        return True

    def __insert_item_for_parent(self) -> calmpy.Item:
        '''
        Creates item with provided data for a specified parent id
        :param parent_id: id of item to insert child to
        :type parent_id: str
        :param item_dict: data of item to add
        :type item_dict: dict
        :return: item that got added
        :type calmpy.Item
        '''
        # prepare minimal data for items

        item_dict = {
            'Description': 'Test import Reqif in script'
        }
        parent_id = self._test_parent_item.id
        parent = self._cb_server.get_item(parent_id)

        try:
            new_item = self._cb_server.get_tracker(
                int(parent.tracker.id)).create_item(fields=item_dict)
        except calmpy.exceptions.ServerError as e:
            print(e)
            print(f'Problem in creating item for parent {
            parent_id} with data: {item_dict}')

        status = self.__update_parent(parent_id=parent_id, item_id=new_item.id)

        # change field values
        new_item['Status Mobileye to Audi_pe'] = 'Empty'
        new_item['Comment Mobileye to Audi_pe'] = 'Comment for testing'
        new_item['Foreign ID_Polarion_pe'] = 'Test'
        new_item.update_fields()
        return new_item if status else None

    def __get_tracker_view(self):
        '''
        This functions returns id and name of tracker view containing include string
        :return: int, str (id, name)
        '''
        # initialize codebeamer server
        cb = self._cb_server
        include = 'Import Reqif Testcases'

        # prepare request
        request_url = f"{cb.URL}/api/v3/trackers/{self._test_tracker_id}/reports"

        # request reports from server
        reports = cb.session.make_single_request(
            request_type="GET", request_url=request_url)

        # check response
        filtered_reports = [
            report for report in reports if include in report['name']]

        if len(filtered_reports) > 1:
            print(f'Found multiple views with names including "{include}", will take {filtered_reports[0]}')

        view = filtered_reports[0] if filtered_reports else None

        return view.get('id', None) if view is not None else None, view.get('name', None) if view is not None else None


    def __export_reqif(self, project_name: str = 'DAS-PROD-ECUS'):
        '''
        This functions exports given trackers from specified project as a single reqif
        :param project_name: id of project to export trackers from
        :type project_name: id
        :return: reqif data
        '''

        # create tracker export configs
        tracker_export_configs = []
        tracker = self._cb_server.get_tracker(tracker_id=self._test_tracker_id)
        print(f'\tTracker Name: {tracker.name}')
        # get correct view for tracker
        view_id, view_name = self.__get_tracker_view()
        print(f'\tView Name: {view_name} View Id: {view_id}')

        if view_name is None or view_id is None:
            sys.exit(f'tracker {tracker.name} (id: {self._test_tracker_id}) has no view which name includes "{view_name}"!')

        # generate reqif export config based on view
        field_list = ['Status Mobileye to Audi_pe', 'Comment Mobileye to Audi_pe', 'Foreign ID_Polarion_pe']
        reqif_export_config, _ = tracker.get_reqif_export_config(tracker_field_list=field_list, tracker_view=view_id)
        tracker_export_configs.append(reqif_export_config)

        # export reqif
        reqif = self._cb_server.get_project(project=project_name).export_as_reqif(
        destination=f'Test_Export_{tracker.name}_{self._formatted_time}',
        tracker_list=tracker_export_configs)

        save_reqif = self.__get_test_output_path() / f'test_export_{tracker.name}.reqifz'

        # save reqif data to .reqifz file
        with open(save_reqif, "wb") as f:
            f.write(reqif.getbuffer())
        return save_reqif

    def test_import_reqif_to_project(self):
        '''
        Test method to import a reqif file to a project.
        This method tests the import_reqif_to_project method of CodebeamerImport.
        '''
        item = self.__insert_item_for_parent()
        # field values before exporting...!
        status_me_to_audi = item['Status Mobileye to Audi_pe']
        comment_me_to_audi = item['Comment Mobileye to Audi_pe']
        foreign_id_polarion = item['Foreign ID_Polarion_pe']

        self.cb_import = CodebeamerImport(
            cb_server=self._cb_server.URL,
            reqif_file_path=self.__export_reqif(),
            mapping_file=str(self.__get_test_output_path() / 'DAS-PROD-ECUS.json'),
            project_id=self.project_id,
            output_dir_base=str(self.__get_test_output_path()))

        # updating/changing field values before importing...!
        item['Status Mobileye to Audi_pe'] = 'Agreed'
        item['Comment Mobileye to Audi_pe'] = 'Test Comment'
        item['Foreign ID_Polarion_pe'] = 'Testing'
        item.update_fields()

        # Import the reqif file to the project
        result = self.cb_import.import_reqif_to_project()
        print('...', result)

        # field values after importing...!
        imported_item = self._cb_server.get_item(item_id=item.id)
        status_me_to_audi_ = imported_item['Status Mobileye to Audi_pe']
        comment_me_to_audi_ = imported_item['Comment Mobileye to Audi_pe']
        foreign_id_polarion_ = imported_item['Foreign ID_Polarion_pe']

        if not result or not any(result.get("result", [])):
            print("Imported but import of Reqif has not changed anything. Please check if the provided file is correct.")
            self.assertEqual(result, {'result': [[]]})
        else:
            # check field values updated after import with manually updated field values before import
            tracker_result = result['result'][0][0]
            updated_items = tracker_result['items']['updatedItems']
            for item in updated_items:
                print(f"Item ID: {item['id']}")
                for change in item['changes']:
                    if change['fieldName'] == 'Status Mobileye to Audi_pe':
                        old_value = change['oldValue']
                        new_value = change['newValue']
                        self.assertNotEqual(old_value, new_value)

                    if change['fieldName'] == 'Comment Mobileye to Audi_pe':
                        old_value = change['oldValue']
                        new_value = change['newValue']
                        self.assertNotEqual(old_value, new_value)

                    if change['fieldName'] == 'Foreign ID_Polarion_pe':
                        old_value = change['oldValue']
                        new_value = change['newValue']
                        self.assertNotEqual(old_value, new_value)

            # check the new updated field values after import with old values before export
            self.assertEqual(status_me_to_audi_, status_me_to_audi)
            self.assertEqual(comment_me_to_audi_, comment_me_to_audi)
            self.assertEqual(foreign_id_polarion_, foreign_id_polarion)

if __name__ == '__main__':
    unittest.main()
