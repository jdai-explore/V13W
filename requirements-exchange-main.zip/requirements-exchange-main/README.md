# Requirement Exchange Process
The Requirement Exchange Process is a process to synchronize requirements with other parties and share and align on them with and suppliers.
## CCB-Workflow
### Description
The CCB-Workflow is the process to synchronize CH63/Audi requirements with SV62/PAG.
### Process
#### Start
- Workflow: [start_requirement_exchange_process.yml](.github/workflows/start_requirement_exchange_process.yml)
- Trigger: https://git.hub.vwgroup.com/CH-ECU/requirements-exchange/actions/workflows/start_requirement_exchange_process.yml
- Inputs:
    - None
- Outputs:
    - https://jfrog.hub.vwgroup.com/artifactory/checu-reqex-generic-internal/change_history/
    - https://jfrog.hub.vwgroup.com/artifactory/checu-reqex-generic-internal/change_log/
#### Decision Making
- Workflow: [execute_ccb_decisions.yml](.github/workflows/execute_ccb_decisions.yml)
- Trigger: MANUAL PROCESS BY CCB
- Inputs:
    - [timestr]-change_log.xlsx (OUTPUT of Start)
- Outputs:
    - LOCAL file (.xlsx file next to CCB_GUI.exe)
#### Decision Execution
- Workflow:
- Trigger: Upload to https://jfrog.hub.vwgroup.com/artifactory/checu-reqex-generic-internal/ccb_decisions_inbox/
- Inputs:
    - OUTPUT of Decision Making
- Outputs:
    - https://jfrog.hub.vwgroup.com/artifactory/checu-reqex-generic-internal/ccb_decisions/

## Export-Workflow
- Workflow: [codebeamer_export.yml](.github/workflows/codebeamer_export.yml)
- Trigger: https://git.hub.vwgroup.com/CH-ECU/requirements-exchange/actions/workflows/codebeamer_export.yml
- Inputs:
    - None
- Outputs:
    - https://jfrog.hub.vwgroup.com/artifactory/checu-reqex-generic-exchange/Audi2MobilEye/

## Import/Feedback/Statistics-Workflow
- Workflow: [codebeamer_import_feedback_statistics.yml](.github/workflows/codebeamer_import_feedback_statistics.yml)
- Trigger: https://git.hub.vwgroup.com/CH-ECU/requirements-exchange/actions/workflows/codebeamer_import_feedback_statistics.yml
- Inputs:
    - reqIF path: JFrog repository path to .reqif file containing MobilEye feedback to import
    - Baseline ID: The baseline ID of the corresponding ReqIF export
- Outputs:
    - https://jfrog.hub.vwgroup.com/artifactory/checu-reqex-generic-internal/import/
    - https://jfrog.hub.vwgroup.com/artifactory/checu-reqex-generic-internal/feedback_Audi2MobilEye/
    - https://jfrog.hub.vwgroup.com/artifactory/checu-reqex-generic-internal/statistics/
