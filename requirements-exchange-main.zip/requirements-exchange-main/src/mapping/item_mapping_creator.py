import json
import argparse
import polars as pl
import pandas as pd
from dataclasses import dataclass
from tqdm import tqdm
from pathlib import Path
from datetime import date
from typing import Dict, List
import calmpy.exceptions
import calmpy


@dataclass
class TrackerPairData:
    """
    A class that represents data of a tracker pair
    """
    instance_1: str = ''
    instance_2: str = ''
    tracker_name_1: str = ''
    tracker_name_2: str = ''
    mapping_field: str = ''
    tracker_empty_1: pl.DataFrame = None
    tracker_empty_2: pl.DataFrame = None
    tracker_non_empty_no_mapping_1: pl.DataFrame = None
    tracker_non_empty_no_mapping_2: pl.DataFrame = None
    tracker_mapping: pl.DataFrame = None


class ItemMappingCreator:
    """
    A class that represents the creation of item mappings for tracker id pairs
    """
    TRACKER_PAIR_CH63_ID = 'TrackerID-DPE'
    TRACKER_PAIR_SV62_ID = 'TrackerID-DPAS'

    def __init__(self, cb_server: str, tracker_mapping: Path,
                 field_mapping: Path, output_dir: Path,
                 baseline_instance1: str = None, baseline_instance2: str = None) -> None:
        """
        Constructs an object of DecisionExecutor that will handle the execution of CCD decisions

        :param cb_server: The url or short name for Codebeamer instance to work with
        :type cb_server: str
        :param tracker_mapping: path to .xlsx file that contains list of tracker pairs (SV62/CH63)
        :type tracker_mapping: Path
        :param field_mapping: path to .json file that contains SV62 to CH63 field mappings
        :type field_mapping: Path
        :param baseline_instance1: the baseline to export for instance 1
        :type baseline_instance1: str
        :param baseline_instance1: the baseline to export for instance 2
        :type baseline_instance1: str
        :param output_dir: path to directory where results are stored
        :type output_dir: Path
        :return: None
        """
        # save parameter data
        self._baseline_instance1 = baseline_instance1
        self._baseline_instance2 = baseline_instance2

        # prepare date of execution
        self._time_str = str(date.today())

        # prepare output path
        self._output_dir = output_dir / f'{cb_server}_{self._time_str}'

        # initialize calmpy codebeamer server
        self._cb_server_name = cb_server
        self._cb_server = calmpy.Server(url=cb_server)

        # load tracker pair json
        self._tracker_mapping = tracker_mapping
        self._tracker_pairs = self.__load_json(self._tracker_mapping)

        # load SV62 to CH63 field mapping
        self._sv62_to_ch63_field_mapping_path = field_mapping
        self._sv62_to_ch63 = self.__load_json(
            self._sv62_to_ch63_field_mapping_path)

    def __load_json(self, config_file_path: Path) -> Dict:
        """
        Loads JSON file.

        :param config_file_path: path to .json file
        :type config_file_path: Path
        :return: Json data
        :type Dict
        """
        with open(config_file_path, 'r', encoding='utf-8') as file:
            return json.load(file)

    def __save_tracker_pair_data_as_xlsx(self, tracker_pair_data: TrackerPairData, sheet_name: str, file_prefix: str = ''):
        """
        Saves TrackerPairData as xlsx's in given path

        :param tracker_pair_data: data of tracker pairs to save
        :type tracker_pair_data: TrackerPairData
        :param sheet_name: name of sheet to insert df in
        :type sheet_name: str
        :param file_prefix: string that will be placed in front of file name
        :type file_prefix: str
        """
        # prepare data path
        data_file_path = self._output_dir / \
            f'{file_prefix}{tracker_pair_data.instance_1}-{tracker_pair_data.tracker_name_1[:2]}_{tracker_pair_data.instance_2}-{tracker_pair_data.tracker_name_2[:2]}_{sheet_name}.xlsx'

        # save data tracker 1 empty
        self.__save_polars_df_as_xlsx(df=tracker_pair_data.tracker_empty_1,
                                      sheet_name=f'EMPTY_{tracker_pair_data.instance_1}',
                                      data_file_path=data_file_path)

        # save data tracker 2 empty
        self.__save_polars_df_as_xlsx(df=tracker_pair_data.tracker_empty_2,
                                      sheet_name=f'EMPTY_{tracker_pair_data.instance_2}',
                                      data_file_path=data_file_path)

        # save data tracker 1 non empty no mapping
        self.__save_polars_df_as_xlsx(df=tracker_pair_data.tracker_non_empty_no_mapping_1,
                                      sheet_name=f'NON_EMPTY_NO_MAPPING_{tracker_pair_data.instance_1}',
                                      data_file_path=data_file_path)

        # save data tracker 2 non empty no mapping
        self.__save_polars_df_as_xlsx(df=tracker_pair_data.tracker_non_empty_no_mapping_2,
                                      sheet_name=f'NON_EMPTY_NO_MAPPING_{tracker_pair_data.instance_2}',
                                      data_file_path=data_file_path)

        # save mapping data
        self.__save_polars_df_as_xlsx(df=tracker_pair_data.tracker_mapping,
                                      sheet_name=f'MAPPING_{tracker_pair_data.instance_1}_{tracker_pair_data.instance_2}',
                                      data_file_path=data_file_path)

    def __save_polars_df_as_xlsx(self, df: pl.DataFrame, sheet_name: str, data_file_path: Path):
        """
        Saves Dataframe in given path

        :param df: Dataframe to save
        :type df: pl.DataFrame
        :param sheet_name: name of sheet to insert df in
        :type sheet_name: str
        :param data_file_path: Path where Dataframe should be saved
        :type data_file_path: Path
        """
        if df is None:
            return

        # create parent folder if it does not exist
        if not data_file_path.parent.exists():
            data_file_path.parent.mkdir(parents=True, exist_ok=True)

        df_pd = df.to_pandas()

        # Write sheet
        if data_file_path.exists():
            with pd.ExcelWriter(data_file_path, engine='openpyxl', mode='a') as writer:
                df_pd.to_excel(writer, sheet_name=sheet_name, index=False)
        else:
            with pd.ExcelWriter(data_file_path, engine='openpyxl') as writer:
                df_pd.to_excel(writer, sheet_name=sheet_name, index=False)

    def __concat_df(self, df1: pl.DataFrame, df2: pl.DataFrame) -> pl.DataFrame:
        """
        Concatenates two DataFrames if possible

        :param df1: Left Dataframe to concatenate
        :type df1: pl.DataFrame
        :param df2: Right Dataframe to concatenate
        :type df2: pl.DataFrame
        :return: pl.DataFrame (concatenated DataFrame)
        """
        if df1 is not None and df2 is not None:
            return pl.concat([df1, df2], how='diagonal_relaxed')
        elif df1 is not None:
            return df1
        else:
            return df2

    def __merge(self, tracker_pair_data_1: TrackerPairData,
                tracker_pair_data_2: TrackerPairData) -> TrackerPairData:
        """
        Merges two TrackerPairData objects

        :param tracker_pair_data_1: Left TrackerPairData to merge
        :type tracker_pair_data_1: TrackerPairData
        :param tracker_pair_data_2: Right TrackerPairData to merge
        :type tracker_pair_data_2: TrackerPairData
        :return: TrackerPairData (merged TrackerPairData)
        """
        merged_tracker_pair_data = TrackerPairData(instance_1=tracker_pair_data_1.instance_1 if tracker_pair_data_1.instance_1 != '' else tracker_pair_data_2.instance_1,
                                                   instance_2=tracker_pair_data_1.instance_2 if tracker_pair_data_1.instance_2 != '' else tracker_pair_data_2.instance_2,
                                                   tracker_name_1=tracker_pair_data_1.tracker_name_1 +
                                                   '_' + tracker_pair_data_2.tracker_name_1,
                                                   tracker_name_2=tracker_pair_data_1.tracker_name_2 +
                                                   '_' + tracker_pair_data_2.tracker_name_2,
                                                   mapping_field=tracker_pair_data_1.mapping_field if tracker_pair_data_1.mapping_field != '' else tracker_pair_data_2.mapping_field)
        # merge when both are not empty
        if tracker_pair_data_1.tracker_empty_1 is not None and tracker_pair_data_2.tracker_empty_1 is not None:
            merged_tracker_pair_data.tracker_empty_1 = self.__concat_df(df1=tracker_pair_data_1.tracker_empty_1,
                                                                        df2=tracker_pair_data_2.tracker_empty_1)
        else:
            # assign the non empty dataframe
            if tracker_pair_data_1.tracker_empty_1 is not None:
                merged_tracker_pair_data.tracker_empty_1 = tracker_pair_data_1.tracker_empty_1
            elif tracker_pair_data_2.tracker_empty_1 is not None:
                merged_tracker_pair_data.tracker_empty_1 = tracker_pair_data_2.tracker_empty_1

        # merge when both are not empty
        if tracker_pair_data_1.tracker_empty_2 is not None and tracker_pair_data_2.tracker_empty_2 is not None:
            merged_tracker_pair_data.tracker_empty_2 = self.__concat_df(df1=tracker_pair_data_1.tracker_empty_2,
                                                                        df2=tracker_pair_data_2.tracker_empty_2)
        else:
            # assign the non empty dataframe
            if tracker_pair_data_1.tracker_empty_2 is not None:
                merged_tracker_pair_data.tracker_empty_2 = tracker_pair_data_1.tracker_empty_2
            elif tracker_pair_data_2.tracker_empty_2 is not None:
                merged_tracker_pair_data.tracker_empty_2 = tracker_pair_data_2.tracker_empty_2

        # merge when both are not empty
        if tracker_pair_data_1.tracker_non_empty_no_mapping_1 is not None and tracker_pair_data_2.tracker_non_empty_no_mapping_1 is not None:
            merged_tracker_pair_data.tracker_non_empty_no_mapping_1 = self.__concat_df(df1=tracker_pair_data_1.tracker_non_empty_no_mapping_1,
                                                                                       df2=tracker_pair_data_2.tracker_non_empty_no_mapping_1)
        else:
            # assign the non empty dataframe
            if tracker_pair_data_1.tracker_non_empty_no_mapping_1 is not None:
                merged_tracker_pair_data.tracker_non_empty_no_mapping_1 = tracker_pair_data_1.tracker_non_empty_no_mapping_1
            elif tracker_pair_data_2.tracker_non_empty_no_mapping_1 is not None:
                merged_tracker_pair_data.tracker_non_empty_no_mapping_1 = tracker_pair_data_2.tracker_non_empty_no_mapping_1

        # merge when both are not empty
        if tracker_pair_data_1.tracker_non_empty_no_mapping_2 is not None and tracker_pair_data_2.tracker_non_empty_no_mapping_2 is not None:
            merged_tracker_pair_data.tracker_non_empty_no_mapping_2 = self.__concat_df(df1=tracker_pair_data_1.tracker_non_empty_no_mapping_2,
                                                                                       df2=tracker_pair_data_2.tracker_non_empty_no_mapping_2)
        else:
            # assign the non empty dataframe
            if tracker_pair_data_1.tracker_non_empty_no_mapping_2 is not None:
                merged_tracker_pair_data.tracker_non_empty_no_mapping_2 = tracker_pair_data_1.tracker_non_empty_no_mapping_2
            elif tracker_pair_data_2.tracker_non_empty_no_mapping_2 is not None:
                merged_tracker_pair_data.tracker_non_empty_no_mapping_2 = tracker_pair_data_2.tracker_non_empty_no_mapping_2

        # merge when both are not empty
        if tracker_pair_data_1.tracker_mapping is not None and tracker_pair_data_2.tracker_mapping is not None:
            merged_tracker_pair_data.tracker_mapping = self.__concat_df(df1=tracker_pair_data_1.tracker_mapping,
                                                                        df2=tracker_pair_data_2.tracker_mapping)
        else:
            # assign the non empty dataframe
            if tracker_pair_data_1.tracker_mapping is not None:
                merged_tracker_pair_data.tracker_mapping = tracker_pair_data_1.tracker_mapping
            elif tracker_pair_data_2.tracker_mapping is not None:
                merged_tracker_pair_data.tracker_mapping = tracker_pair_data_2.tracker_mapping

        return merged_tracker_pair_data

    def __move_column_to_front(self, df: pl.DataFrame, columns_to_move: List[str]) -> pl.DataFrame:
        """
        Rearanges columns of DataFrame so that specified columns are in the front

        :param df: DataFrame to rearange
        :type df: pl.DataFrame
        :param columns_to_move: list of column names to move to the front
        :type columns_to_move: List[str]
        :return: pl.DataFrame (rearranged DataFrame)
        """
        # Get the remaining columns that are not in 'columns_to_move'
        remaining_columns = [
            col for col in df.columns if col not in columns_to_move]

        # Reorder the columns: place 'columns_to_move' first, then 'remaining_columns'
        ordered_columns = columns_to_move + remaining_columns

        # Reorder the DataFrame
        df_reordered = df.select(ordered_columns)

        return df_reordered

    def __print_statistics(self, tracker_pair_data: TrackerPairData):
        """
        Prints statistics of provided TrackerPairData to console

        :param tracker_pair_data: data to get statistics for
        :type tracker_pair_data: TrackerPairData    
        :return: None
        """
        cnt_empty_1 = tracker_pair_data.tracker_empty_1.height
        cnt_empty_2 = tracker_pair_data.tracker_empty_2.height
        cnt_not_empty_no_mapping_1 = tracker_pair_data.tracker_non_empty_no_mapping_1.height
        cnt_not_empty_no_mapping_2 = tracker_pair_data.tracker_non_empty_no_mapping_2.height
        cnt_mapping = tracker_pair_data.tracker_mapping.height
        cnt_overall = cnt_empty_1 + cnt_empty_2 + cnt_not_empty_no_mapping_1 + \
            cnt_not_empty_no_mapping_2 + cnt_mapping

        print(f'empty items ({tracker_pair_data.instance_1}):' +
              f' {cnt_empty_1} ({(cnt_empty_1/cnt_overall)*100}%)')
        print(f'empty items ({tracker_pair_data.instance_2}):' +
              f' {cnt_empty_2} ({(cnt_empty_2/cnt_overall)*100}%)')
        print(f'not empty-not mappable items ({tracker_pair_data.instance_1}):' +
              f' {cnt_not_empty_no_mapping_1} ({(cnt_not_empty_no_mapping_1/cnt_overall)*100}%)')
        print(f'not empty-not mappable items ({tracker_pair_data.instance_2}):' +
              f' {cnt_not_empty_no_mapping_2} ({(cnt_not_empty_no_mapping_2/cnt_overall)*100}%)')
        print(f'mappable items ({tracker_pair_data.instance_1}+{tracker_pair_data.instance_2}):' +
              f' {cnt_mapping} ({(cnt_mapping/cnt_overall)*100}%)')
        print(f'Overall items:' +
              f' {cnt_overall}')

    def create_item_mappings(self) -> Path:
        """
        Creates .xlsx output for empty, non empty - no mapping and mappable items from specified trackers

        :return: Path (result folder)
        """

        field_pairs = [{'CH63': 'Foreign ID_DOORS_pe',
                        'SV62': 'Foreign ID_DOORS_pe'}]

        print('Extract data:')

        tracker_pair_data_dict = {}
        for tracker_pair in tqdm(self._tracker_pairs):
            # get tracker data
            tracker_ch63 = self._cb_server.get_tracker(
                tracker_pair[self.TRACKER_PAIR_CH63_ID])
            ch63_items = tracker_ch63.get_items() if self._baseline_instance1 is None else tracker_ch63.get_items(
                baseline=self._baseline_instance1)
            ch63_item_df = ch63_items.to_dataframe()

            tracker_sv62 = self._cb_server.get_tracker(
                tracker_pair[self.TRACKER_PAIR_SV62_ID])
            sv62_items = tracker_sv62.get_items() if self._baseline_instance2 is None else tracker_sv62.get_items(
                baseline=self._baseline_instance2)
            sv62_item_df = sv62_items.to_dataframe()

            # prepare filtered data
            for field_pair in field_pairs:
                # prepare empty dataframes
                tracker_pair_data = TrackerPairData(instance_1='CH63',
                                                    instance_2='SV62',
                                                    tracker_name_1=tracker_ch63.name,
                                                    tracker_name_2=tracker_sv62.name,
                                                    mapping_field=field_pair['CH63'],
                                                    tracker_empty_1=None,
                                                    tracker_empty_2=None,
                                                    tracker_non_empty_no_mapping_1=None,
                                                    tracker_non_empty_no_mapping_2=None,
                                                    tracker_mapping=None)
                prefered_column_order = ['ID',
                                         'Tracker.id',
                                         field_pair[tracker_pair_data.instance_1],
                                         'Description']

                if field_pair[tracker_pair_data.instance_1] in ch63_item_df.columns:
                    # filter for empty rows
                    tracker_pair_data.tracker_empty_1 = ch63_item_df.filter(ch63_item_df[field_pair[tracker_pair_data.instance_1]]
                                                                            .is_null())
                    # rearrange columns
                    tracker_pair_data.tracker_empty_1 = self.__move_column_to_front(df=tracker_pair_data.tracker_empty_1,
                                                                                    columns_to_move=prefered_column_order)
                if field_pair[tracker_pair_data.instance_2] in sv62_item_df.columns:
                    # filter for empty rows
                    tracker_pair_data.tracker_empty_2 = sv62_item_df.filter(sv62_item_df[field_pair[tracker_pair_data.instance_2]]
                                                                            .is_null())
                    # rearrange columns
                    tracker_pair_data.tracker_empty_2 = self.__move_column_to_front(df=tracker_pair_data.tracker_empty_2,
                                                                                    columns_to_move=prefered_column_order)

                if field_pair[tracker_pair_data.instance_1] in ch63_item_df.columns and field_pair[tracker_pair_data.instance_2] in sv62_item_df.columns:
                    # prepare non empty but not matching dataframes
                    tracker_pair_data.tracker_non_empty_no_mapping_1 = ch63_item_df.filter(ch63_item_df[field_pair[tracker_pair_data.instance_1]].is_not_null() &
                                                                                           ~ch63_item_df[field_pair[tracker_pair_data.instance_1]].is_in(sv62_item_df[field_pair[tracker_pair_data.instance_2]]))

                    tracker_pair_data.tracker_non_empty_no_mapping_2 = sv62_item_df.filter(sv62_item_df[field_pair[tracker_pair_data.instance_2]].is_not_null() &
                                                                                           ~sv62_item_df[field_pair[tracker_pair_data.instance_2]].is_in(ch63_item_df[field_pair[tracker_pair_data.instance_1]]))

                    # prepare non empty and matching dataframes
                    non_empty_mapping_field_ch63 = ch63_item_df.filter(ch63_item_df[field_pair[tracker_pair_data.instance_1]].is_not_null() &
                                                                       ch63_item_df[field_pair[tracker_pair_data.instance_1]].is_in(sv62_item_df[field_pair[tracker_pair_data.instance_2]]))
                    non_empty_mapping_field_sv62 = sv62_item_df.filter(sv62_item_df[field_pair[tracker_pair_data.instance_2]].is_not_null() &
                                                                       sv62_item_df[field_pair[tracker_pair_data.instance_2]].is_in(ch63_item_df[field_pair[tracker_pair_data.instance_1]]))
                    tracker_pair_data.tracker_mapping = non_empty_mapping_field_ch63.join(non_empty_mapping_field_sv62,
                                                                                          on=field_pair[tracker_pair_data.instance_1],
                                                                                          how='inner',
                                                                                          suffix=f' {tracker_pair_data.instance_2}')
                    # manually add suffix to columns from the left DataFrame (CH63)
                    tracker_pair_data.tracker_mapping = tracker_pair_data.tracker_mapping.rename({
                        # skip the join column
                        col: f"{col} {tracker_pair_data.instance_1}" for col in non_empty_mapping_field_ch63.columns if col != field_pair[tracker_pair_data.instance_1]
                    })

                    # reorder columns
                    tracker_pair_data.tracker_non_empty_no_mapping_1 = self.__move_column_to_front(df=tracker_pair_data.tracker_non_empty_no_mapping_1,
                                                                                                   columns_to_move=prefered_column_order)
                    tracker_pair_data.tracker_non_empty_no_mapping_2 = self.__move_column_to_front(df=tracker_pair_data.tracker_non_empty_no_mapping_2,
                                                                                                   columns_to_move=prefered_column_order)
                    tracker_pair_data.tracker_mapping = self.__move_column_to_front(df=tracker_pair_data.tracker_mapping,
                                                                                    columns_to_move=[f'ID {tracker_pair_data.instance_1}',
                                                                                                     f'Tracker.id {tracker_pair_data.instance_1}',
                                                                                                     f'ID {tracker_pair_data.instance_2}',
                                                                                                     f'Tracker.id {tracker_pair_data.instance_2}',
                                                                                                     field_pair[tracker_pair_data.instance_1],
                                                                                                     f'Description {tracker_pair_data.instance_1}',
                                                                                                     f'Description {tracker_pair_data.instance_2}'])

                    # save data as xlsx
                    self.__save_tracker_pair_data_as_xlsx(tracker_pair_data=tracker_pair_data,
                                                          sheet_name=field_pair[tracker_pair_data.instance_1])
                # add initial data entry
                if field_pair[tracker_pair_data.instance_1] not in tracker_pair_data_dict:
                    tracker_pair_data_dict[field_pair[tracker_pair_data.instance_1]] = [
                        tracker_pair_data]
                else:
                    tracker_pair_data_dict[field_pair[tracker_pair_data.instance_1]].append(
                        tracker_pair_data)

        # merge and save data frames
        print('Merge and save dataframes:')
        overall_tracker_pair_data = {}
        for field in tracker_pair_data_dict:
            if field not in overall_tracker_pair_data:
                overall_tracker_pair_data[field] = TrackerPairData(tracker_name_1='XX',
                                                                   tracker_name_2='XX')
            for tracker_pair_data in tqdm(tracker_pair_data_dict[field]):
                # merge data to overall data
                overall_tracker_pair_data[field] = self.__merge(
                    tracker_pair_data_1=overall_tracker_pair_data[field], tracker_pair_data_2=tracker_pair_data)

        # save overall data as xlsx
        for field, tracker_pair_data in overall_tracker_pair_data.items():
            self.__save_tracker_pair_data_as_xlsx(tracker_pair_data=tracker_pair_data,
                                                  sheet_name=field,
                                                  file_prefix='Overall_')
            print(f'data based on field: {field}')
            self.__print_statistics(tracker_pair_data=tracker_pair_data)

        return self._output_dir


def main():
    parser = argparse.ArgumentParser(
        description='Creation of item mappings for specified tracker pairs')
    parser.add_argument('--cb_server', type=str,
                        help='Instance the actions should be performed on (e.g. "Prod", "QS")',
                        default='QS')
    parser.add_argument('--tracker_mapping', type=str,
                        help='Path to .json file that contains the tracker mapping')
    parser.add_argument('--field_mapping', type=str,
                        help='Path to .json file that contains the field mapping')
    parser.add_argument('--baseline_CH63',
                        help='id of baseline for data to export for CH63',
                        type=int,
                        default=None)
    parser.add_argument('--baseline_SV62',
                        help='id of baseline for data to export for SV62',
                        type=int,
                        default=None)
    parser.add_argument('--output_dir', type=str,
                        help='Path to output directory')
    args = parser.parse_args()

    item_mapping_creator = ItemMappingCreator(cb_server=args.cb_server,
                                              tracker_mapping=Path(
                                                  args.tracker_mapping),
                                              field_mapping=Path(
                                                  args.field_mapping),
                                              output_dir=Path(args.output_dir),
                                              baseline_instance1=args.baseline_CH63,
                                              baseline_instance2=args.baseline_SV62)

    item_mapping_creator.create_item_mappings()


if __name__ == '__main__':
    main()
