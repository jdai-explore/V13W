import calmpy
import pandas as pd
import json
from tqdm import tqdm
from pathlib import Path


def main() -> int:
        result_path = Path('./codebeamer_export_only_CH63')
        tracker_ids = ['92348129', '84849200', '92347611', '92347870', '92347439', '92347698', '92347784', '92347352', '92347525', '92348043']
        #cb_server = calmpy.Server(url='Prod') 
        # Load the JSON configuration file
        with open('./config/instance_url.json', 'r') as file:
            data = json.load(file)
        cb_server = calmpy.Server(url=data['data_sources']['codebeamer_instance']['url'], verify=False)

        for tracker_id in tracker_ids:
            tracker_result_path = result_path / f'{tracker_id}.xlsx'
            if tracker_result_path.exists():
                 continue

            print(f'Start with tracker {tracker_id}')

            # get tracker
            tracker = cb_server.get_tracker(tracker_id=tracker_id)

            # get all items of tracker
            tracker_items = tracker.get_items()

            # create empty dataframe (with all fields and additional ids)
            df = pd.DataFrame(columns=list({field for item in tracker.get_items() for field in item}))

            # check if CH63 is in any modul variant of item (field: 'Module Variant_pe')
            for item in tqdm(tracker_items):
                if item['Module Variant_pe'] is None:
                     continue

                if isinstance(item['Module Variant_pe'], list):
                    if all(['CH63' in variant for variant in item['Module Variant_pe']]):
                        # convert all fields to dict
                        item_dict = {field: item[field] for field in item}

                        # add dict to dataframe
                        df.loc[len(df)] = item_dict
                else:
                     if 'CH63' in item['Module Variant_pe']:
                        # convert all fields to dict
                        item_dict = {field: item[field] for field in item}

                        # add dict to dataframe
                        df.loc[len(df)] = item_dict

            # save dataframe
            if not tracker_result_path.parent.exists():
                tracker_result_path.parent.mkdir(parents=True, exist_ok=True)

            df.to_excel(tracker_result_path, index=False)


if __name__ == '__main__':
    main()
