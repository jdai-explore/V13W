import time
import json
import re
from pathlib import Path
from argparse import ArgumentParser
from openpyxl import load_workbook
from enum import Enum
import polars as pl
import calmpy
import sys


class CodebeamerExporterRFQ:
    """
    CodebeamerExporterRFQ - A class that will handle the export of codebeamer trackers for RFQ process
    """

    def __init__(self, cb_instance: str, tracker_ids_json: Path, field_json: Path, view_name: str,
                 baseline: str, output_dir_base: str) -> None:
        """
        Constructs an object of DecisionExecutor that will handle the execution of CCB decisions

        :param cb_instance: The url or short name for Codebeamer instance to work with
        :type cb_instance: str
        :param tracker_ids_json: path to .json file that contains the trackers to export
        :type tracker_ids_json: Path
        :param field_json: path to .json file that contains field names to export
        :type field_json: Path
        :param view_name: the name of view to export
        :type view_name: str
        :param baseline: the baseline to export
        :type baseline: str
        :param output_dir_base: path to the output directory where results should be saved to
        :type output_dir_base: str
        :return: None
        """
        # save parameters
        self._cb_instance = cb_instance
        self._tracker_ids_json = tracker_ids_json
        self._field_json = field_json
        self._view_name = view_name
        self._baseline = baseline
        self._output_dir_base = output_dir_base

        # get the current time
        self._current_time = time.localtime()

        # format the current time
        self._formatted_time = time.strftime("%Y-%b-%d", self._current_time)

        # prepare output folder
        self._output_dir = Path(f'{self._output_dir_base}/export_{self._formatted_time}')
        if not self._output_dir.exists():
            self._output_dir.mkdir(parents=True, exist_ok=True)

        # load the JSON configuration file
        with open(self._tracker_ids_json, 'r', encoding='utf-8') as file:
            self._package_data = json.load(file)

        # load the JSON field list
        with open(self._field_json, 'r', encoding='utf-8') as file:
            self._field_list = json.load(file)['field_names']

    def export(self) -> Path:
        """
        This function exports the specified trackers as packages and creates a corresponding report

        :return: returns path to generated output folder
        """
        # update baseline
        baseline_str = self._baseline if self._baseline is not None else 'Head Revision'

        for tracker_id in self._package_data['tracker_ids']:
            # export reqif
            print(f'Export trackers {tracker_id} ...')
            print(f'\tBaseline: {baseline_str}')
            self._export_reqif(cb_instance=self._cb_instance,
                               tracker_ids=[tracker_id],
                               save_dir=self._output_dir,
                               baseline=self._baseline)
            print(f'Export for tracker {tracker_id} - done\n')

        return self._output_dir

    def get_tracker_view(self, cb_instance: str, tracker_id: int, include: str):
        '''
        This functions returns id and name of tracker view containing include string

        :param cb_instance: codebeamer instance that the view will be requested on
        :type cb_instance: str
        :param tracker_id: id of tracker to request view for
        :type tracker_id: int
        :param include: value that the name of the view should contain
        :type include: str
        :return: int, str (id, name)
        '''
        # initialize codebeamer server
        cb = calmpy.Server(url=cb_instance)

        # prepare request
        request_url = f"{cb.URL}/api/v3/trackers/{tracker_id}/reports"

        # request reports from server
        reports = cb.session.make_single_request(
            request_type="GET", request_url=request_url)

        # check response
        filtered_reports = [
            report for report in reports if include in report['name']]

        if len(filtered_reports) > 1:
            print(f'Found multiple views with names including "{include}", will take {filtered_reports[0]}')

        view = filtered_reports[0] if filtered_reports else None

        return view.get('id', None) if view is not None else None, view.get('name', None) if view is not None else None

    def _export_reqif(self, cb_instance: str, tracker_ids: list, save_dir: str,
                      project_name: str = 'DAS-PROD-ECUS', baseline: calmpy.Baseline = None):
        '''
        This functions exports given trackers from specified project as a single reqif

        :param cb_instance: codebeamer instance that the view will be requested on
        :type cb_instance: str
        :param tracker_ids: ids of trackers export
        :type tracker_ids: list[int]
        :param save_dir: path of output folder
        :type save_dir: str
        :param project_name: id of project to export trackers from
        :type project_name: id
        :return: reqif data
        '''
        # initialize codebeamer server
        cb_server = calmpy.Server(url=cb_instance, readonly=False)

        # create tracker export configs
        tracker_export_configs = []
        for tracker_id in tracker_ids:
            tracker = cb_server.get_tracker(tracker_id=tracker_id)
            print(f'\tTracker Name: {tracker.name}')
            # get correct view for tracker
            view_id, view_name = self.get_tracker_view(cb_instance=cb_instance,
                                                       tracker_id=tracker_id,
                                                       include=self._view_name)
            print(f'\tView Name: {view_name} View Id: {view_id}')

            if view_name is None or view_id is None:
                sys.exit(f'tracker {tracker.name} (id: {tracker_id}) has no view which name includes "{self._view_name}"!')

            # generate regif export config based on view
            reqif_export_config, _ = tracker.get_reqif_export_config(tracker_field_list=self._field_list, tracker_view=view_id)
            tracker_export_configs.append(reqif_export_config)

        # export reqif
        reqif = cb_server.get_project(project=project_name).export_as_reqif(destination=f'RFQ-{tracker.name}_{self._formatted_time}',
                                                                            tracker_list=tracker_export_configs,
                                                                            baseline=baseline)

        # save reqif data to .reqifz file
        with open(save_dir / (tracker.name + '.reqifz'), "wb") as f:
            f.write(reqif.getbuffer())


def add_arguments(parser: ArgumentParser):
    '''
    This functions handles the arguments for this script

    :param parser: argument parser including arguments to parse
    :type parser: ArgumentParser
    '''
    parser.add_argument('--cb_instance',
                        help='specifies on which instance the updates are made ("Prod", "QS", ...)',
                        type=str)
    parser.add_argument('--tracker_ids_json',
                        help='json including tracker ids to update',
                        type=str)
    parser.add_argument('--field_json',
                        help='json including field to export',
                        type=str)
    parser.add_argument('--view_name',
                        help='name of view',
                        type=str,
                        default='RFQ - SDV0.1_ADAS')
    parser.add_argument('--baseline',
                        help='id of baseline for data to export',
                        type=int,
                        default=None)
    parser.add_argument('--output_dir', type=str,
                        help='Path to output directory')


def main() -> int:
    '''
    This functions handles the export of trackers on given server
    '''

    # argument parsing
    parser = ArgumentParser(prog='codebeamer_exporter_rfq',
                            description='Exports given trackers and creates report for RFQ process')
    add_arguments(parser=parser)
    args = parser.parse_args()

    codebeamer_exporter = CodebeamerExporterRFQ(cb_instance=args.cb_instance,
                                                tracker_ids_json=args.tracker_ids_json,
                                                field_json=args.field_json,
                                                view_name=args.view_name,
                                                baseline=args.baseline,
                                                output_dir_base=args.output_dir)
    codebeamer_exporter.export()


if __name__ == '__main__':
    main()
