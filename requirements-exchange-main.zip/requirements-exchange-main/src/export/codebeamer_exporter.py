import time
import json
import re
from pathlib import Path
from argparse import ArgumentParser
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.worksheet.table import Table, TableStyleInfo
from enum import Enum
import calmpy


class EXPORT_TYPE(Enum):
    ALL = 'ALL'
    SUPPLIER_MOBILEYE = 'SUPPLIER_MOBILEYE'
    SUPPLIER_VALEO = 'SUPPLIER_VALEO'
    SUPPLIER_CONTINENTAL = 'SUPPLIER_CONTINENTAL'
    SUPPLIER_MAGNA = 'SUPPLIER_MAGNA'
    SUPPLIER_APTIV = 'SUPPLIER_APTIV'

VIEW_INCLUDE_STR = "Requirement Exchange - MobilEye"


class CodebeamerExporter:
    """
    CodebeamerExporter - A class that will handle the export of codebeamer trackers
    """

    def __init__(self, cb_instance: str, tracker_ids_json: Path,
                 baseline: str, output_dir_base: str,
                 export_type: EXPORT_TYPE = EXPORT_TYPE.ALL) -> None:
        """
        Constructs an object of DecisionExecutor that will handle the execution of CCB decisions
        :param cb_instance: The url or short name for Codebeamer instance to work with
        :type cb_instance: str
        :param tracker_ids_json: path to .json file that contains the trackers to export
        :type tracker_ids_json: Path
        :param baseline: the baseline to export
        :type baseline: str
        :param export_type: the type of export to execute (manages which fields to export)
        :type export_type: EXPORT_TYPE
        :param output_dir_base: path to the output directory where results should be saved to
        :type output_dir_base: str
        :return: None
        """
        # save parameters
        self._cb_instance = cb_instance
        self._tracker_ids_json = tracker_ids_json
        self._baseline = baseline
        self._export_type = export_type
        self._output_dir_base = output_dir_base

        # get the current time
        self._current_time = time.localtime()

        # format the current time
        self._formatted_time = time.strftime("%Y-%b-%d", self._current_time)

        # prepare output folder
        self._output_dir = (Path(f'{self._output_dir_base}/export_{self._formatted_time}_{self._export_type}')
                            if self._export_type != EXPORT_TYPE.ALL else Path(
            f'{self._output_dir_base}/export_{self._formatted_time}'))
        if not self._output_dir.exists():
            self._output_dir.mkdir(parents=True, exist_ok=True)

        # load the JSON configuration file
        with open(self._tracker_ids_json, 'r', encoding='utf-8') as file:
            self._package_data = json.load(file)

    def export(self) -> Path:
        """
        This function exports the specified trackers as packages and creates a corresponding report
        :return: returns path to generated output folder
        """
        # initialize codebeamer server
        cb_server = calmpy.Server(url=self._cb_instance)

        # update baseline
        baseline_str = self._baseline if self._baseline is not None else 'Head Revision'

        # styling
        bold = Font(bold=True)
        center = Alignment(horizontal="center", vertical="center")
        header_fill = PatternFill(start_color="ADD8E6", end_color="ADD8E6", fill_type="solid")
        bundle_fill = PatternFill(start_color="F2F2F2", end_color="F2F2F2", fill_type="solid")
        # border
        border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )

        wb = Workbook()
        ws = wb.active
        ws.title = "BT-LAH"
        excel_row = 2

        ws.merge_cells(start_row=excel_row, start_column=2, end_row=excel_row, end_column=5)
        ws.cell(row=excel_row, column=2, value="BT-LAH CH63-ECU Packages (Delta CH63/SV62)").font = Font(bold=True, size=20)
        ws.cell(row=excel_row, column=2).alignment = center
        ws.cell(row=excel_row, column=2).fill = header_fill
        for col in range(2,6):
            ws.cell(row=excel_row, column=col).border = border
        excel_row += 2

        # Header row
        ws.merge_cells(start_row=excel_row, start_column=2, end_row=excel_row, end_column=3)
        ws.cell(row=excel_row, column=2, value="Allgemein").font = Font(bold=True, size=14)
        ws.cell(row=excel_row, column=2).alignment = center
        ws.cell(row=excel_row, column=2).fill = header_fill
        ws.cell(row=excel_row, column=4, value="Items (all)").font = Font(bold=True, size=14)
        ws.cell(row=excel_row, column=4).fill = header_fill
        ws.cell(row=excel_row, column=5, value="Items (CH63 only)").font = Font(bold=True, size=14)
        ws.cell(row=excel_row, column=5).fill = header_fill
        for col in range(2,6):
            ws.cell(row=excel_row, column=col).border = border
        excel_row += 1

        # baseline
        ws.cell(row=excel_row, column=2, value="Baseline:").font = bold
        ws.cell(row=excel_row, column=3, value=baseline_str)
        excel_row += 1

        for package_idx, package_tracker_ids in self._package_data.items():
            print(f'Generate report data for package {package_idx}:')
            print(f'\tCurrent date: {self._formatted_time}')
            print(f'\tBaseline: {baseline_str}')

            # update report - names for bundles
            bundle_name = self.get_bundle_name_str(time_str=self._formatted_time,
                                                                     bundle=package_idx)
            #fill data in excel file
            ws.cell(row=excel_row, column=2, value=f"Bundle Nr: {package_idx}").font = bold
            ws.cell(row=excel_row, column=3, value=self._formatted_time).font = bold
            for col in range(2,6):
                ws.cell(row=excel_row, column=col).border = border
                ws.cell(row=excel_row, column=col).fill = bundle_fill
            excel_row += 1

            ws.cell(row=excel_row, column=2, value=f"Bundle Name:").font = bold
            ws.cell(row=excel_row, column=3, value=bundle_name)
            for col in range(2,6):
                ws.cell(row=excel_row, column=col).border = border
                ws.cell(row=excel_row, column=col).fill = bundle_fill
            excel_row += 1
            # fill empty row with border and color
            for col in range(2,6):
                ws.cell(row=excel_row, column=col).border = border
                ws.cell(row=excel_row, column=col).fill = bundle_fill
            excel_row += 1

            ws.cell(row=excel_row, column=2, value="Nr.").font = bold
            ws.cell(row=excel_row, column=3, value="Requirement Documents").font = bold
            for col in range(2,6):
                ws.cell(row=excel_row, column=col).border = border
                ws.cell(row=excel_row, column=col).fill = bundle_fill
            excel_row += 1

            # update report - document names
            for idx, tracker_id in enumerate(package_tracker_ids):
                tracker = cb_server.get_tracker(tracker_id=tracker_id)
                items = tracker.get_items(baseline=self._baseline)
                if not items:
                    print(f"No items found for tracker {tracker_id}. Skipping.")
                    continue
                items = items.to_dataframe()

                # iterate through rows and count how many rows have all elements in the 'Module Variant_pe' list containing 'CH63'
                ch63_only_item_cnt = 0
                if 'Module Variant_pe' in items.columns:
                    for row in items.select('Module Variant_pe').iter_rows():
                        # 'city' column is the second column, index 1
                        modul_variants = row[0]
                        if modul_variants is not None:
                            # ! count TBD as CH63 only -> If this is not the case, also update the public view of codebeamer
                            if all('CH63' in modul_variant or 'TBD' in modul_variant for modul_variant in
                                   modul_variants):
                                ch63_only_item_cnt += 1
                        else:
                            # count 'Unset' as CH63 only
                            ch63_only_item_cnt += 1

                # update document/tracker name
                tracker_name = tracker.name
                # update all items
                all_items = items.height
                # update ch63 items
                ch63_items = ch63_only_item_cnt

                print(f'\tTracker {tracker.name} contains {items.height} items, out of those {ch63_only_item_cnt} are CH63 only')

                #Tracker row
                ws.cell(row=excel_row, column=2, value=idx+1)
                ws.cell(row=excel_row, column=2).alignment = center
                ws.cell(row=excel_row, column=3, value=tracker_name)
                ws.cell(row=excel_row, column=4, value=all_items)
                ws.cell(row=excel_row, column=5, value=ch63_items)
                for col in range(2,6):
                    ws.cell(row=excel_row, column=col).border = border
                    ws.cell(row=excel_row, column=col).fill = bundle_fill
                excel_row+=1


            excel_row+=1
            #To fit columns when excel file is opened
            for column_cells in ws.columns:
                max_length = max(len(str(cell.value)) if cell.value else 0 for cell in column_cells)
                ws.column_dimensions[column_cells[0].column_letter].width = max_length + 2

            # export reqif
            print(f'Export trackers for package {package_idx} ...')
            self._export_reqif(cb_instance=self._cb_instance,
                               tracker_ids=package_tracker_ids,
                               bundle_name=self.get_bundle_name_str(time_str=self._formatted_time,
                                                                    bundle=package_idx,
                                                                    include_ext=False),
                               save_dir=self._output_dir,
                               baseline=self._baseline)

            print(f'Export for package {package_idx} - done\n')
        #self.apply_table_formatting(ws)
        # save report
        wb.save(self._output_dir /
                f'DAS-PROD-ECUS-ExportForME_{self._formatted_time}.xlsx')

        return self._output_dir

    def apply_table_formatting(self, ws):
        """
        Finds and formats each bundle's requirement table in the worksheet as an Excel Table.
        """
        current_row = 1
        max_row = ws.max_row

        while current_row <= max_row:
            cell_value = ws.cell(row=current_row, column=2).value  # Column B = index 2
            if cell_value and str(cell_value).startswith("Bundle Nr.:"):
                # Table header is 2 rows below
                header_row = current_row + 2
                start_col = 2  # Column B
                end_col = 5  # Column E

                # Find how many rows until the next "Bundle Nr." or empty row
                end_row = header_row
                while end_row <= max_row:
                    next_val = ws.cell(row=end_row + 1, column=2).value
                    if next_val and "Bundle Nr.:" in str(next_val):
                        break
                    end_row += 1

                # Create table ref like "B8:E14"
                ref = f"{ws.cell(row=header_row, column=start_col).coordinate}:{ws.cell(row=end_row, column=end_col).coordinate}"
                table_name = f"BundleTable_{header_row}"

                table = Table(displayName=table_name, ref=ref)
                style = TableStyleInfo(
                    name="TableStyleMedium9",
                    showFirstColumn=False,
                    showLastColumn=False,
                    showRowStripes=True,
                    showColumnStripes=False
                )
                table.tableStyleInfo = style
                ws.add_table(table)

                current_row = end_row + 1
            else:
                current_row += 1

    def get_tracker_view(self, cb_instance: str, tracker_id: int, include: str):
        '''
        This functions returns id and name of tracker view containing include string
        :param cb_instance: codebeamer instance that the view will be requested on
        :type cb_instance: str
        :param tracker_id: id of tracker to request view for
        :type tracker_id: int
        :param include: value that the name of the view should contain
        :type include: str
        :return: int, str (id, name)
        '''
        # initialize codebeamer server
        cb = calmpy.Server(url=cb_instance)

        # prepare request
        request_url = f"{cb.URL}/api/v3/trackers/{tracker_id}/reports"

        # request reports from server
        reports = cb.session.make_single_request(
            request_type="GET", request_url=request_url)

        # check response
        filtered_reports = [
            report for report in reports if include in report['name']]

        if len(filtered_reports) > 1:
            print(f'Found multiple views with names including "{include}", will take {filtered_reports[0]}')

        view = filtered_reports[0] if filtered_reports else None
        return view.get('id', None), view.get('name', None)

    def get_bundle_name_str(self, time_str: str, bundle: int, include_ext: bool = True) -> str:
        '''
        This functions returns the name of the bundle specified by parameters
        :param time_str: string of specific time
        :type time_str: str
        :param bundle: number of bundle to return the name for
        :type bundle: int
        :param include_ext: bool if ".regifz" should be included
        :type include_ext: bool
        :return: str (name of bundle)
        '''
        name = f'DAS-PROD-ECUS-ExportForME_Bundle-{bundle}_{time_str}'
        return name + '.reqifz' if include_ext else name

    def _export_reqif(self, cb_instance: str, tracker_ids: list, save_dir: str, bundle_name: str,
                      project_name: str = 'DAS-PROD-ECUS', baseline: calmpy.Baseline = None):
        '''
        This functions exports given trackers from specified project as a single reqif
        :param cb_instance: codebeamer instance that the view will be requested on
        :type cb_instance: str
        :param tracker_ids: ids of trackers export
        :type tracker_ids: list[int]
        :param save_dir: path of output folder
        :type save_dir: str
        :param bundle_name: name of bundle
        :type bundle_name: str
        :param project_name: id of project to export trackers from
        :type project_name: id
        :return: reqif data
        '''
        # initialize codebeamer server
        cb_server = calmpy.Server(url=cb_instance, readonly=False)

        # create tracker export configs
        tracker_export_configs = []
        for tracker_id in tracker_ids:
            tracker = cb_server.get_tracker(tracker_id=tracker_id)

            # get correct view for tracker
            view_id, view_name = self.get_tracker_view(cb_instance=cb_instance,
                                                       tracker_id=tracker_id,
                                                       include=VIEW_INCLUDE_STR)

            if view_name is None or view_id is None:
                print(f'tracker id {tracker_id} has no view which name includes "{VIEW_INCLUDE_STR}"!')
                break

            tracker_field_list = self.get_tracker_field_list(tracker)

            # generate regif export config based on view
            reqif_export_config, _ = tracker.get_reqif_export_config(tracker_field_list=tracker_field_list,
                                                                     tracker_view=view_id)
            tracker_export_configs.append(reqif_export_config)
        # export reqif
        reqif = cb_server.get_project(project=project_name).export_as_reqif(destination=bundle_name,
                                                                            tracker_list=tracker_export_configs,
                                                                            baseline=baseline)

        # save reqif data to .reqifz file
        with open(save_dir / (bundle_name + '.reqifz'), "wb") as f:
            f.write(reqif.getbuffer())

    def get_tracker_field_list(self, tracker: calmpy.Tracker) -> list:
        '''
        This functions return the list of fields filtered by export type (self)
        :param tracker: tracker to extract fields from
        :type tracker: calmpy.Tracker
        :return: list of fields to export
        '''
        field_list = [field.label for field in tracker.get_field_config()]
        match self._export_type:
            case EXPORT_TYPE.ALL:
                return field_list
            case EXPORT_TYPE.SUPPLIER_MOBILEYE:
                return self.remove_supplier_feedback_fields(exception_supplier_str='MobilEye',
                                                            field_list=field_list)
            case EXPORT_TYPE.SUPPLIER_VALEO:
                return self.remove_supplier_feedback_fields(exception_supplier_str='Valeo',
                                                            field_list=field_list)
            case EXPORT_TYPE.SUPPLIER_CONTINENTAL:
                return self.remove_supplier_feedback_fields(exception_supplier_str='Continental',
                                                            field_list=field_list)
            case EXPORT_TYPE.SUPPLIER_MAGNA:
                return self.remove_supplier_feedback_fields(exception_supplier_str='Magna',
                                                            field_list=field_list)
            case EXPORT_TYPE.SUPPLIER_APTIV:
                return self.remove_supplier_feedback_fields(exception_supplier_str='Aptiv',
                                                            field_list=field_list)
        return []

    def remove_supplier_feedback_fields(self, exception_supplier_str: str, field_list: list) -> list:
        '''
        This functions supplier feedback fields from list of field with exepction of specified supplier
        :param exception_supplier_str: string of supplier to except from removal
        :type exception_supplier_str: str
        :param field_list: list of fields
        :type field_list: list
        :return: list of fields to export
        '''
        status_audi_to_supplier_re = r'.*Status Audi to .*'
        status_supplier_to_audi_re = r'.*Status .* to Audi.*'
        comment_audi_to_supplier_re = r'.*Comment Audi to .*'
        comment_supplier_to_audi_re = r'.*Comment .* to Audi.*'

        field_list = self._remove_matching_items(field_list=field_list,
                                                 pattern=status_audi_to_supplier_re,
                                                 exception_str=exception_supplier_str)

        field_list = self._remove_matching_items(field_list=field_list,
                                                 pattern=status_supplier_to_audi_re,
                                                 exception_str=exception_supplier_str)

        field_list = self._remove_matching_items(field_list=field_list,
                                                 pattern=comment_audi_to_supplier_re,
                                                 exception_str=exception_supplier_str)

        field_list = self._remove_matching_items(field_list=field_list,
                                                 pattern=comment_supplier_to_audi_re,
                                                 exception_str=exception_supplier_str)
        return field_list

    def _remove_matching_items(self, field_list, pattern, exception_str) -> list:
        '''
        This functions removes items based on regular expression, there are specified exceptions.
        :param pattern: regular expression for removal purpose
        :type pattern: str
        :param exception_str: the strings to exclude even when matching the regular expression
        :type exception_str: str
        :param field_list: list of fields
        :type field_list: list
        :return: list of fields to export
        '''
        regex = re.compile(pattern=pattern)
        return [item for item in field_list if not regex.match(item) or exception_str in item]


def add_arguments(parser: ArgumentParser):
    '''
    This functions handles the arguments for this script
    :param parser: argument parser including arguments to parse
    :type parser: ArgumentParser
    '''
    parser.add_argument('--cb_instance',
                        help='specifies on which instance the updates are made ("Prod", "QS", ...)',
                        type=str)
    parser.add_argument('--tracker_ids_json',
                        help='json including tracker ids to update',
                        type=str)
    parser.add_argument('--baseline',
                        help='id of baseline for data to export',
                        type=int,
                        default=None)
    parser.add_argument('--export_type', type=EXPORT_TYPE, choices=list(EXPORT_TYPE), default=EXPORT_TYPE.ALL,
                        help='type of export to execute (manages fields to export)')
    parser.add_argument('--output_dir', type=str,
                        help='Path to output directory')


def main() -> int:
    '''
    This functions handles the export of trackers on given server including an export report
    '''

    # argument parsing
    parser = ArgumentParser(prog='codebeamer_exporter',
                            description='Exports given trackers and creates report')
    add_arguments(parser=parser)
    args = parser.parse_args()

    codebeamer_exporter = CodebeamerExporter(cb_instance=args.cb_instance,
                                             tracker_ids_json=args.tracker_ids_json,
                                             baseline=args.baseline,
                                             export_type=args.export_type,
                                             output_dir_base=args.output_dir)
    codebeamer_exporter.export()


if __name__ == '__main__':
    main()
