from argparse import ArgumentParser
from pathlib import Path
import json
import calmpy
import time
import re
from tqdm import tqdm
import pandas as pd
from openpyxl import load_workbook
from dataclasses import dataclass
from typing import Tuple, Dict
import calmpy.exceptions
from src.decision_executor.decision_executor import Status


@dataclass
class Update:
    """
    A class that represents an codebeamer update
    """
    field_name: str
    command: str
    value: str


class CodebeamerUpdater:
    """
    CodebeamerUpdater - A class that will handle the updates of codebeamer based on a specific template
    """
    UPDATE_TRACKER_ID_IDX = 0
    UPDATE_ITEM_ID_IDX = 1
    UPDATE_FILTER_IDX = 3
    UPDATE_COMMENT_IDX = 4
    UPDATE_COMMAND_START_IDX = 5
    UPDATE_FIELD_NAME_START_IDX = 6

    ADD_TRACKER_ID_IDX = 0
    ADD_PREDECESSOR_ITEM_ID_IDX = 1
    ADD_SUCCESSOR_ITEM_ID_IDX = 2
    ADD_PARENT_ITEM_IDX = 3
    ADD_COMMENT_IDX = 4
    ADD_FIELD_START_IDX = 5
    ADD_TYPE_IDX = 5
    ADD_DESCRIPTION_IDX = 6
    ADD_MODULE_VARIANT_IDX = 7
    ADD_SAFETY_RELEVANCE_IDX = 8
    ADD_SECURITY_RELEVANCE_IDX = 9
    ADD_SUPPLIER_IDX = 10
    ADD_CR_IDX = 10

    COPY_SRC_TRACKER_ID_IDX = 0
    COPY_SRC_ITEM_ID_IDX = 1
    COPY_DST_TRACKER_ID_IDX = 2
    COPY_DST_PREDECESSOR_ITEM_ID_IDX = 3
    COPY_DST_SUCCESSOR_ITEM_ID_IDX = 4
    COPY_DST_PARENT_ITEM_ID_IDX = 5
    COPY_COMMENT_IDX = 6

    CMD_REMOVE_VALUE = 'REMOVE_VALUE'
    CMD_ADD_VALUE = 'ADD_VALUE'
    CMD_SET_VALUE = 'SET_VALUE'
    CMD_SUBSTITUTE_VALUE = 'SUBSTITUTE_VALUE'

    def __init__(self, cb_instance: str, update_template: Path, output_dir_base: Path, copy_field_value_mapping: Path=None) -> None:
        """
        Constructs an object of DecisionExecutor that will handle the execution of CCD decisions

        :param cb_instance: The url or short name for Codebeamer instance to work with
        :type cb_instance: str
        :param update_template: path to .xlsx with desired changes in specific format
        :type update_template: Path
        :param copy_field_value_mapping: path to .json mapping file for field value mappings (used in copy)
        :type copy_field_value_mapping: Path
        :param output_dir_base: path to the output directory where results should be saved to
        :type output_dir_base: str
        :return: None
        """
        # save parameters
        self._cb_instance = cb_instance
        self._update_template = update_template
        self._copy_field_value_mapping = copy_field_value_mapping
        self._output_dir_base = output_dir_base

        # get the current time
        self._current_time = time.localtime()

        # format the current time
        self._formatted_time = time.strftime(
            "%Y-%b-%d", self._current_time)

        # prepare output folder
        self._output_dir = Path(
            f'{self._output_dir_base}/cb_updates_{self._formatted_time}')
        if not self._output_dir.exists():
            self._output_dir.mkdir(parents=True, exist_ok=True)

        # load mappings
        if copy_field_value_mapping:
            self._copy_field_value_json = self.__load_json(config_file_path=copy_field_value_mapping)
            self._copy_field_map_template2ch63 = {entry['template']: entry for entry in self._copy_field_value_json['field_mappings']}

        else:
            self._copy_field_value_json = {}
            self._copy_field_map_template2ch63 = {}

        # load requested updates template
        self._wb = load_workbook(self._update_template)
        self._ws_updates = self._wb['FIELD_UPDATE']
        self._ws_add = self._wb['ADD_ITEM']
        self._ws_copy = self._wb['ADD_ITEM_COPY']

        # setup codebeamer server
        self._cb_server = calmpy.Server(url=self._cb_instance, readonly=False)

    def update_item(self, item: calmpy.Item, fields: Dict = {}) -> Tuple[Dict, Status, str]:
        '''
        This functions handles the update of an item on given server with prodivded field data

        :param item: item to update
        :type item: calmpy.Item
        :param fields: field names / value to update
        :type fields: Dict
        :return: Tuple[Dict, Status, str] (Response of server, Status, msg)
        '''
        try:
            # update item in codebeamer
            response = item.update_fields(fields=fields)

            # check if update was successfull
            item_ref = self._cb_server.get_item(item_id=item.id)

            status = Status.SUCCESS
            msg = ''
            for field in fields:
                if item_ref[field] != item[field]:
                    msg += f'field "{field}" was not updated correctly, requested:"{
                        item[field]}", actual:"{item_ref[field]}";'
                    status = Status.FAILED

            return response, status, msg
        except calmpy.exceptions.ServerError as e:
            return response, Status.FAILED, e

    def insert_item_with_hierarchy(self, item_dict: dict, tracker_id: int, reference_item_id: int, reference_is_predecessor: bool = True,
                                   reference_is_parent = None) -> Tuple[Status, calmpy.Item, str]:
        """
        Creates item with provided data for a specified reference id

        :param reference_is_predecessor: information if reference id is the predecessor or successor
        :type reference_is_predecessor: bool
        :param reference_is_parent: information if reference id is the parent
        :type reference_is_parent: bool
        :param reference_item_id: id of item for reference to hierarchy
        :type reference_item_id: int
        :param tracker_id: id of tracker where to insert item to
        :type tracker_id: str
        :param item_dict: data of item to add
        :type item_dict: dict
        :return: item that got added
        :type calmpy.Item
        """
        try:
            new_item = self._cb_server.get_tracker(
                tracker_id=int(tracker_id)).create_item(fields=item_dict)

            # update hierarchy
            status, msg = self.update_parent(reference_item_id=reference_item_id,
                                             item_id=new_item.id,
                                             reference_is_predecessor=reference_is_predecessor,
                                             reference_is_parent=reference_is_parent)
        except calmpy.exceptions.ServerError as e:
            print(e)
            print(f'Problem in creating item with data: {item_dict}')
            return Status.FAILED, None, e
        return status, new_item, msg

    def update_parent(self, reference_item_id: int, item_id: int, reference_is_predecessor: bool = True,
                      reference_is_parent = None) -> Tuple[Status, str]:
        """
        Updates item hierarchy in codebeamer so that item is item after reference item

        :param reference_item_id: id of item that is the predecessor to the item with item_id
        :type reference_item_id: int
        :param item_id: id of item to update the hierarchy for
        :type item_id: int
        :param reference_is_predecessor: information if reference item is predecessor or successor
        :type reference_is_predecessor: bool
        :param reference_is_parent: information if reference id is the parent
        :type reference_is_parent: bool
        :return: Status and message
        :type Tuple[Status, str]
        """
        if reference_is_parent:
            parent_id = reference_item_id
        else:
            reference_item = self._cb_server.get_item(item_id=reference_item_id)
            if reference_item['parent'] is not None:
                parent_id = reference_item['parent'].id
            else:
                return Status.SUCCESS, 'Could not update parent due to no parent available (reference item on top level)'

        # url of children for parent
        children_url = f'{self._cb_server.query.SWAGGER_URL_V3}/items/' + \
            f'{int(parent_id)}/children'

        # get all current item children
        response = self._cb_server.session.make_paged_requests(request_url=children_url,
                                                               request_type='GET',
                                                               is_readonly_operation=True,
                                                               entries=500)

        # check if its more than 1 page
        if response.total > 1:
            print(f'parent {parent_id} has more than 500 children.' +
                  f' Hierarchy of item {item_id} will be ignored')
            return Status.FAILED, f'Item {parent_id} has more than 500 children, update will not work'

        # extract children list
        parent_child_refs = response.all[0].content['itemRefs']

        # convert to list of children ids
        existing_children_ids = [children['id']
                                 for children in parent_child_refs]

        # check if item is already a child
        if item_id not in existing_children_ids:
            if reference_is_parent == None or reference_is_parent == False:
                for idx, child in enumerate(parent_child_refs):
                    if child['id'] == reference_item_id:
                        if reference_is_predecessor:  # reference is predecessor -> insert child after reference item
                            parent_child_refs.insert(
                                idx + 1, {'id': int(item_id), 'type': 'TrackerItemReference'})
                            break
                        else:  # reference is succsessor -> insert child before reference item
                            parent_child_refs.insert(
                                idx, {'id': int(item_id), 'type': 'TrackerItemReference'})
                            break
            else:
                parent_child_refs.append({'id': int(item_id), 'type': 'TrackerItemReference'})

            # transform to query data
            children_data = {'children': parent_child_refs}

            # update hierarchy
            try:
                response = self._cb_server.session.make_single_request(
                    request_url=children_url, request_type='PUT', data=children_data)
            except ...:
                return Status.FAILED, f'ERROR: {item_id} was not set as child of {parent_id}'
            return Status.SUCCESS, f'{item_id} was successfully set as child of {parent_id} (after {reference_item_id})'
        return Status.SUCCESS, f'{item_id} was already a child of {parent_id}'

    def execute_updates(self) -> Path:
        '''
        This functions handles requested updates for codebeamer

        :return: path to report of update modifications
        :type Path
        '''
        report_path = (Path(self._output_dir) /
                       f'{Path(self._update_template).stem}_updates.xlsx')

        # prepare report dataframe
        exec_updates_df = pd.DataFrame(
            columns=(['Tracker ID', 'Item ID', 'Command', 'Field Name', 'Value', 'Field Value Old', 'Field Value New', 'Comment', 'Status', 'Execution Date', 'Request (Row)']))

        # extract header info
        headers = [cell.value for cell in self._ws_updates[1]]

        # execute each requested update
        for idx, row in enumerate(self._ws_updates.iter_rows(min_row=2, values_only=True)):
            tracker_id = row[CodebeamerUpdater.UPDATE_TRACKER_ID_IDX]

            if tracker_id is None:
                print('Updates - Done')
                return report_path

            item_id = row[CodebeamerUpdater.UPDATE_ITEM_ID_IDX]
            comment = row[CodebeamerUpdater.UPDATE_COMMENT_IDX]
            filters = row[CodebeamerUpdater.UPDATE_FILTER_IDX]
            filters = filters.split('\n') if filters else filters

            # create list of updates
            updates = []
            for row_idx in range(CodebeamerUpdater.UPDATE_COMMAND_START_IDX, len(row)-1, 2):
                if row[row_idx] is not None:
                    if headers[row_idx+1] == 'Description' or headers[row_idx+1] == 'Summary':
                        updates.append(Update(field_name=headers[row_idx+1], command=row[row_idx], value=[row[row_idx+1]]))
                    else:
                        updates.append(Update(field_name=headers[row_idx+1], command=row[row_idx], value=row[row_idx+1].split('\n')))

            # get items that should be updates
            items = self._cb_server.get_tracker(tracker_id=tracker_id).get_items(
            ) if item_id is None else [self._cb_server.get_tracker(tracker_id=tracker_id).get_item(item=item_id)]

            # apply filter
            if filters:
                seperated_filters = []
                for filter in filters:
                    filter_split = filter.split('=')
                    field_value = filter_split[1]

                    # if value is list -> prepare data
                    if filter_split[1].startswith('[') and filter_split[1].endswith(']'):
                        field_value = filter_split[1].replace(
                            '[', '').replace(']', '')
                        field_value = field_value.split(',')
                        field_value.sort()

                    seperated_filters.append({'field_name': filter_split[0],
                                              'field_value': field_value})

                filtered_items = []
                for item in items:
                    for filter in seperated_filters:
                        if filter['field_name'] in item:
                            if isinstance(filter['field_value'], list):
                                # check if field to be filtered is None/empty
                                if item[filter['field_name']] is None:
                                    break
                                # check if all entries from filter are in item
                                if not all(entry in item[filter['field_name']] for entry in filter['field_value']):
                                    break
                            else:
                                if filter['field_value'] != item[filter['field_name']]:
                                    break
                        else:
                            # specified filter is not correct
                            break
                    else: # executed when for is done successfully
                        filtered_items.append(item)
                items = filtered_items

            print(f'Update {idx}: {
                  len(items)} items (applied filters) need to be updated with {updates}')

            # apply update to each item
            for item in items:
                updates_reports = []
                for update in updates:
                    report_data_dict = {
                        'Tracker ID': tracker_id,
                        'Item ID': item.id,
                        'Command': update.command,
                        'Field Name': update.field_name,
                        'Value': update.value,
                        'Field Value Old': item[update.field_name].copy() if isinstance(item[update.field_name], list) else item[update.field_name],
                        'Comment': comment,
                        'Request (Row)': idx + 2
                    }
                    # prepare update data
                    match update.command:
                        case CodebeamerUpdater.CMD_REMOVE_VALUE:
                            item = self.execute_command_REMOVE_VALUE(item=item,
                                                                     update=update)
                        case CodebeamerUpdater.CMD_ADD_VALUE:
                            item = self.execute_command_ADD_VALUE(item=item,
                                                                  update=update)
                        case CodebeamerUpdater.CMD_SET_VALUE:
                            if update.field_name == 'Status':
                                status, msg = self.set_item_to_state(item_id=item.id,
                                                                     state_name=update.value[0])
                                report_data_dict['Status'] = f'{
                                    status}, message: {msg}' if msg != '' else status
                            item = self.execute_command_SET_VALUE(item=item,
                                                                  update=update)
                        case CodebeamerUpdater.CMD_SUBSTITUTE_VALUE:
                            item = self.execute_command_SUBSTITUTE_VALUE(item=item,
                                                                         update=update)

                    # update report data
                    report_data_dict['Field Value New'] = item[update.field_name]

                    # only add if something changed
                    if report_data_dict['Field Value New'] != report_data_dict['Field Value Old']:
                        updates_reports.append(report_data_dict)

                # add comment if given
                if comment is not None:
                    # add comment if its not already added
                    if not self.check_is_already_comment(comment=comment, item=item):
                        try:
                            item.add('Comment', comment_text=comment)
                        except:
                            print(f'Could not add comment to {item.id}')

                    # check if there are any updates
                    if not updates_reports:
                        # Add executed decision to dataframe
                        exec_updates_df.loc[len(exec_updates_df)] = {
                            'Tracker ID': tracker_id,
                            'Item ID': item.id,
                            'Comment': comment,
                            'Request (Row)': idx + 2,
                            'Status': Status.SUCCESS,
                            'Execution Date': time.strftime("%Y-%b-%d %H:%M:%S",
                                                            time.localtime())
                        }

                # update item
                if updates_reports:
                    response, status, msg = self.update_item(item=item,
                                                             fields={update_report['Field Name']: update_report['Field Value New'] for update_report in updates_reports if update_report['Field Name'] != 'Status'})

                    for updates_report in updates_reports:
                        # Add status
                        if updates_report['Field Name'] != 'Status':
                            updates_report['Status'] = f'{status}, message: {
                                msg}, response: {response}' if msg != '' else status

                        # Add execution date
                        updates_report['Execution Date'] = time.strftime("%Y-%b-%d %H:%M:%S",
                                                                         time.localtime())

                        # Add executed decision to dataframe
                        exec_updates_df.loc[len(exec_updates_df)
                                            ] = updates_report

            # update report
            self.__save_df_as_xlsx(df=exec_updates_df,
                                   data_file_path=report_path)
        print('Updates - Done')
        return report_path

    def execute_adds(self) -> Path:
        '''
        This functions handles requested insertion of items for codebeamer

        :return: path to report of add modifications
        :type Path
        '''
        report_path = (Path(self._output_dir) /
                       f'{Path(self._update_template).stem}_adds.xlsx')

        # prepare report dataframe
        exec_add_df = pd.DataFrame(
            columns=(['Tracker ID', 'Item ID', 'Command', 'Status', 'Execution Date', 'Request (Row)', 'Field Data']))

        # extract header info
        headers = [cell.value for cell in self._ws_add[1]]

        added_items_by_row_idx = {}
        # execute each requested update
        for idx, row in enumerate(self._ws_add.iter_rows(min_row=2, values_only=True)):
            tracker_id = row[CodebeamerUpdater.ADD_TRACKER_ID_IDX]

            if tracker_id is None:
                # tracker_id empty -> no more items to add
                print('Add-Done')
                return report_path

            # extract requested hierarchy by reference id
            predecessor_id = row[CodebeamerUpdater.ADD_PREDECESSOR_ITEM_ID_IDX]
            successor_id = row[CodebeamerUpdater.ADD_SUCCESSOR_ITEM_ID_IDX]
            parent_id = row[CodebeamerUpdater.ADD_PARENT_ITEM_IDX]

            reference_id = None
            reference_is_predecessor = None
            reference_is_parent = None
            if predecessor_id is not None:
                reference_id = predecessor_id
                reference_is_predecessor = True
            elif successor_id is not None:
                reference_id = successor_id
                reference_is_predecessor = False
            elif parent_id is not None:
                reference_id = parent_id
                reference_is_parent = True

            # check if reference id was basis of newly created item in this iteration
            if reference_id in added_items_by_row_idx:
                # get actual reference
                reference_id = added_items_by_row_idx[reference_id]

            comment = row[CodebeamerUpdater.ADD_COMMENT_IDX]

            fields = {'Tracker': tracker_id}
            for col_idx in range(CodebeamerUpdater.ADD_FIELD_START_IDX, len(row)):
                if row[col_idx] is not None:
                    if '\n' in row[col_idx] and headers[col_idx] != 'Description':  # input should be a list
                        # split based on new lines
                        split = row[col_idx].split('\n')

                        # remove empty values (e.g. introduced by additional new line)
                        split_filter_empty = [item for item in split if item.strip()]
                        fields[headers[col_idx]] = split_filter_empty
                    else:  # input is atomic value
                        fields[headers[col_idx]] = row[col_idx]

            if 'Type' in fields:
                if fields['Type'] == 'Folder':
                    fields['Summary'] = fields['Description']

            # add item
            status, item, msg = self.insert_item_with_hierarchy(item_dict=fields,
                                                                tracker_id=tracker_id,
                                                                reference_item_id=reference_id,
                                                                reference_is_predecessor=reference_is_predecessor,
                                                                reference_is_parent=reference_is_parent)
            status = Status.FAILED if item is None else Status.SUCCESS

            # add comment if given
            if comment is not None and status == Status.SUCCESS:
                item.add('Comment', comment_text=comment)

            report_data_dict = {
                'Tracker ID': fields['Tracker'],
                'Item ID': item.id if item is not None else None,
                'Command': 'ADD_ITEM',
                'Request (Row)': idx + 2,
                'Field Data': {field: item[field] for field in item} if item is not None else None,
                'Status': status if status == Status.SUCCESS else f'{status} - {msg}',
                'Execution Date': time.strftime("%Y-%b-%d %H:%M:%S",
                                                time.localtime())
            }

            if status == Status.SUCCESS:
                added_items_by_row_idx[idx + 2] = item.id

            # Add executed decision to dataframe
            exec_add_df.loc[len(exec_add_df)] = report_data_dict

            # update report
            self.__save_df_as_xlsx(df=exec_add_df, data_file_path=report_path)

            print(f'Request (row: {idx + 2}) was executed with status {status if status == Status.SUCCESS else f'{status} - {msg}'}')
        return report_path

    def execute_template_copies(self) -> Path:
        '''
        This functions handles requested copies of items from template trackers to other trackers

        :return: path to report of copied items
        :type Path
        '''
        if not (self._copy_field_value_json and self._copy_field_value_mapping):
            print('No field value mapping provided - copies will not be executed')
            return

        report_path = (Path(self._output_dir) /
                       f'{Path(self._update_template).stem}_template_copies.xlsx')

        # prepare report dataframe
        exec_copy_df = pd.DataFrame(
            columns=(['Tracker ID', 'Item ID', 'Status', 'Execution Date', 'Request (Row)', 'Field Data']))

        # keep track of items that got added (to build hierarchy on top of that)
        copied_items = {}

        # execute each requested update
        for idx, row in enumerate(self._ws_copy.iter_rows(min_row=2, values_only=True)):
            src_tracker_id = row[CodebeamerUpdater.COPY_SRC_TRACKER_ID_IDX]

            if src_tracker_id is None:
                # tracker_id empty -> no more items to add
                print('Copy-Done')
                return report_path

            src_item_id = row[CodebeamerUpdater.COPY_SRC_ITEM_ID_IDX]
            dst_tracker_id = row[CodebeamerUpdater.COPY_DST_TRACKER_ID_IDX]
            predecessor_id = row[CodebeamerUpdater.COPY_DST_PREDECESSOR_ITEM_ID_IDX]
            successor_id = row[CodebeamerUpdater.COPY_DST_SUCCESSOR_ITEM_ID_IDX]
            parent_id = row[CodebeamerUpdater.COPY_DST_PARENT_ITEM_ID_IDX]

            src_item = self._cb_server.get_item(src_item_id)

            if src_item is None or src_item_id is None:
                error_msg = f'Could not retrieve item {src_item_id} from server.'
                print(error_msg)
                report_data_dict = {
                    'Tracker ID': dst_tracker_id,
                    'Item ID': None,
                    'Request (Row)': idx + 2,
                    'Field Data': None,
                    'Status': f'{Status.FAILED} - {error_msg}',
                    'Execution Date': time.strftime("%Y-%b-%d %H:%M:%S",
                                                    time.localtime())
                }

                # Add executed decision to dataframe
                exec_copy_df.loc[len(exec_copy_df)] = report_data_dict
                continue

            reference_id = None
            reference_is_predecessor = None
            reference_is_parent = None
            if predecessor_id is not None:
                reference_id = predecessor_id
                reference_is_predecessor = True
            elif successor_id is not None:
                reference_id = successor_id
                reference_is_predecessor = False
            elif parent_id is not None:
                reference_id = parent_id
                reference_is_parent = True

            # check if reference id was basis of newly created item in this iteration
            if reference_id in copied_items:
                # get actual reference
                reference_id = copied_items[reference_id]
            else:
                # want to use reference that is not created yet -> skip
                if reference_id in self._ws_copy[CodebeamerUpdater.COPY_SRC_ITEM_ID_IDX]:
                    report_data_dict = {
                        'Tracker ID': fields['Tracker'],
                        'Item ID': None,
                        'Request (Row)': idx + 2,
                        'Field Data': {field: item[field] for field in item} if item is not None else None,
                        'Status': f'{Status.SKIPPED} - referenced id is also a source id and was not created yet',
                        'Execution Date': time.strftime("%Y-%b-%d %H:%M:%S",
                                                        time.localtime())
                    }

                    # Add executed decision to dataframe
                    exec_copy_df.loc[len(exec_copy_df)] = report_data_dict

                    # update report
                    self.__save_df_as_xlsx(df=exec_copy_df, data_file_path=report_path)
                    continue

            comment = None

            fields = {'Tracker': dst_tracker_id}
            field_status = None
            for field in src_item:
                # if field is in mapping -> do not ignore
                if field in self._copy_field_map_template2ch63:
                    template2ch63_map = self._copy_field_map_template2ch63[field]

                    # status can not be set direclty -> use workflow
                    if field == 'Status':
                        if template2ch63_map['use_value_mapping'] == False:
                            field_status = src_item[field]
                        elif src_item[field] in template2ch63_map['template_to_ch63_values']:
                            field_status = template2ch63_map['template_to_ch63_values'][src_item[field]]
                        else:
                            print(f'Field will be ignored due to no mapping requested but not found:\tfield={field}\tfield value={src_item[field]}')
                        continue

                    # attachments can not be set direclty -> use add_attachments
                    if field == 'Attachments':
                        continue

                    # no value mapping should be used -> use src item field value
                    if template2ch63_map['use_value_mapping'] == False:
                        if src_item[field] != None:
                            fields[template2ch63_map['ch63']] = src_item[field]
                            continue

                    # src item value is in field value mapping -> use mapped value
                    if isinstance(src_item[field], list):
                        for entry in src_item[field]:
                            if entry in template2ch63_map['template_to_ch63_values']:
                                if template2ch63_map['ch63'] in fields:
                                    fields[template2ch63_map['ch63']].append(entry)
                                else:
                                    fields[template2ch63_map['ch63']] = [entry]
                            else:
                                if entry is not None:
                                    print(f'Field will be ignored due to no mapping found:\tfield={field}\tfield value={entry}')
                    else:
                        if str(src_item[field]) in template2ch63_map['template_to_ch63_values']:
                            fields[template2ch63_map['ch63']] = template2ch63_map['template_to_ch63_values'][str(src_item[field])]
                            continue
                        else:
                            if src_item[field] is not None:
                                print(f'Field will be ignored due to no mapping found:\tfield={field}\tfield value={src_item[field]}')
                elif 'Format' in field: # have same format as src
                    fields[field] = src_item[field]


            # add item
            status, item, msg = self.insert_item_with_hierarchy(item_dict=fields,
                                                                tracker_id=dst_tracker_id,
                                                                reference_item_id=reference_id,
                                                                reference_is_predecessor=reference_is_predecessor,
                                                                reference_is_parent=reference_is_parent)
            status = Status.FAILED if item is None else Status.SUCCESS

            # set status correctly
            if field_status and status == Status.SUCCESS:
                status, msg = self.set_item_to_state(item_id=item.id, state_name=field_status)

            # update copied items
            if status == Status.SUCCESS:
                copied_items[src_item_id] = item.id

            # add attachments
            if status == Status.SUCCESS:
                # get src attachments
                attachments = src_item.get_attachments()

                if attachments:
                    try:
                        # add dst attachments
                        for attachment in attachments:
                            item.add_attachment(attachment=attachment)
                    except:
                        status = Status.FAILED

            comment = row[CodebeamerUpdater.COPY_COMMENT_IDX]

            # add comment if given
            if status == Status.SUCCESS:
                # add standard comment
                item.add('Comment', comment_text=f'Item added as copy of item with id {src_item_id} from tracker with id {src_tracker_id}')

                if comment is not None:
                    item.add('Comment', comment_text=comment)

            report_data_dict = {
                'Tracker ID': fields['Tracker'],
                'Item ID': item.id if item is not None else None,
                'Request (Row)': idx + 2,
                'Field Data': {field: item[field] for field in item} if item is not None else None,
                'Status': status if status == Status.SUCCESS else f'{status} - {msg}',
                'Execution Date': time.strftime("%Y-%b-%d %H:%M:%S",
                                                time.localtime())
            }

            # Add executed decision to dataframe
            exec_copy_df.loc[len(exec_copy_df)] = report_data_dict

            # update report
            self.__save_df_as_xlsx(df=exec_copy_df, data_file_path=report_path)
        return report_path

    def execute_command_REMOVE_VALUE(self, item: calmpy.Item, update: Update) -> calmpy.Item:
        '''
        This functions handles the REMOVE_VALUE command update to item members

        :param item: The item whose members will be updates
        :type item: calmpy.Item
        :param update: Data of update to be executed
        :type update: Update
        :return: calmpy.Item
        '''
        if update.command != CodebeamerUpdater.CMD_REMOVE_VALUE:
            print(f'Provided command {update.command} was requested to be processed as {
                  CodebeamerUpdater.CMD_REMOVE_VALUE}')
            return item

        if isinstance(item[update.field_name], list):
            for value in update.value:
                # check if value is in field
                if value in item[update.field_name]:
                    # remove value from list
                    item[update.field_name].remove(value)
            if item[update.field_name] == []:
                item[update.field_name] = None
        else:
            # atomic value -> unset
            item[update.field_name] = None

        return item

    def execute_command_ADD_VALUE(self, item: calmpy.Item, update: Update) -> calmpy.Item:
        '''
        This functions handles the ADD_VALUE command update to item members

        :param item: The item whose members will be updates
        :type item: calmpy.Item
        :param update: Data of update to be executed
        :type update: Update
        :return: calmpy.Item
        '''
        if update.command != CodebeamerUpdater.CMD_ADD_VALUE:
            print(f'Provided command {update.command} was requested to be processed as {
                  CodebeamerUpdater.CMD_ADD_VALUE}')
            return item

        if isinstance(item[update.field_name], list):
            for value in update.value:
                if value not in item[update.field_name] and not value.isspace() and value != '':
                    # add value to list
                    item[update.field_name].append(value)
        else:
            # atomic value -> set value
            item[update.field_name] = str(
                item[update.field_name]) + ''.join([update_value for update_value in update.value])

        return item

    def execute_command_SET_VALUE(self, item: calmpy.Item, update: Update) -> calmpy.Item:
        '''
        This functions handles the SET_VALUE command update to item members

        :param item: The item whose members will be updates
        :type item: calmpy.Item
        :param update: Data of update to be executed
        :type update: Update
        :return: calmpy.Item
        '''
        if update.command != CodebeamerUpdater.CMD_SET_VALUE:
            print(f'Provided command {update.command} was requested to be processed as {
                  CodebeamerUpdater.CMD_SET_VALUE}')
            return item

        if isinstance(item[update.field_name], list):
            # reset value
            item[update.field_name] = []
            for value in update.value:
                # add value to list
                item[update.field_name].append(value)
        else:
            # atomic value -> set value
            item[update.field_name] = update.value[0]

        return item

    def execute_command_SUBSTITUTE_VALUE(self, item: calmpy.Item, update: Update) -> calmpy.Item:
        '''
        This functions handles the SUBSTITUTE_VALUE command update to item members

        :param item: The item whose members will be updates
        :type item: calmpy.Item
        :param update: Data of update to be executed
        :type update: Update
        :return: calmpy.Item
        '''
        if update.command != CodebeamerUpdater.CMD_SUBSTITUTE_VALUE:
            print(f'Provided command {update.command} was requested to be processed as {
                  CodebeamerUpdater.CMD_SUBSTITUTE_VALUE}')
            return item

        # iterate through all substitute requests
        for value_old_idx in range(0, len(update.value), 2):
            if value_old_idx + 1 >= len(update.value):
                continue

            # extract old+new value
            old_value = update.value[value_old_idx].split('Old:')[1]
            new_value = update.value[value_old_idx + 1].split('New:')[1]

            # replace values
            if isinstance(item[update.field_name], list):
                item[update.field_name] = [new_value if value ==
                                           old_value else value for value in item[update.field_name]]
            else:
                item[update.field_name] = item[update.field_name].replace(
                    old_value, new_value)

        return item

    def set_item_to_state(self, item_id: int, state_name: str) -> Tuple[Status, str]:
        """
        Updates the 'Status' field of given item in Codebeamer to specified state

        :param item_id: id of item which status will be updated to specified state
        :type item_id: int
        :param state_name: name of the state the item should be updated to
        :type state_name: str
        :return: status of the update operation, message
        :type Tuple[Status, str]
        """
        if pd.isna(item_id):
            return Status.FAILED, 'Given item id is empty'

        # Get valid transitions for this item
        request_transition_url = f"{
            self._cb_server.query.SWAGGER_URL_V3}/items/{int(item_id)}/transitions"

        response_transition = self._cb_server.session.make_single_request(
            request_url=request_transition_url,
            request_type='GET',
            is_readonly_operation=True)

        # Get transition that ends in 'Obsolete' if exists
        state_transition = next((transition.get("toStatus") for transition in response_transition
                                 if transition.get("toStatus")['name'] == state_name), None)

        if state_transition is not None:
            # URL of item
            request_url = f"{
                self._cb_server.query.SWAGGER_URL_V3}/items/{int(item_id)}"

            # get current data of item
            response_item = self._cb_server.session.make_single_request(
                request_url=request_url,
                request_type='GET',
                is_readonly_operation=True)

            # Update state data
            response_item['status'] = state_transition

            try:
                # Update item
                response = self._cb_server.session.make_single_request(request_url=request_url,
                                                                       request_type='PUT',
                                                                       data=response_item)
            except calmpy.exceptions.ServerError as e:
                return Status.FAILED, '/'.join([failed_response.content['message']
                                                for failed_response in e.failed_responses])

            # check if transition was successfull
            request_transition_url = f"{
                self._cb_server.query.SWAGGER_URL_V3}/items/{int(item_id)}/transitions"

            response_transition = self._cb_server.session.make_single_request(
                request_url=request_transition_url,
                request_type='GET',
                is_readonly_operation=True)

            current_state = next((transition.get("fromStatus")['name']
                                 for transition in response_transition), None)

            if current_state == state_name:
                return Status.SUCCESS, 'Success'
            else:
                return Status.FAILED, 'Positive feedback from API but result does not match'
        else:
            current_state = next((transition.get("fromStatus")['name']
                                 for transition in response_transition), None)
            if current_state == state_name:
                return Status.SUCCESS, ''
            return (Status.FAILED,
                    f'There is no valid transition to "{state_name}" from current Status ' +
                    f'"{current_state}" for item {item_id}')

    def check_is_already_comment(self, comment: str, item: calmpy.Item) -> bool:
        """
        Checks if the provided comment is already a comment of given item

        :param comment: comment to check
        :type comment: str
        :param item: item to check comment for
        :type item: calmpy.Item
        :return: True if provided comment is already comment of item, else False
        :type bool
        """
        calmpy_comments = item.get_comments()
        comments = [calmpy_comment['comment'] for calmpy_comment in calmpy_comments]

        return comment in comments

    def __save_df_as_xlsx(self, df: pd.DataFrame, data_file_path: Path):
        """
        Saves Dataframe in given path

        :param df: Dataframe to save
        :type df: pd.DataFrame
        :param data_file_path: Path where Dataframe should be saved
        :type data_file_path: Path
        """
        writer = pd.ExcelWriter(data_file_path, engine='xlsxwriter')
        df.to_excel(writer, sheet_name='Updates', index=False)

        for column in df:
            column_length = max(df[column].astype(
                str).map(len).max(), len(column)) + 5
            col_idx = df.columns.get_loc(column)
            writer.sheets['Updates'].set_column(
                col_idx, col_idx, column_length)

        writer.close()

    def __load_json(self, config_file_path: Path) -> Dict:
        """
        Loads JSON file.

        :param config_file_path: path to .json file
        :type config_file_path: Path
        :return: Json data
        :type Dict
        """
        with open(config_file_path, 'r', encoding='utf-8') as file:
            return json.load(file)


def add_arguments(parser: ArgumentParser):
    '''
    This functions handles the arguments for this script

    :param parser: argument parser including arguments to parse
    :type parser: ArgumentParser
    '''
    parser.add_argument('--cb_instance',
                        help='specifies on which instance the updates are made ("Prod", "QS", ...)',
                        type=str)
    parser.add_argument('--update_template',
                        help='the filled template with desired updates to codebeamer',
                        type=str)
    parser.add_argument('--copy_field_value_mapping',
                        help='the .json file including the field value mappings from template items field to other ch63 item fields',
                        type=str)
    parser.add_argument('--output_dir',
                        help='path where the outputs of the script will be saved to',
                        type=str)


def main() -> int:
    '''
    This functions handles the update of an item on given server with prodivded field data
    '''

    # argument parsing
    parser = ArgumentParser(
        prog='update_fields',
        description='Updates items on given server')
    add_arguments(parser=parser)
    args = parser.parse_args()

    codebeamer_updater = CodebeamerUpdater(cb_instance=args.cb_instance,
                                           update_template=args.update_template,
                                           copy_field_value_mapping=args.copy_field_value_mapping,
                                           output_dir_base=args.output_dir)
    codebeamer_updater.execute_template_copies()
    codebeamer_updater.execute_adds()
    codebeamer_updater.execute_updates()

if __name__ == '__main__':
    main()
