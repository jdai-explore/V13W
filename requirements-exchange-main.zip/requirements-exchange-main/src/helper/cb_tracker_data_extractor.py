"""
Script Name: cb_tracker_data_extractor.py
Description: This Script checks quality for SDV0.1 requirements for all BT-LAHs
Version: 1.0
"""
from argparse import ArgumentParser
from pathlib import Path
import calmpy
import calmpy.exceptions
from tqdm import tqdm
import os
from collections import defaultdict
import json


def add_arguments(parser: ArgumentParser):
    """
    This functions handles the arguments for this script
    :param parser: argument parser including arguments to parse
    :type parser: ArgumentParser
    """
    parser.add_argument('--cb_instance',
                        help='specifies on which instance the updates are made ("Prod", "QS", ...)',
                        type=str,
                        required=True)
    parser.add_argument('--tracker_ids_json',
                        help='json including tracker ids to update',
                        type=str)


def overall_statistics(bt_lahs_json_files):
    """
        This functions creates an overall statistics for all the json files in a given folder.
        :param bt_lahs_json_files: the path of a json files for all trackers
        :type bt_lahs_json_files: pathlib.Path
    """
    # Initialize dictionaries to store aggregated statistics
    print(type(bt_lahs_json_files))
    total_module_variants = defaultdict(int)
    total_status_counts = defaultdict(int)
    total_description_counts = defaultdict(int)
    total_tracker_items = 0

    # Loop through all JSON files in the directory
    for filename in os.listdir(bt_lahs_json_files.parent):
        if filename.endswith(".json"):
            file_path = os.path.join(bt_lahs_json_files.parent, filename)

            with open(file_path, encoding='utf-8') as file:
                data = json.load(file)

                # Aggregate tracker item count
                total_tracker_items += data.get("tracker_item_cnt", 0)

                # Aggregate "ModuleVariants_pe" counts
                if "ModuleVariants_pe" in data and isinstance(data["ModuleVariants_pe"], list):
                    for variant in data["ModuleVariants_pe"]:
                        for key, value in variant.items():
                            total_module_variants[key] += value

                # Aggregate "Status" counts
                if "Status" in data and isinstance(data["Status"], list):
                    for status in data["Status"]:
                        for key, value in status.items():
                            total_status_counts[key] += value

                # Aggregate "Description" counts
                if "Description" in data and isinstance(data["Description"], list):
                    for desc in data["Description"]:
                        for key, value in desc.items():
                            total_description_counts[key] += value

    # Create the final aggregated JSON
    aggregated_data = {
        "total_tracker_items": total_tracker_items,
        "ModuleVariants_pe": total_module_variants,
        "Status": total_status_counts,
        "Description": total_description_counts
    }

    # Save overall aggregated data to a JSON file
    overall_statistics_path = bt_lahs_json_files.parent / "Overall_BT-LAH_statistics.json"
    with open(overall_statistics_path, "w", encoding='utf-8') as output:
        json.dump(aggregated_data, output, indent=4)


def main() -> int:
    """
    This function parses JSON file to extract tracker IDs, retrieve items and count
    occurrences of ModuleVariants_pe, Status and Description field values.
    """

    # argument parsing
    parser = ArgumentParser(
        prog='update_fields',
        description='Updates items on given server')
    add_arguments(parser=parser)
    args = parser.parse_args()

    #   load tracker ids from JSON file
    file = open(args.tracker_ids_json, encoding='utf-8')
    data = json.load(file)

    statistics_path = ''
    tracker_ids = data['tracker_ids']

    cb_server_name = args.cb_instance
    cb_server = calmpy.Server(url=cb_server_name)

    print(f'Getting Info from CB instance: {cb_server_name}')

    for tracker_id in tracker_ids:
        tracker = cb_server.get_tracker(tracker_id=tracker_id)
        tracker_items = tracker.get_items()

        print(f'Quality Checks for tracker {tracker.name} ({tracker_id})')

        # Initialize module_variant_pe lists to count field values
        module_variant_pe = []
        tbd = []
        unset = []
        other = []

        # Initialize status lists to count field values
        status = []
        status_unset = []
        status_in_progress = []
        status_in_review = []
        status_released = []
        status_rejected = []
        status_new = []
        status_obsolete = []

        # Description which are Empty or Non-Empty
        description = []
        empty = []
        non_empty = []

        for item in tqdm(tracker_items):
            # Check 'Module Variant_pe' field values and append their IDs
            if item['Module Variant_pe'] is None:
                unset.append(item.id)

            elif 'TBD' in item['Module Variant_pe']:
                tbd.append(item.id)
            else:
                other.append(item.id)

            # categorize items based on their 'status' field and append their IDs to the respective status lists
            if item['status'] is None:
                status_unset.append(item.id)

            elif item['status'] == 'in Progress':
                status_in_progress.append(item.id)

            elif item['status'] == 'Obsolete':
                status_obsolete.append(item.id)

            elif item['status'] == 'In Review':
                status_in_review.append(item.id)

            elif item['status'] == 'Released':
                status_released.append(item.id)

            elif item['status'] == 'New':
                status_new.append(item.id)

            elif item['status'] == 'Rejected':
                status_rejected.append(item.id)

            # check if the 'Description' field is empty or Non-empty
            if item['Description'] == "":
                empty.append(item.id)
            else:
                non_empty.append(item.id)

        # Append moduleVariant_pe
        module_variant_pe.append({
                    'TBD': len(tbd),
                    'Unset': len(unset),
                    'Other': len(other)
                })

        # Append description
        description.append({
            'Empty': len(empty),
            'Non-Empty': len(non_empty)
           })

        # Append status
        status.append({
                    'Unset': len(status_unset),
                    'in Progress': len(status_in_progress),
                    'In Review': len(status_in_review),
                    'Released': len(status_released),
                    'New': len(status_new),
                    'Rejected': len(status_rejected),
                    'Obsolete': len(status_obsolete)
          })

        # prepare report
        statistics = {
            'cb_instance': cb_server_name,
            'tracker_id': tracker_id,
            'tracker_name': tracker.name,
            'tracker_item_cnt': len(tracker_items),
            'ModuleVariants_pe': module_variant_pe,
            'Status': status,
            'Description': description
        }
        # save statistics for moduleVariant_pe, status and description fields
        statistics_path = Path(
            '.') / 'BT_LAH_Statistics' / f'{tracker.name}.json'

        if not statistics_path.parent.exists():
            statistics_path.parent.mkdir(parents=True, exist_ok=True)

        with open(statistics_path, "w", encoding='utf8') as file:
            json.dump(statistics, file, indent=4,
                      sort_keys=False, ensure_ascii=False)

    overall_statistics(statistics_path)

if __name__== "__main__":
    main()
