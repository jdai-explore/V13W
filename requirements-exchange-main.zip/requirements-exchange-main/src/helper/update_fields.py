from argparse import ArgumentParser
from pathlib import Path
import calmpy.exceptions
from tqdm import tqdm
import pandas as pd
import json
import calmpy


def add_arguments(parser: ArgumentParser):
    '''
    This functions handles the arguments for this script

    :param parser: argument parser including arguments to parse
    :type parser: ArgumentParser
    '''
    parser.add_argument('--cb_instance',
                        help='specifies on which instance the updates are made ("Prod", "QS", ...)',
                        type=str)
    parser.add_argument('--tracker_ids_json',
                        help='json including tracker ids to update',
                        type=str)
    parser.add_argument('--field_name',
                        help='name of field to update for all requirements',
                        type=str)
    parser.add_argument('--field_value',
                        help='value to update the field to',
                        type=str)


def update_item(server: calmpy.Server, item: calmpy.Item,
                field_name: str, field_value: str) -> bool:
    '''
    This functions handles the update of an item on given server with prodivded field data

    :param server: server of item to change
    :type server: calmpy.Server
    :param item: item to update
    :type item: calmpy.Item
    :param field_name: field name to update
    :type field_name: str
    :param field_value: value to update item field to
    :type field_value: str
    :return: bool (True if success, else False)
    '''
    try:
        # update item in codebeamer
        item[field_name] = field_value
        item.update_fields()

        # check if update was successfull
        item_ref = server.get_item(item_id=item.id)

        return item_ref[field_name] == field_value
    except calmpy.exceptions.ServerError:
        return False


def main() -> int:
    '''
    This functions handles the update of an item on given server with prodivded field data
    '''

    # argument parsing
    parser = ArgumentParser(
        prog='update_fields',
        description='Updates items on given server')
    add_arguments(parser=parser)
    args = parser.parse_args()

    # prepare inputs
    file = open(args.tracker_ids_json, encoding='utf-8')
    data = json.load(file)

    tracker_ids = data['tracker_ids']

    field_name = args.field_name
    field_value = args.field_value

    # prepare cb server
    cb_server_name = args.cb_instance
    cb_server = calmpy.Server(url=cb_server_name, readonly=False)

    # prepare types to update
    update_types = ['Functional',
                    'Non-functional',
                    'Process-Requirement',
                    'Server-Requirement',
                    'Client-Requirement',
                    'Backend-Requirement',
                    ]

    # prepare module variants to update
    update_module_variants_only = 'CH63'

    print(f'Updating CB instance: {cb_server_name}')

    for tracker_id in tracker_ids:
        tracker = cb_server.get_tracker(tracker_id=tracker_id)
        tracker_items = tracker.get_items()

        print(f'Updating tracker {tracker.name} ({tracker_id})')

        updated_ids_success = []
        updated_ids_failed = []
        for item in tqdm(tracker_items):
            # check if modul variant is valid
            if not isinstance(item['Module Variant_pe'], list):
                continue

            # check if item is requirement and if module variant needs to be updated
            if (item['Type'] in update_types and
                    all(update_module_variants_only in module_variant
                        for module_variant in item['Module Variant_pe'])):
                if field_name in item:
                    if pd.isna(item[field_name]):
                        # update field
                        status = update_item(server=cb_server,
                                             item=item,
                                             field_name=field_name,
                                             field_value=field_value)

                        if status:
                            updated_ids_success.append(item.id)
                        else:
                            updated_ids_failed.append(item.id)

        # prepare report
        statistics = {
            'cb_instance': cb_server_name,
            'tracker_id': tracker_id,
            'tracker_name': tracker.name,
            'tracker_item_cnt': len(tracker_items),
            'update_types': update_types,
            'update_module_variants_only': update_module_variants_only,
            'field_name': field_name,
            'field_value': field_value,
            'updated_item_ids_succes': updated_ids_success,
            'updated_item_ids_succes_cnt': len(updated_ids_success),
            'updated_item_ids_failed': updated_ids_failed,
            'updated_item_ids_failed_cnt': len(updated_ids_failed)
        }
        # save statistics
        if updated_ids_success or updated_ids_failed:
            statistics_path = Path(
                '.') / 'updated_fields' / f'{tracker.name}.json'

            if not statistics_path.parent.exists():
                statistics_path.parent.mkdir(parents=True, exist_ok=True)

            with open(statistics_path, "w", encoding='utf8') as file:
                json.dump(statistics, file, indent=4,
                          sort_keys=False, ensure_ascii=False)


if __name__ == '__main__':
    main()
