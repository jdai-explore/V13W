import calmpy
import pandas as pd
import json
from pathlib import Path
import openpyxl
from datetime import date
from typing import Dict, List
import argparse

def load_configurations(config_file_path: str) -> Dict:
    """Loads configurations from a JSON file."""
    with open(config_file_path, 'r') as file:
        return json.load(file)

def get_tracker_items(tracker_id: str, cb_server: calmpy.Server) -> List:
    """Gets the items of the tracker."""
    tracker = cb_server.get_tracker(tracker_id=tracker_id)
    return tracker.get_items()

def get_latest_item_modified_date(items: List) -> str:
    """Gets the latest modified date of items."""
    latest_modified_date = None
    for item in items:
        modified_date = item.modifiedAt
        if latest_modified_date is None or modified_date > latest_modified_date:
            latest_modified_date = modified_date
    return latest_modified_date

def get_tracker_info(tracker_ids: List[str], cb_server: calmpy.Server) -> pd.DataFrame:
    """Gets the tracker information from the server."""
    columns = ['Tracker Id', 'Tracker Name', 'DateOfModification', 'Baseline', 'Server Address', 'SyncStatus']
    final_df = pd.DataFrame(columns=columns)

    for tracker_id in tracker_ids:
        tracker = cb_server.get_tracker(tracker_id=tracker_id)
        tracker_name = tracker.name
        items = get_tracker_items(tracker_id, cb_server)
        latest_modified_date = get_latest_item_modified_date(items)
        baseline = getattr(tracker, 'baseline', None)
        server_address = "https://cb.vwgroup.com/cb"
        sync_status = getattr(tracker, 'syncStatus', None)

        new_row = pd.DataFrame({
            'Tracker Id': [tracker_id],
            'Tracker Name': [tracker_name],
            'DateOfModification': [latest_modified_date],
            'Baseline': [baseline],
            'Server Address': [server_address],
            'SyncStatus': [sync_status],
        })

        if not new_row.isna().all().all(): 
            if final_df.empty:
                final_df = new_row
            else:
                final_df = pd.concat([final_df, new_row], ignore_index=True)

    return final_df

def save_to_excel(df: pd.DataFrame, file_path: str) -> None:
    """Saves the DataFrame to an Excel file."""
    df.to_excel(file_path, index=False)

    # Load the workbook
    wb = openpyxl.load_workbook(file_path)
    sheet = wb['Sheet1']

    # Increase the column width
    for i in range(1, sheet.max_column + 1):
        max_length = 0
        column_name = openpyxl.utils.get_column_letter(i)
        for cell in sheet[column_name]:
            if cell.value:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
        if column_name == 'A':  # Tracker ID
            sheet.column_dimensions[column_name].width = 15
        elif column_name == 'B':  # Tracker Name
            sheet.column_dimensions[column_name].width = 70
        elif column_name == 'C':  # DateOfModification
            sheet.column_dimensions[column_name].width = 25
        elif column_name == 'D':  # Baseline
            sheet.column_dimensions[column_name].width = 10
        elif column_name == 'E':  # Server Address
            sheet.column_dimensions[column_name].width = 40
        elif column_name == 'F':  # SyncStatus
            sheet.column_dimensions[column_name].width = 15
        else:
            sheet.column_dimensions[column_name].width = max_length + 5

    # Save the workbook
    wb.save(file_path)

def main() -> int:
    parser = argparse.ArgumentParser(description='Sync Tracker Info')
    parser.add_argument('--tracker_ids_file', type=str, help='Path to tracker IDs JSON file')
    parser.add_argument('--output_dir', type=str, help='Path to output directory')
    args = parser.parse_args()

    # Load configurations
    tracker_ids_dict = load_configurations(args.tracker_ids_file)

    # Create a CalmPy server instance
    cb_server = calmpy.Server(url="Prod", verify=False)

    all_tracker_info_df = pd.DataFrame()

    # Get tracker information for all track IDs
    for tracker_id_set in tracker_ids_dict.values():
        tracker_info_df = get_tracker_info(tracker_id_set, cb_server)
        all_tracker_info_df = pd.concat([all_tracker_info_df, tracker_info_df])

    if not all_tracker_info_df.empty:
        # Save to Excel
        result_path = Path(args.output_dir)
        if not result_path.exists():
            result_path.mkdir(parents=True)
        file_path = result_path / f'{date.today()}_change_history.xlsx'
        save_to_excel(all_tracker_info_df, file_path)
    else:
        print("\033[93mNo trackers found.\033[0m")

    return 0

if __name__ == '__main__':
    main()
