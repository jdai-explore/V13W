import calmpy
import json
import os
import sys
from argparse import ArgumentParser

class CodebeamerBaseline:
    """
    CodebeamerBaseline - A class that will create baseline on given project
    """

    def __init__(self, cb_instance: str, project_id: int, tracker_id: int, baseline_data: dict) -> None:
        """
        Constructs an object of CodebeamerBaseline that will handle the creation of baseline
        :param cb_instance: The url or short name for Codebeamer instance to work with
        :param project_id: The ID of the project
        :param tracker_id: The ID of the tracker
        :param baseline_data: The data for creating a baseline
        :type cb_instance: str
        :type project_id: int
        :type tracker_id: int
        :type baseline_data: dict
        :return: None
        """
        
        # save parameters 
        self._cb_instance = cb_instance
        self._project_id = project_id
        self._tracker_id = tracker_id
        self._baseline_data = baseline_data
        # Initialize the Codebeamer server connection
        self._server = calmpy.Server(url=cb_instance, readonly=False, verify=False)

    def create_baseline(self) -> calmpy.Baseline:
        """
        Creates a baseline using the provided baseline data.
        :return: A dictionary containing the result of the create baseline operation.
        :rtype: dict
        """
        try:
            print("Creating baseline....")

            # Get the project object from the Codebeamer server
            project = self._server.get_project(self._project_id)

            # Create a baseline
            baseline = project.create_baseline(name=self._baseline_data["name"], description=self._baseline_data["description"])

            if baseline is not None:
                print("Baseline created successfully.")
                return baseline
            else:
                print("Failed to create baseline.")
                sys.exit(1)
        except Exception as e:
            print(f"Error creating baseline: {e}")
            sys.exit(1)
    
    def create_tracker_baseline(self) -> calmpy.Baseline:
        """
        Creates a baseline on a tracker using the provided baseline data.
        :param tracker_id: The ID of the tracker
        :type tracker_id: int
        :return: A dictionary containing the result of the create baseline operation.
        :rtype: dict
        """
        try:
            print("Creating baseline on tracker....")

            # Get the tracker object from the Codebeamer server
            tracker = self._server.get_tracker(self._tracker_id)

            # Create a baseline
            tracker_baseline = tracker.create_baseline(name=self._baseline_data["name"], description=self._baseline_data["description"])

            if tracker_baseline is not None:
                print("Tracker baseline created successfully.")
                return tracker_baseline
            else:
                print("Failed to create tracker baseline.")
                sys.exit(1)
        except calmpy.exceptions.CalmpyException as e:
            print(f"Error creating baseline: {e}")
            sys.exit(1)
        except Exception as e:
            print(f"An unexpected error occurred: {e}")
            sys.exit(1)
        
def add_arguments(parser: ArgumentParser) -> None:
    '''
    This function handles the arguments for this script
    :param parser: argument parser including arguments to parse
    :type parser: ArgumentParser
    '''
    parser.add_argument('--cb_instance',
                        help='specifies on which instance the updates are made ("Prod", "QS", ...)',
                        type=str)
    parser.add_argument('--project_id',
                        help='the id of the project',
                        type=int)
    parser.add_argument('--tracker_id',
                        help='the id of the tracker',
                        type=int)
    parser.add_argument('--name',
                        help='name of the baseline',
                        type=str)
    parser.add_argument('--description',
                        help='description of the baseline',
                        type=str)

def parse_baseline_data(name: str, description: str, project_id: int, tracker_id: int) -> dict:
    try:
        return {
            "name": name,
            "description": description,
            "tracker": {"id": tracker_id},
            "project": {"id": project_id},
        }
    except Exception as e:
        print(f"Invalid data: {e}")
        return {}

def main() -> int:
    '''
    This function handles the baseline
    '''

    # argument parsing
    parser = ArgumentParser(prog='codebeamer_baseline',
                            description='creation of baseline')
    add_arguments(parser=parser)
    args = parser.parse_args()

    # Parse the baseline data
    baseline_data = parse_baseline_data(args.name, args.description, args.project_id, args.tracker_id)

    # Create a CodebeamerBaseline object
    codebeamer_baseline = CodebeamerBaseline(cb_instance=args.cb_instance,
                                         project_id=args.project_id,
                                         tracker_id=args.tracker_id,
                                         baseline_data=baseline_data)

    # Create a baseline on project or tracker based on tracker_id
    if args.tracker_id is not None:
        result = codebeamer_baseline.create_tracker_baseline()
    else:
        result = codebeamer_baseline.create_baseline()

    if result is not None:
        print("Baseline creation result:")
        print(result)
        sys.exit(0)
    else:
        sys.exit(1)

if __name__ == '__main__':
    main()
