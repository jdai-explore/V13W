import argparse
import json
import os
import shutil
from datetime import datetime

import calmpy
import openpyxl
from openpyxl import Workbook

# Define a lambda function to filter module variants
module_variant_filter = lambda item: getattr(item, 'Module Variant_pe', None) is not None and not any(variant in ['TBD', 'SV62-1Box', 'SV62-2Box', 'HCP2.low', 'HCP2.TV', 'HCP2.M_ACA', 'HCP2.F',' HCP2.M', 'HCP2.M_red', 'AID']  for variant in getattr(item, 'Module Variant_pe', []))

def main():
    parser = argparse.ArgumentParser(description='Process Codebeamer Statistics')
    parser.add_argument('--input_directory', type=str, required=True, help='Path to the input directory containing Excel files')
    parser.add_argument('--tracker_ids_path', type=str, required=True, help='Path to the tracker_ids.json file')
    parser.add_argument('--output_directory', type=str, required=True, help='Path to the output directory where processed files will be saved')
    parser.add_argument('--calmpy_url', type=str, required=True, help='The CalmPy server URL')
    
    args = parser.parse_args()

    # Load the tracker values from the JSON file
    with open(args.tracker_ids_path, 'r') as f:
        tracker_ids = json.load(f)

    # Create output directory with timestamp if it doesn't exist
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir_path = os.path.join(args.output_directory, f"Report_{timestamp}")
    if not os.path.exists(output_dir_path):
        os.makedirs(output_dir_path)

    # Create a CalmPy server instance
    cb_server = calmpy.Server(url=args.calmpy_url, verify=False)

    # Process CH63 trackers
    for tracker in tracker_ids['trackers']['CH63']:
        ch63_tracker_id = tracker
        # Retrieve CH63 tracker values
        ch63_tracker = cb_server.get_tracker(ch63_tracker_id)
        ch63_items = ch63_tracker.get_items()

        # Iterate over all files in the directory
        for filename in os.listdir(args.input_directory):
            if filename.endswith('.xlsx'):
                file_path = os.path.join(args.input_directory, filename)

                # Load the file
                wb = openpyxl.load_workbook(file_path)
                ws = wb.active
                print(f"Processing file: {filename}")            
                print("get Server")

                # Document
                print("serialize")

                ws['D4'] = f"{ch63_tracker.deep_serialize().get('name')}"
                print(f"Tracker Names: {ws['D4'].value}")
                currentCell = ws.cell(row=5, column=4)
                currentCell.value = f"{ch63_tracker.deep_serialize().get('keyName')}"
                print(f"Current Cell Value: {currentCell.value}")
                ws['D8'] = len(ch63_items)
                print(f"Total Items: {ws['D8'].value}")

                print("*****************************************")                
                attribute = ws['D10'].value
                total_sum_row12= 0
                total_sum_row14= 0
                for col in range(4,13):
                    field_value = ws.cell(row=11, column=col).value
                    if field_value == '[Empty]':
                        field_value = None
                    print(11, col, attribute, field_value, sum(module_variant_filter(item) and item[attribute] == field_value for item in ch63_items))
                    ws.cell(row=12, column=col).value = sum(item[attribute] == field_value for item in ch63_items)
                    total_sum_row12 += ws.cell(row=12, column=col).value
                    # Calculate the sum of values in columns 6 and 7
                    if col == 6:
                        value_6_ch63 = sum(item[attribute] == field_value for item in ch63_items)
                    elif col == 7:
                        value_7_ch63 = sum(item[attribute] == field_value for item in ch63_items)
                        # Calculate the final value for the merged row
                        final_value = value_6_ch63 + value_7_ch63
                        ws.cell(row=13, column=6).value = final_value
                    ws.cell(row=13, column=13).value = total_sum_row12
                        
                    ws.cell(row=14, column=col).value = sum(module_variant_filter(item) and item[attribute] == field_value for item in ch63_items)
                    total_sum_row14 += ws.cell(row=14, column=col).value
                    # Calculate the sum of values in columns 6 and 7
                    if col == 6:
                        value_6 = sum(module_variant_filter(item) and item[attribute] == field_value for item in ch63_items)
                    elif col == 7:
                        value_7 = sum(module_variant_filter(item) and item[attribute] == field_value for item in ch63_items)
                        # Update the value in the merged rows
                        total_value = value_6 + value_7
                        ws.cell(row=15, column=6).value = total_value
                    ws.cell(row=15, column=13).value = total_sum_row14

                print("*****************************************")
                attribute = ws['D17'].value
                for col in range(4,13):
                    field_value = ws.cell(row=18, column=col).value
                    if field_value == '[Empty]':
                        field_value = None
                    print(18, col, attribute, field_value, sum(module_variant_filter(item) and item[attribute] == field_value for item in ch63_items))
                    ws.cell(row=19, column=col).value = sum(item[attribute] == field_value for item in ch63_items)
                    ws.cell(row=20, column=col).value = sum(module_variant_filter(item) and item[attribute] == field_value for item in ch63_items)

                print("*****************************************")
                attribute = ws['D22'].value
                for col in range(4,11):
                    field_value = ws.cell(row=23, column=col).value
                    if field_value == '[Empty]':
                        field_value = None
                    print(23, col, attribute, field_value, sum(item[attribute] == field_value for item in ch63_items))
                    print(23, col, attribute, field_value, sum(module_variant_filter(item) and item[attribute] == field_value for item in ch63_items))
                    ws.cell(row=24, column=col).value = sum(item[attribute] == field_value for item in ch63_items)
                    ws.cell(row=25, column=col).value = sum(module_variant_filter(item) and item[attribute] == field_value for item in ch63_items)
              
                print("*****************************************")
                attribute = ws['D27'].value
                for col in range(4,8):
                    field_value = ws.cell(row=28, column=col).value
                    if field_value == '[Empty]':
                        field_value = None

                    if field_value == 'Discarded Requirements*' and col == 6:
                        discarded_requirements_filter = lambda item: ( 
                            (getattr(item, 'categories', '') in ['Functional','Non-functional']) 
                            and getattr(item, 'Status Requester_ct', None) in ['Discarded', 'Proposed to Discard']
                        )
                        filtered_items = list(filter(discarded_requirements_filter, ch63_items))
                        print(29, col, "Discarded Requirements*", len(filtered_items))
                        ws.cell(row=29, column=6).value = len(filtered_items)
                        
                        filtered_items_module_variant = list(filter(lambda item: discarded_requirements_filter(item) and module_variant_filter(item), ch63_items))
                        print(30, col, "Discarded Requirements*", len(filtered_items_module_variant))
                        ws.cell(row=30, column=6).value = len(filtered_items_module_variant)

                    if field_value == 'Valid Requirements*' and col == 7:
                        discarded_valid_filter = lambda item: ( 
                            (getattr(item, 'categories', '') in ['Functional','Non-functional']) 
                            and getattr(item, 'Status Requester_ct', None) not in ['Discarded', 'Proposed to Discard']
                        )
                        filtered_items = list(filter(discarded_valid_filter, ch63_items))
                        print(29, col, "Valid Requirements*", len(filtered_items))
                        ws.cell(row=29, column=7).value = len(filtered_items)
                        
                        filtered_items_module_variant = list(filter(lambda item: discarded_valid_filter(item) and module_variant_filter(item), ch63_items))
                        print(30, col, "Valid Requirements*", len(filtered_items_module_variant))
                        ws.cell(row=30, column=7).value = len(filtered_items_module_variant)
                    else:
                        print(29, col, attribute, field_value, sum(item[attribute] == field_value for item in ch63_items))
                        ws.cell(row=29, column=col).value = sum(item[attribute] == field_value for item in ch63_items)
                        ws.cell(row=30, column=col).value = sum(module_variant_filter(item) and item[attribute] == field_value for item in ch63_items)
                
                print("*****************************************")
                field_row = ws['C37'].value
                field_col = ws['E35'].value
                for row in range(37,44):
                    field_row_value = ws.cell(row=row, column=4).value
                    for col in range(5,13):
                        field_col_value = ws.cell(row=36, column=col).value
                        if field_row_value == '[Empty]':
                            field_row_value = None
                        if field_col_value == '[Empty]':
                            field_col_value = None
                        print(field_row, field_row_value, field_col, field_col_value,
                              sum(item[field_row] == field_row_value and item[field_col] == field_col_value for item in ch63_items))
                        ws.cell(row=row, column=col).value = sum(item[field_row] == field_row_value and item[field_col]
                                                                == field_col_value for item in ch63_items)
                
                print("*****************************************")
                field_row = ws['C53'].value
                field_col = ws['E51'].value
                for row in range(53,60):
                    field_row_value = ws.cell(row=row, column=4).value
                    for col in range(5,13):
                        field_col_value = ws.cell(row=52, column=col).value
                        if field_row_value == '[Empty]':
                            field_row_value = None
                        if field_col_value == '[Empty]':
                            field_col_value = None
                        print(field_row, field_row_value, field_col, field_col_value,
                              sum(module_variant_filter(item) and item[field_row] == field_row_value and item[field_col] == field_col_value for item in ch63_items))
                        ws.cell(row=row, column=col).value = sum(module_variant_filter(item) and item[field_row] == field_row_value and item[field_col] == field_col_value for item in ch63_items)

                # Save the worksheet as a (*.xlsx) file
                wb.template = False
                ch63_tracker_name = ch63_tracker.deep_serialize().get('name')
                save_path = os.path.join(output_dir_path, f"{ch63_tracker_name}.xlsx")
                wb.save(save_path)
                print(f"File saved at: {save_path}")
    
if __name__ == "__main__":
    main()
