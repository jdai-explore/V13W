import argparse
import calmpy
import json
import os
import pandas as pd
from pathlib import Path
from typing import Dict
import time
from difflib import SequenceMatcher
import re

# Fields to ignore
fields_to_ignore_audi = [
    "Comments/Attachments", "Attachments", "Assigned at", "assigned to", "Release", "description", "Subject",
    "BsM-O comment_ct", "Submitted by", "BsM-Sa.FuSi comment_ct", "BsM-E.L_ct", "Tracker", "BsM-E.D comment_ct",
    "Comment PAG to Mobileye_pe", "Submitted at", "Update Status_pe", "Description Format",
    "Comment Requester_ct", "Comment Internal_ct", "Comment Mobileye to PAG_pe", "Subject", "BsM-E.T_ct",
    "Verification Method_ct", "BsM-E.T comment_ct", "Import Status_ct", "BsM-E.D_ct",
    "Status Mobileye to PAG_pe", "BsM-E.L comment_ct", "ReqIF-Import Status_pe", "Status PAG to Mobileye_pe",
    "Status Audi to Mobileye_pe", "BsM-O_ct", "Comment Mobileye to Audi_pe"
    ]


def _remove_chars(value: str) -> str:
    unwanted_chars = [r"\\\\", r"__", r",,", r"~_", r"~", r"%!", r"%%\(.*\)", r"~#~#", r'[\r\n]+', r'##', r'\* ',
                      r'\*\*', r'\*\. ']

    for unwanted_char in unwanted_chars:
        value = re.sub(f'{unwanted_char}', '', value)

    return value.strip()


def _load_json(json_file_path: Path):
    with open(json_file_path, 'r', encoding='utf-8') as file:
        return json.load(file)


def _convert_to_excel():
    start_time = time.time()
    modified_items = []
    new_items = []
    deleted_items = []
    duplicate_items = []

    for file in os.listdir():
        if file.endswith(".csv"):
            if file.startswith("modified_items"):
                df = pd.read_csv(file, sep=";")
                modified_items.append(df)

            elif file.startswith("new_items"):
                df = pd.read_csv(file, sep=";")
                new_items.append(df)

            elif file.startswith("deleted_items"):
                df = pd.read_csv(file, sep=";")
                deleted_items.append(df)

            elif file.startswith("duplicate_items"):
                df = pd.read_csv(file, sep=";")
                duplicate_items.append(df)

    modified_items_df = pd.concat(modified_items)
    new_items_df = pd.concat(new_items)
    deleted_items_df = pd.concat(deleted_items)
    duplicate_items_df = pd.concat(duplicate_items)

    file_name = "change_log.xlsx"
    if os.path.isfile(file_name):
        os.remove(file_name)

    with pd.ExcelWriter("change_log.xlsx") as writer:
        modified_items_df.to_excel(writer, index=False, sheet_name="modified_items")
        new_items_df.to_excel(writer, index=False, sheet_name="new_items")
        deleted_items_df.to_excel(writer, index=False, sheet_name="deleted_items")
        duplicate_items_df.to_excel(writer, index=False, sheet_name="duplicate_items")

    print("Exporting to Excel took " + str(round(time.time() - start_time, 2)) + " seconds!")


class ChangeLog:
    def __init__(self, cb_server: str, trackers_json_path: Path, field_mapping_path: Path,
                 tracker_ids_to_filter: str, item_status: str):

        # The Codebeamer server instance
        self._cb_server = calmpy.Server(url=cb_server, readonly=True)

        # The trackers and fields to compare
        self._trackers_json = _load_json(trackers_json_path)
        self._field_mapping_sv62_ch_63 = _load_json(field_mapping_path)
        self._trackers_to_process = tracker_ids_to_filter

        # If the item does not match the status specified, skip it
        self._item_status = item_status

        # _matched_items is a dictionary to store the ID numbers of items that match
        # It has the following structure:
        # {
        #   "Audi":
        #       {
        #           "AudiTrackerID_1":{<AudiItemID_1>:<PorscheItemID_1>, <AudiItemID_2>:<PorscheItemID_2>},
        #           "AudiTrackerID_2":{<AudiItemID_1>:<PorscheItemID_1>, <AudiItemID_2>:<PorscheItemID_2>},
        #       },
        #
        #   "Porsche":
        #       {
        #           "PorscheTrackerID_1"{<PorscheItemID_1>:<AudiItemID_1>, <PorscheItemID_2>:<AudiItemID_2},
        #           "PorscheTrackerID_2":{<PorscheItemID_1>:<AudiItemID_1>, <PorscheItemID_2>:<AudiItemID_2},
        #        }
        # }
        self._matched_items = {"Audi": {}, "Porsche": {}}

        # _modified_items is a dictionary to store the ID numbers of items that match and have been modified
        # It has the following structure:
        # {
        #   "AudiTrackerID_1":
        #       {
        #           <AudiItemID_1>:
        #               {
        #                   "PorscheItemId": 56165161, "Fields":
        #                       {
        #                           "FieldName1":<SimilarityRatio>,
        #                           "FieldName2":<SimilarityRatio>,
        #                           "FieldName3":<SimilarityRatio>
        #                        }
        #               },
        #
        #           <AudiItemID_2>:
        #               {
        #                   "PorscheItemId":
        #                       {
        #                           "DifferingFields":
        #                               [
        #                                   {"FieldName1":<SimilarityRatio>},
        #                                   {"FieldName2":<SimilarityRatio>},
        #                                   {"FieldName3":<SimilarityRatio>}
        #                               ]
        #                        }
        #               },
        #
        # }
        self._modified_items = {}

        # _new_items is a dictionary to the ID numbers of items that don't have a foreign id doors, a.k.a. "new items"
        # It has the following structure:
        # {
        #   "Audi":
        #       {
        #           "AudiTrackerID_1":[<AudiItemID_1>, <AudiItemID_2>, ..., <AudiItemID_N>],
        #           "AudiTrackerID_2":[<AudiItemID_1>, <AudiItemID_2>, ..., <AudiItemID_N>],
        #       },
        #
        #    "Porsche":
        #        {
        #           "PorscheTrackerID_1":[<PorscheItemID_1>, <PorscheItemID_2>, ..., <PorscheItemID_N>],
        #           "PorscheTrackerID_2":[<PorscheItemID_1>, <PorscheItemID_2>, ..., <PorscheItemID_N>],
        #        }
        # }
        self._new_items = {"Audi": {}, "Porsche": {}}

        # Deleted items are items that have a foreign doors ID but do not have a match. The reasoning is that these
        # items were imported from an external database at some point in time, but either Audi or Porsche deleted them
        # in their database. It has the same structure as the _new_items dictionary
        self._deleted_items = {"Audi": {}, "Porsche": {}}

        # In the case that multiple items have the same foreign doors id, it is not possible to establish a match,
        # because their contents can vary wildly. These items need to be pulled aside for manual inspection. The
        # structure of the dictionary is the same as the _new_items dictionary
        self._duplicated_items = {"Audi": {}, "Porsche": {}}

    def run(self):
        # Parse the list of trackers to process from the args
        # If the list is empty, process all trackers
        trackers_to_process = []

        # Process all trackers
        if self._trackers_to_process == "":
            trackers_to_process = self._trackers_json

        # Only process trackers in the list
        else:
            # First we need to parse the string for trackers
            tracker_ids = re.split(r'[,\s]+', self._trackers_to_process)

            for tracker_id in tracker_ids:
                for tracker_pair in self._trackers_json:
                    if tracker_pair["TrackerID-DPE"] == tracker_id:
                        trackers_to_process.append(tracker_pair)

        for tracker_pair in trackers_to_process:
            tracker_id_audi = tracker_pair["TrackerID-DPE"]
            tracker_id_porsche = tracker_pair["TrackerID-DPAS"]

            tracker_name_audi = tracker_pair["TrackerName-DPE"]
            tracker_name_porsche = tracker_pair["TrackerName-DPAS"]

            tracker_audi = self._cb_server.get_tracker(tracker_id_audi)
            tracker_porsche = self._cb_server.get_tracker(tracker_id_porsche)

            items_audi = tracker_audi.get_items()
            items_porsche = tracker_porsche.get_items()

            bundle_audi = {"ID": tracker_id_audi, "Name": tracker_name_audi, "Tracker": tracker_audi,
                           "Items": items_audi}
            bundle_porsche = {"ID": tracker_id_porsche, "Name": tracker_name_porsche, "Tracker": tracker_porsche,
                              "Items": items_porsche}

            # First we need to preprocess the trackers and store them in dictionaries so that we can efficiently find
            # matching items and compare their fields. doors_audi and doors_porsche are dictionaries that contain item
            # pairs that have been matched using their foreign doors id. The key for each dictionary is the foreign
            # doors id and the value is the codebeamer item id. This is implemented to take advantage of the O(1)
            # operations required to find the matching item. During this conversion operation, items that do not have a
            # foreign doors id value are discovered and stored in the new_items dictionaries for later processing.
            # Additionally, if there are multiple items in the same tracker that share the same value for the Foreign
            # ID_DOORS_pe attribute, they are also discovered
            doors_audi, doors_porsche = self._preprocess_items(bundle_audi, bundle_porsche)

            # Now that we have our data in a format that we can easily work with, it's time to find matches for items
            # in both trackers that share the same value for the Foreign ID_DOORS_pe attribute
            self._match_items(bundle_audi, doors_audi, bundle_porsche, doors_porsche)

            print("---- Audi ----")
            deleted_items_count = len(self._deleted_items["Audi"][tracker_id_audi])
            print("Items with unique Foreign ID_DOORS_pe: " + str(len(doors_audi.keys())) + " items")
            print("of these without a match: " + str(deleted_items_count) + " (deleted) items")

            new_items_count = len(self._new_items["Audi"][tracker_id_audi])
            print("Items without a Foreign ID_DOORS_pe: " + str(new_items_count) + " (new) items")

            duplicate_items_count = len(self._duplicated_items["Audi"][tracker_id_audi])
            print(
                "Items with a duplicated Foreign ID_DOORS_pe: " + str(duplicate_items_count) + " (duplicate) items")

            print()

            print("---- Porsche ----")
            print("Items with unique Foreign ID_DOORS_pe: " + str(len(doors_porsche.keys())) + " items")

            deleted_items_count = len(self._deleted_items["Porsche"][tracker_id_porsche])
            print("of these without a match: " + str(deleted_items_count) + " (deleted) items")

            new_items_count = len(self._new_items["Porsche"][tracker_id_porsche])
            print("Items without a Foreign ID_DOORS_pe: " + str(new_items_count) + " (new) items")

            duplicate_items_count = len(self._duplicated_items["Porsche"][tracker_id_porsche])
            print(
                "Items with a duplicated Foreign ID_DOORS_pe: " + str(duplicate_items_count) + " (duplicate) items")

            print("----------------------------------------")

            # Now we need to compare matched items
            self._compare_items(bundle_audi, bundle_porsche)

            # And finally export the output to a file
            self._export_modified_items_to_csv(bundle_audi, bundle_porsche)
            self._export_new_items_to_csv(bundle_audi, bundle_porsche)
            self._export_deleted_items_to_csv(bundle_audi, bundle_porsche)
            self._export_duplicate_items_to_csv(bundle_audi, bundle_porsche)

        _convert_to_excel()

    def _preprocess_items(self, bundle_audi: Dict, bundle_porsche: Dict):
        print("----------------------------")
        print("Preprocessing trackers...")
        # First we need to get a list of item IDs from the Audi tracker from the server
        tracker_id_audi = bundle_audi["ID"]
        tracker_id_porsche = bundle_porsche["ID"]

        items_audi = bundle_audi["Items"]
        items_porsche = bundle_porsche["Items"]

        # These counters are to display the number of items found in each tracker that are not of type "Folder"
        # or "Information"
        req_items_audi_count = 0
        req_items_porsche_count = 0

        # Then let's convert the Item IDs and their Foreign Doors ID field to a dictionary so that we can
        # search them quickly using hash tables
        doors_id_item_id_audi = {}
        doors_id_item_id_porsche = {}

        new_items_buffer_audi = []
        new_items_buffer_porsche = []

        duplicated_items_buffer_audi = []
        duplicated_items_buffer_porsche = []

        duplicates_to_remove_audi = []
        duplicates_to_remove_porsche = []

        for item in items_audi:

            # Ignore folders and information items
            if item["Type"] != "Folder" and item["Type"] != "Information":

                item_id = item["ID"]
                foreign_doors_id = item["Foreign ID_DOORS_pe"]

                req_items_audi_count += 1

                # Check if the item has a value for the foreign id doors field
                if foreign_doors_id is not None:

                    # Ensure that the item does not share its foreign doors id with another item
                    if foreign_doors_id not in doors_id_item_id_audi.keys():
                        doors_id_item_id_audi[foreign_doors_id] = item_id

                    # otherwise remember this item id and mark it for removal from the dictionary
                    else:
                        # Special case to also add the existing item's id to the duplicate items id buffer
                        duplicate_item_id = doors_id_item_id_audi[foreign_doors_id]
                        if duplicate_item_id not in duplicated_items_buffer_audi:
                            duplicated_items_buffer_audi.append(duplicate_item_id)

                            if foreign_doors_id not in duplicates_to_remove_audi:
                                duplicates_to_remove_audi.append(foreign_doors_id)

                        # Add the current item to the duplicate items id buffer
                        duplicated_items_buffer_audi.append(item_id)

                # If there is no foreign id value, then the item is classified as a "new item"
                else:
                    new_items_buffer_audi.append(item["ID"])

        # Remove the duplicate foreign doors ids
        for duplicate in duplicates_to_remove_audi:
            del doors_id_item_id_audi[duplicate]

        for item in items_porsche:

            # Ignore folders and information items
            if item["Type"] != "Folder" and item["Type"] != "Information":

                item_id = item["ID"]
                foreign_doors_id = item["Foreign ID_DOORS_pe"]

                req_items_porsche_count += 1

                # Check if the item has a value for the foreign id doors field
                if foreign_doors_id is not None:

                    # Ensure that the item does not share its foreign doors id with another item
                    if foreign_doors_id not in doors_id_item_id_porsche.keys():
                        doors_id_item_id_porsche[foreign_doors_id] = item_id

                    # otherwise remember this item id and mark it for removal from the dictionary
                    else:
                        # Special case to also add the existing item's id to the duplicate items id buffer
                        duplicate_item_id = doors_id_item_id_porsche[foreign_doors_id]
                        if duplicate_item_id not in duplicated_items_buffer_porsche:
                            duplicated_items_buffer_porsche.append(duplicate_item_id)

                            if foreign_doors_id not in duplicates_to_remove_porsche:
                                duplicates_to_remove_porsche.append(foreign_doors_id)

                        # Add the current item to the duplicate items id buffer
                        duplicated_items_buffer_porsche.append(item_id)

                # If there is no foreign id value, then the item is classified as a "new item"
                else:
                    new_items_buffer_porsche.append(item["ID"])

        # Remove the duplicate foreign doors ids
        for duplicate in duplicates_to_remove_porsche:
            del doors_id_item_id_porsche[duplicate]

        print(str(req_items_audi_count) + " requirement items found in Audi tracker " + str(tracker_id_audi)
              + " | " + bundle_audi["Name"])
        print(str(req_items_porsche_count) + " requirement items found in Porsche tracker " + str(tracker_id_porsche)
              + " | " + bundle_porsche["Name"])
        print()

        self._new_items["Audi"][tracker_id_audi] = new_items_buffer_audi
        self._new_items["Porsche"][tracker_id_porsche] = new_items_buffer_porsche
        self._duplicated_items["Audi"][tracker_id_audi] = duplicated_items_buffer_audi
        self._duplicated_items["Porsche"][tracker_id_porsche] = duplicated_items_buffer_porsche

        return doors_id_item_id_audi, doors_id_item_id_porsche

    def _match_items(self, bundle_audi: Dict, doors_audi: Dict, bundle_porsche: Dict, doors_porsche: Dict):
        tracker_id_audi = bundle_audi["ID"]
        tracker_id_porsche = bundle_porsche["ID"]

        matched_items_audi = {}
        matched_items_porsche = {}

        deleted_items_audi = []
        deleted_items_porsche = []

        # Now try to find a match for each Audi Item
        for foreign_id in doors_audi:

            if foreign_id in doors_porsche:
                matched_items_audi[doors_audi[foreign_id]] = doors_porsche[foreign_id]

            # If the item has a foreign id doors, but no matching Porsche counterpart, it means the item
            # was imported to the Audi tracker and "removed/not imported" from the Porsche tracker
            else:
                deleted_items_audi.append(doors_audi[foreign_id])

        # And now try to find a match for each Porsche Item
        for foreign_id in doors_porsche.keys():
            if foreign_id in doors_audi:
                matched_items_porsche[doors_porsche[foreign_id]] = doors_audi[foreign_id]

            # If the item has a foreign id doors, but no matching Audi counterpart, it means the item
            # was imported to the Porsche tracker and "removed/not imported" from the Audi tracker
            else:
                deleted_items_porsche.append(doors_porsche[foreign_id])

        # Modified items
        self._matched_items["Audi"][tracker_id_audi] = matched_items_audi
        self._matched_items["Porsche"][tracker_id_porsche] = matched_items_porsche

        # Deleted items
        self._deleted_items["Audi"][tracker_id_audi] = deleted_items_audi
        self._deleted_items["Porsche"][tracker_id_porsche] = deleted_items_porsche

    def _compare_items(self, bundle_audi: Dict, bundle_porsche: Dict):
        # Now we need to loop through the matched items and compare their attributes. The items attributes are
        # mapped using the sv_63_to_ch63_field_mapping.json file. This will be the most computationally expensive
        # part of the code as it needs to perform a lot of comparisons for each item

        # First we need to read in the json file to have the mappings in memory
        json_mappings = self._field_mapping_sv62_ch_63

        # Then we can drop all keys that have the value null. This means there is no mapping for this attribute
        # therefore it doesn't need to be compared. Additionally, we can define a list of fields to ignore
        filtered_mappings = {}

        # Drop fields that are set to be ignored
        for mapping in json_mappings:
            if json_mappings[mapping] is not None:
                if mapping not in fields_to_ignore_audi:
                    filtered_mappings[mapping] = json_mappings[mapping]

        # Now we compare the attributes of each matched item pair. The repeated server request for the items is done to
        # minimise RAM consumption. If the performance suffers due to a slow internet connection, it could be considered
        # to declare the trackers as class variables.
        start_time = time.time()
        print("Comparison started ... Audi tracker: " + bundle_audi["Name"] + " | Porsche tracker: "
              + bundle_porsche["Name"])

        # Define the tracker IDs to compare
        tracker_id_audi = bundle_audi["ID"]

        # Define ItemLists to access all Audi and Porsche items
        items_audi = bundle_audi["Items"]
        items_porsche = bundle_porsche["Items"]

        # Let's get the matched items for this tracker
        matched_items = self._matched_items["Audi"][tracker_id_audi]

        # We will need a buffer before writing the data to the .csv file
        # Let's create a container to store the results of this comparison
        output_buffer = {}

        # And in this loop we compare the items
        for audi_item_id in matched_items:
            differing_fields_buffer = []
            item_id_porsche = matched_items[audi_item_id]
            item_porsche = items_porsche.get_by_id(item_id_porsche)
            item_audi = items_audi.get_by_id(audi_item_id)

            if self._item_status != "All":
                if item_audi["Status"] != self._item_status:
                    continue

            # Now we will compare the fields of each item
            for field_porsche_name in filtered_mappings.keys():
                field_porsche = item_porsche[field_porsche_name]
                field_audi_name = filtered_mappings[field_porsche_name]
                field_audi = item_audi[field_audi_name]

                # Required due to bug in Python. Search the internet for:
                # fix: Sequence Matcher error in Bank Reconciliation #23539
                if field_audi is None:
                    field_audi = ""

                if field_porsche is None:
                    field_porsche = ""

                # Pre-process the string to remove unwanted characters
                field_audi = str(field_audi).strip()
                field_porsche = str(field_porsche).strip()
                field_audi = _remove_chars(field_audi)
                field_porsche = _remove_chars(field_porsche)

                # field_audi = field_audi.replace("\\\\", "").replace(",,", "").replace("~", "").replace("__", "")
                # field_porsche = field_porsche.replace("\\\\", "").replace(",,", "").replace("~", "").replace("__", "")

                # Calculate the similarity ratio
                result = SequenceMatcher(None, field_audi, field_porsche).ratio()

                # If it's less than 95%, we will not add this item to the modified list
                if result < 0.95:
                    differing_fields_buffer.append({field_audi_name: round(result, 2)})

            output_buffer[audi_item_id] = {"PorscheItemId": item_id_porsche, "Fields": differing_fields_buffer}

        # Now that all the items have been added to the output buffer, we can write the results to the
        # "modified items" dictionary
        self._modified_items[tracker_id_audi] = output_buffer
        print("Number of modified items added: " + str(len(self._modified_items[tracker_id_audi].keys())))

        # print("Field: " + field_porsche_name + " | Porsche: " + str(field_porsche))
        # print("Similarity score: " + str(result*100) + " %")
        # print("-----")

        print("Comparison took " + str(round(time.time() - start_time, 2)) + " seconds!")

    def _export_modified_items_to_csv(self, bundle_audi: Dict, bundle_porsche: Dict):
        start_time = time.time()
        print("Exporting modified items to csv...")

        json_mappings = self._field_mapping_sv62_ch_63
        filtered_mappings = {}

        # Drop fields that are set to be ignored
        for mapping in json_mappings:
            if json_mappings[mapping] is not None:
                if mapping not in fields_to_ignore_audi:
                    filtered_mappings[json_mappings[mapping]] = mapping

        # Check if a file has generated for the tracker. If it already exists, delete it
        file_name = "modified_items_" + bundle_audi["ID"] + "__" + bundle_porsche["ID"] + ".csv"
        if os.path.isfile(file_name):
            os.remove(file_name)

        # Write output
        with open(file_name, "w", encoding="utf-8", buffering=1) as f:

            # Define the headers
            f.write(
                "Audi-TrackerID;"
                "Audi-TrackerName;"
                "Audi-ItemId;"
                "Audi-FieldName;"
                "Audi-FieldValue;"
                "Audi-Description;"
                "PAG-TrackerID;"
                "PAG-TrackerName;"
                "PAG-ItemId;"
                "PAG-FieldName;"
                "PAG-FieldValue;"
                "PAG-Description;"
                "Similarity\n"
            )

            modified_items = self._modified_items[bundle_audi["ID"]]

            for audi_item_id in modified_items:
                audi_items = bundle_audi["Items"]
                porsche_items = bundle_porsche["Items"]

                audi_item = audi_items.get_by_id(audi_item_id)

                porsche_item_id = modified_items[audi_item_id]["PorscheItemId"]
                porsche_item = porsche_items.get_by_id(porsche_item_id)

                fields = modified_items[audi_item_id]["Fields"]

                for field in fields:
                    field_name_audi = list(field)[0]
                    field_value_audi = str(audi_item[field_name_audi])
                    field_name_porsche = filtered_mappings[field_name_audi]
                    similarity = field[field_name_audi]

                    # CH63 - TrackerID
                    f.write(bundle_audi["ID"] + ";")

                    # CH63-TrackerName
                    f.write(bundle_audi["Name"] + ";")

                    # CH63-ItemId
                    f.write(str(audi_item_id) + ";")

                    # CH63 - FieldName
                    f.write(field_name_audi + ";")

                    # CH63 - FieldValue
                    if field_value_audi is not None:
                        # Pre-process the string to remove unwanted characters
                        field_value_audi = field_value_audi.strip()
                        field_value_audi = _remove_chars(field_value_audi)

                    f.write("\"" + field_value_audi.replace(";", ",").replace("\"", "") + "\"" + ";")

                    # CH63 - Description
                    f.write(str(audi_item.deep_serialize()).replace("\"", "").replace(";", "") + ";")

                    # SV62 - TrackerID
                    f.write(bundle_porsche["ID"] + ";")

                    # SV62 - TrackerName
                    f.write(str(bundle_porsche["Tracker"]["name"]) + ";")

                    # SV62 - ItemId
                    f.write(str(porsche_item_id) + ";")

                    # SV62 - FieldName
                    f.write(field_name_porsche + ";")

                    # SV62 - FieldValue
                    field_value_porsche = str(porsche_item[field_name_porsche])
                    if field_value_porsche is not None:
                        # Pre-process the string to remove unwanted characters
                        field_value_porsche = field_value_porsche.strip()
                        field_value_porsche = _remove_chars(field_value_porsche)

                    f.write("\"" + field_value_porsche.replace("\"", "").replace(";", "") + "\"" + ";")

                    # SV62 - Description
                    f.write(str(porsche_item.deep_serialize()).replace("\"", "").replace(";", "") + ";")

                    # Similarity
                    f.write(str(similarity) + "\n")

        print("Export modified items to csv took " + str(round(time.time() - start_time, 2)) + " seconds!")

    def _export_new_items_to_csv(self, bundle_audi, bundle_porsche):
        start_time = time.time()
        print("Exporting new items to csv...")

        # Check if files have been generated for the trackers. If they already exist, delete them
        file_name_audi = "new_items_" + bundle_audi["ID"] + ".csv"
        if os.path.isfile(file_name_audi):
            os.remove(file_name_audi)

        file_name_porsche = "new_items_" + bundle_porsche["ID"] + ".csv"
        if os.path.isfile(file_name_porsche):
            os.remove(file_name_porsche)

        # Get the list of new items in this Audi tracker
        new_items_audi = self._new_items["Audi"][bundle_audi["ID"]]

        # Get the list of new items in this Porsche tracker
        new_items_porsche = self._new_items["Porsche"][bundle_porsche["ID"]]

        # Write output for new items in Audi tracker
        with open(file_name_audi, "w", encoding="utf-8", buffering=1) as f:

            audi_items = bundle_audi["Items"]

            # First we need to prepare the headers
            f.write(
                "Tracker-Id;"
                "Tracker-Name;"
                "Item-Id;"
                "Item-Type;"
                "Summary;"
                "Description;"
                "Fields;"
                "URL\n"
            )

            # Write each item to the .csv file
            for new_item_id in new_items_audi:
                new_item = audi_items.get_by_id(new_item_id)

                f.write(str(new_item["Tracker"]) + ";")
                f.write(str(new_item["Tracker"]["name"]) + ";")
                f.write(str(new_item["ID"]) + ";")
                f.write(str(new_item["Type"]) + ";")
                f.write(str(new_item["Summary"]) + ";")

                description = _remove_chars(str(new_item["Description"]).replace("\"", "").replace(";", ""))
                f.write("\"" + description + "\";")

                fields = _remove_chars(str(new_item.deep_serialize()).replace("\"", "").replace(";", ""))
                f.write("\"" + fields + "\";")

                f.write("\"" + "https://cb.vwgroup.com/cb/issue/" + str(new_item["ID"]) + "\"\n")

        # Write output for new items in Porsche tracker
        with open(file_name_porsche, "w", encoding="utf-8", buffering=1) as f:
            porsche_items = bundle_porsche["Items"]

            # First we need to prepare the headers
            f.write(
                "Tracker-Id;"
                "Tracker-Name;"
                "Item-Id;"
                "Item-Type;"
                "Summary;"
                "Description;"
                "Fields;"
                "URL\n"
            )

            # Write each item to the .csv file
            for new_item_id in new_items_porsche:
                new_item = porsche_items.get_by_id(new_item_id)

                f.write(str(new_item["Tracker"]) + ";")
                f.write(str(new_item["Tracker"]["name"]) + ";")
                f.write(str(new_item["ID"]) + ";")
                f.write(str(new_item["Type"]) + ";")
                f.write(str(new_item["Summary"]) + ";")

                description = _remove_chars(str(new_item["Description"]).replace("\"", "").replace(";", ""))
                f.write("\"" + description + "\";")

                fields = _remove_chars(str(new_item.deep_serialize()).replace("\"", "").replace(";", ""))
                f.write("\"" + fields + "\";")

                f.write("\"" + "https://cb.vwgroup.com/cb/issue/" + str(new_item["ID"]) + "\"\n")

        elapsed_time = round(time.time() - start_time, 2)
        print("Exporting new items to csv took " + str(elapsed_time) + " seconds!")

    def _export_deleted_items_to_csv(self, bundle_audi, bundle_porsche):
        start_time = time.time()
        print("Exporting deleted items to csv...")

        # Check if files have been generated for the trackers. If they already exist, delete them
        file_name_audi = "deleted_items_" + bundle_audi["ID"] + ".csv"
        if os.path.isfile(file_name_audi):
            os.remove(file_name_audi)

        file_name_porsche = "deleted_items_" + bundle_porsche["ID"] + ".csv"
        if os.path.isfile(file_name_porsche):
            os.remove(file_name_porsche)

        # Get the list of deleted items in this Audi tracker
        deleted_items_audi = self._deleted_items["Audi"][bundle_audi["ID"]]

        # Get the list of deleted items in this Porsche tracker
        deleted_items_porsche = self._deleted_items["Porsche"][bundle_porsche["ID"]]

        # Write output for new items in Audi tracker
        with open(file_name_audi, "w", encoding="utf-8", buffering=1) as f:

            audi_items = bundle_audi["Items"]

            # First we need to prepare the headers
            f.write(
                "Tracker-Id;"
                "Tracker-Name;"
                "Item-Id;"
                "Foreign ID_DOORS_pe;"
                "Item-Type;"
                "Summary;"
                "Description;"
                "Fields;"
                "URL\n"
            )

            # Write each item to the .csv file
            for deleted_item_id in deleted_items_audi:
                deleted_item = audi_items.get_by_id(deleted_item_id)

                f.write(str(deleted_item["Tracker"]) + ";")
                f.write(str(deleted_item["Tracker"]["name"]) + ";")
                f.write(str(deleted_item["ID"]) + ";")
                f.write(str(deleted_item["Foreign ID_DOORS_pe"]) + ";")
                f.write(str(deleted_item["Type"]) + ";")
                f.write(str(deleted_item["Summary"]) + ";")

                description = _remove_chars(str(deleted_item["Description"]).replace("\"", "").replace(";", ""))
                f.write("\"" + description + "\";")

                fields = _remove_chars(str(deleted_item.deep_serialize()).replace("\"", "").replace(";", ""))
                f.write("\"" + fields + "\";")

                f.write("\"" + "https://cb.vwgroup.com/cb/issue/" + str(deleted_item["ID"]) + "\"\n")

        # Write output for new items in Porsche tracker
        with open(file_name_porsche, "w", encoding="utf-8", buffering=1) as f:
            porsche_items = bundle_porsche["Items"]

            # First we need to prepare the headers
            f.write(
                "Tracker-Id;"
                "Tracker-Name;"
                "Item-Id;"
                "Foreign ID_DOORS_pe;"
                "Item-Type;"
                "Summary;"
                "Description;"
                "Fields;"
                "URL\n"
            )

            # Write each item to the .csv file
            for deleted_item_id in deleted_items_porsche:
                deleted_item = porsche_items.get_by_id(deleted_item_id)

                f.write(str(deleted_item["Tracker"]) + ";")
                f.write(str(deleted_item["Tracker"]["name"]) + ";")
                f.write(str(deleted_item["ID"]) + ";")
                f.write(str(deleted_item["Foreign ID_DOORS_pe"]) + ";")
                f.write(str(deleted_item["Type"]) + ";")
                f.write(str(deleted_item["Summary"]) + ";")

                description = _remove_chars(str(deleted_item["Description"]).replace("\"", "").replace(";", ""))
                f.write("\"" + description + "\";")

                fields = _remove_chars(str(deleted_item.deep_serialize()).replace("\"", "").replace(";", ""))
                f.write("\"" + fields + "\";")

                f.write("\"" + "https://cb.vwgroup.com/cb/issue/" + str(deleted_item["ID"]) + "\"\n")

        elapsed_time = round(time.time() - start_time, 2)
        print("Exporting deleted items to csv took " + str(elapsed_time) + " seconds!")

    def _export_duplicate_items_to_csv(self, bundle_audi, bundle_porsche):
        start_time = time.time()
        print("Exporting duplicated items to csv...")

        # Check if files have been generated for the trackers. If they already exist, delete them
        file_name_audi = "duplicate_items_" + bundle_audi["ID"] + ".csv"
        if os.path.isfile(file_name_audi):
            os.remove(file_name_audi)

        file_name_porsche = "duplicate_items_" + bundle_porsche["ID"] + ".csv"
        if os.path.isfile(file_name_porsche):
            os.remove(file_name_porsche)

        # Get the list of duplicated items in this Audi tracker
        duplicate_items_audi = self._duplicated_items["Audi"][bundle_audi["ID"]]

        # Get the list of deleted items in this Porsche tracker
        duplicate_items_porsche = self._duplicated_items["Porsche"][bundle_porsche["ID"]]

        # Write output for new items in Audi tracker
        if len(duplicate_items_audi) != 0:
            with open(file_name_audi, "w", encoding="utf-8", buffering=1) as f:
                audi_items = bundle_audi["Items"]

                # First we need to prepare the headers
                f.write(
                    "Tracker-Id;"
                    "Tracker-Name;"
                    "Item-Id;"
                    "Foreign ID_DOORS_pe;"
                    "Item-Type;"
                    "Summary;"
                    "Description;"
                    "Fields;"
                    "URL\n"
                )

                # Write each item to the .csv file
                for duplicate_item_id in duplicate_items_audi:
                    duplicate_item = audi_items.get_by_id(duplicate_item_id)

                    f.write(str(duplicate_item["Tracker"]) + ";")
                    f.write(str(duplicate_item["Tracker"]["name"]) + ";")
                    f.write(str(duplicate_item["ID"]) + ";")
                    f.write(str(duplicate_item["Foreign ID_DOORS_pe"]) + ";")
                    f.write(str(duplicate_item["Type"]) + ";")
                    f.write(str(duplicate_item["Summary"]) + ";")

                    description = _remove_chars(str(duplicate_item["Description"]).replace("\"", "").replace(";", ""))
                    f.write("\"" + description + "\";")

                    fields = _remove_chars(str(duplicate_item.deep_serialize()).replace("\"", "").replace(";", ""))
                    f.write("\"" + fields + "\";")

                    f.write("\"" + "https://cb.vwgroup.com/cb/issue/" + str(duplicate_item["ID"]) + "\"\n")

        # Write output for new items in Porsche tracker
        if len(duplicate_items_porsche) != 0:
            with open(file_name_porsche, "w", encoding="utf-8", buffering=1) as f:
                porsche_items = bundle_porsche["Items"]

                # First we need to prepare the headers
                f.write(
                    "Tracker-Id;"
                    "Tracker-Name;"
                    "Item-Id;"
                    "Foreign ID_DOORS_pe;"
                    "Item-Type;"
                    "Summary;"
                    "Description;"
                    "Fields;"
                    "URL\n"
                )

                # Write each item to the .csv file
                for duplicate_item_id in duplicate_items_porsche:
                    duplicate_item = porsche_items.get_by_id(duplicate_item_id)

                    f.write(str(duplicate_item["Tracker"]) + ";")
                    f.write(str(duplicate_item["Tracker"]["name"]) + ";")
                    f.write(str(duplicate_item["ID"]) + ";")
                    f.write(str(duplicate_item["Foreign ID_DOORS_pe"]) + ";")
                    f.write(str(duplicate_item["Type"]) + ";")
                    f.write(str(duplicate_item["Summary"]) + ";")

                    description = _remove_chars(str(duplicate_item["Description"]).replace("\"", "").replace(";", ""))
                    f.write("\"" + description + "\";")

                    fields = _remove_chars(str(duplicate_item.deep_serialize()).replace("\"", "").replace(";", ""))
                    f.write("\"" + fields + "\";")

                    f.write("\"" + "https://cb.vwgroup.com/cb/issue/" + str(duplicate_item["ID"]) + "\"\n")

        elapsed_time = round(time.time() - start_time, 2)
        print("Exporting duplicated items to csv took " + str(elapsed_time) + " seconds!")


def main():
    # Input argument definitions for execution using Github actions
    parser = argparse.ArgumentParser(description="Creates an Excel file listing fields from the Audi and Porsche"
                                                 "trackers that have different values")

    parser.add_argument('--cb_server', type=str,
                        help='Instance the actions should be performed on (e.g. "Prod", "QS")',
                        default='QS')

    parser.add_argument('--tracker_mapping',
                        type=str, required=True,
                        help='Path to requirement doc mapping JSON file')

    parser.add_argument('--field_mapping', type=str,
                        required=True, help='Path to field mapping JSON file')

    parser.add_argument('--tracker_ids_to_filter',
                        type=str,
                        required=False,
                        help='Tracker IDs to filter (use comma separated or space-separated).')

    parser.add_argument('--item_status',
                        type=str,
                        required=False,
                        help='Status filter for items (e.g: "In Review"). '
                             'If not provided, all statuses will be considered')

    args = parser.parse_args()

    # return

    change_log = ChangeLog(
        cb_server=args.__dict__["cb_server"],
        trackers_json_path=Path(args.__dict__["tracker_mapping"]),
        field_mapping_path=Path(args.__dict__["field_mapping"]),
        item_status=args.__dict__["item_status"],
        tracker_ids_to_filter=args.__dict__["tracker_ids_to_filter"]
    )

    start_time = time.time()

    change_log.run()

    print("Total processing time: " + str(round((time.time() - start_time), 2)) + " seconds")


if __name__ == '__main__':
    main()
