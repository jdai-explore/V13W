import time
import json
import sys
from pathlib import Path
from argparse import ArgumentParser
import calmpy
import calmpy.exceptions
from datetime import datetime
import logging
import warnings


class UpdateMEFeedback:
    """
    UpdateMEFeedback - A class that will update Audi feedback based on ME feedback in codebeamer.
    """
    NOT_RELEASED_STATUS = ['in Progress', 'In Review', 'Obsolete', 'Re-evaluation', 'Unset']

    def __init__(self, cb_instance: str, tracker_ids_json: Path, output_dir: Path, baseline: int) -> None:
        """
        Constructs an object of UpdateMEFeedback that will handle the execution of updating feedback
        :param cb_instance: The url or short name for Codebeamer instance to work with
        :type cb_instance: str
        :param tracker_ids_json: path to .json file that contains tracker IDs to update feedback
        :type tracker_ids_json: Path
        :param baseline: Baseline ID for feedback integration from ME
        :type baseline: int
        :param output_dir: path to directory that results of the decision executor are stored
        :type output_dir: Path
        :return: None
        """
        # save parameters
        self._cb_instance = cb_instance
        self._tracker_ids_json = tracker_ids_json
        self._baseline = baseline
        # Prepare output path
        self._output_dir = output_dir
        # initialize the log
        self.full_execution_log = []
        # get the current time
        self._current_time = time.localtime()
        # format the current time
        self._formatted_time = time.strftime("%Y-%b-%d_%H-%M-%S", self._current_time)

    def update_feedback(self):
        """
        update ME feedback to codebeamer
        """
        cb_server = calmpy.Server(url=self._cb_instance, readonly=False)
        # read source_ids_json and check either tracker or item ids given
        with open(self._tracker_ids_json, encoding='utf-8') as file:
            data = json.load(file)

        if 'tracker_ids' in data:
            tracker_ids = data['tracker_ids']
            print("Proceeding with tracker level feedback update")
            for tracker_id in tracker_ids:
                tracker = cb_server.get_tracker(tracker_id=tracker_id)
                items_state_current = {item.id: item for item in tracker.get_items()}
                items_state_baseline = {item.id: item for item in tracker.get_items(baseline=self._baseline)}
                self.evaluate_status_and_feedback_changes(cb_server, items_state_current, items_state_baseline, self.full_execution_log, tracker_id)
        else:
            warnings.warn(f"Please provide tracker_ids_json file")
            return

        self.executed_actions_report(self.full_execution_log)

    def evaluate_status_and_feedback_changes(self, cb_server, items_state_current, items_state_baseline, full_execution_log, tracker_id=None):
        """
        Compares current and baseline item states, fetches item history and determines if a feedback action is needed.
        :param cb_server: The url or short name for Codebeamer instance to work with
        :type cb_server: calmpy.Server
        :param items_state_current: Dictionary containing current item states
        :type items_state_current: dict
        :param items_state_baseline: Dictionary containing baseline item states
        :type items_state_baseline: dict
        :param full_execution_log: Aggregated log of execution details
        :type full_execution_log: List
        :param tracker_id: optional tracker ID associated with the items (if tracker based json given)
        :type tracker_id: int or None
        """
        execution_log = {"Tracker_IDs": [tracker_id] if tracker_id else list(set(item['tracker']['id'] for item in items_state_current.values())),
                       "items": []}
        # skip items not in baseline
        for item_id, current_item in items_state_current.items():
            baseline_item = items_state_baseline.get(item_id)
            if not baseline_item:
                warnings.warn(f"Item {current_item.id} not found in baseline - skipping.")
                continue

            status_before = {
                "Status": baseline_item['Status'],
                "Status Audi to Mobileye_pe": baseline_item['Status Audi to Mobileye_pe'],
                "Status Mobileye to Audi_pe": baseline_item['Status Mobileye to Audi_pe'],
                "Comment Audi to Mobileye_pe": baseline_item['Comment Audi to Mobileye_pe']
            }

            baseline_item_date = baseline_item.modifiedAt

            # fetch item history
            history_url = f'{cb_server.query.SWAGGER_URL_V3}/items/{current_item.id}/history'
            response = cb_server.session.make_single_request(request_url=history_url, request_type='GET',
                                                     is_readonly_operation=True)

            status_changed = False
            for version in response.get('versions', []):
                modified = version.get("modifiedAt")
                if modified:
                    modified = datetime.fromisoformat(modified)
                if modified > baseline_item_date:
                    for change in version.get('changes', []):
                        if change.get('name') == 'Status':
                            status_changed = True
                            break

            if status_changed:
                # Use case 2: Requirements are modified since last export at audi
                if current_item['Status'] == baseline_item['Status'] == 'Released':
                    match current_item['Status Audi to Mobileye_pe']:
                        case 'To evaluate':
                            try:
                                if current_item['Status Mobileye to Audi_pe'] == 'Agreed':
                                    current_item['Comment Audi to Mobileye_pe'] = 'To Re-evaluate'
                                    current_item.update_fields()
                                    execution_log['items'].append({
                                        "item_id": current_item.id,
                                        "status_before": status_before,
                                        "status_after": {
                                            "Status": current_item['Status'],
                                            "Status Audi to Mobileye_pe": current_item['Status Audi to Mobileye_pe'],
                                            "Comment Audi to Mobileye_pe": current_item['Comment Audi to Mobileye_pe']
                                        },
                                        "Audi_action": "manual review should be performed and confirm that req is NOT complete",
                                        "ME_action": "ME needs to wait until the req is Released by Audi"
                                    })
                                elif current_item['Status Mobileye to Audi_pe'] == 'Not agreed':
                                    current_item['Comment Audi to Mobileye_pe'] = 'To Re-evaluate'
                                    current_item.update_fields()
                                    execution_log["items"].append({
                                        "item_id": current_item.id,
                                        "status_before": status_before,
                                        "status_after": {
                                            "Status": current_item['Status'],
                                            "Status Audi to Mobileye_pe": current_item['Status Audi to Mobileye_pe'],
                                            "Comment Audi to Mobileye_pe": current_item['Comment Audi to Mobileye_pe']
                                        },
                                        "Audi_action": "No action needed since ME has not agreed to the requirement yet",
                                        "ME_action": "ME to Re-evaluate"
                                    })

                            except calmpy.exceptions.ServerError as e:
                                msg = f"Problem in updating item {current_item.id}: {e}"
                                logging.error(msg)

                elif current_item['Status'] in self.NOT_RELEASED_STATUS and baseline_item['Status'] in self.NOT_RELEASED_STATUS:
                    match current_item['Status Audi to Mobileye_pe']:
                        case 'To evaluate':
                            if current_item['Status Mobileye to Audi_pe'] == 'Agreed':
                                # condition met, but no update logic required
                                pass
                            elif current_item['Status Mobileye to Audi_pe'] == 'Not agreed':
                                # condition met, but no update logic required
                                pass

                elif current_item['Status'] == 'Released' and baseline_item['Status'] in self.NOT_RELEASED_STATUS:
                    match current_item['Status Audi to Mobileye_pe']:
                        case 'To evaluate':
                            if current_item['Status Mobileye to Audi_pe'] == 'Empty':
                                current_item['Comment Audi to Mobileye_pe'] = 'To Re-evaluate'
                                current_item.update_fields()
                                execution_log["items"].append({
                                    "item_id": current_item.id,
                                    "status_before": status_before,
                                    "status_after": {
                                        "Status": current_item['Status'],
                                        "Status Audi to Mobileye_pe": current_item['Status Audi to Mobileye_pe'],
                                        "Comment Audi to Mobileye_pe": current_item['Comment Audi to Mobileye_pe']
                                    },
                                    "Audi_action": "No action needed since ME has not agreed to the requirement yet.",
                                    "ME_action": "ME needs to wait until the req is Released by Audi"
                                })
                            elif current_item['Status Mobileye to Audi_pe'] == ['Not agreed', 'Agreed with comment', 'To be clarified']:
                                # condition met, but no update logic required
                                pass

                elif current_item['Status'] in self.NOT_RELEASED_STATUS and baseline_item['Status'] == 'Released':
                    match current_item['Status Audi to Mobileye_pe']:
                        case 'To evaluate':
                            if current_item['Status Mobileye to Audi_pe'] == 'Agreed':
                                # condition met, but no update logic required
                                pass
                            elif current_item['Status Mobileye to Audi_pe'] in ['Not agreed', 'Agreed with comment',
                                                                                'To be clarified', 'Empty', 'Discard deployed']:
                                # condition met, but no update logic required
                                pass

            else:
                # Use case 1: Requirements are not modified since last export at audi
                if current_item['Status'] == baseline_item['Status'] == 'Released':
                    match current_item['Status Audi to Mobileye_pe']:
                        case 'Accepted':
                            execution_log['items'].append({
                                "item_id": current_item.id,
                                "status_before": status_before,
                                "status_after": {
                                    "Status": current_item['Status'],
                                    "Status Audi to Mobileye_pe": current_item['Status Audi to Mobileye_pe'],
                                    "Comment Audi to Mobileye_pe": current_item['Comment Audi to Mobileye_pe']
                                },
                                "Audi_action": "Already accepted, no action for ME",
                                "ME_action": None
                            })
                        case 'To evaluate':
                            try:
                                if current_item['Status Mobileye to Audi_pe'] == 'Agreed':
                                    current_item['Status Audi to Mobileye_pe'] = 'Accepted'
                                    current_item['Comment Audi to Mobileye_pe'] = ''
                                    current_item.update_fields()
                                    execution_log['items'].append({
                                        "item_id": current_item.id,
                                        "status_before": status_before,
                                        "status_after": {
                                            "Status": current_item['Status'],
                                            "Status Audi to Mobileye_pe": current_item['Status Audi to Mobileye_pe'],
                                            "Comment Audi to Mobileye_pe": current_item['Comment Audi to Mobileye_pe']
                                        },
                                        "Audi_action": "Manual review is not needed.",
                                        "ME_action": "Feedback accepted, No action for ME"
                                    })
                                elif current_item['Status Mobileye to Audi_pe'] == 'Not agreed':
                                    # condition met, but no update logic required
                                    pass
                            except calmpy.exceptions.ServerError as e:
                                msg = f"Problem in updating item {current_item.id}: {e}"
                                logging.error(msg)

                        case _:
                            warnings.warn(f"Item {current_item.id}: No use case matched - no update performed.")

                # Use case 1: No changes but status is not Released...!
                elif current_item['Status'] in self.NOT_RELEASED_STATUS and baseline_item['Status'] in self.NOT_RELEASED_STATUS:
                    match current_item['Status Audi to Mobileye_pe']:
                        case 'To evaluate':
                            if current_item['Status Mobileye to Audi_pe'] == 'Agreed':
                                # condition met, but no update logic required
                                pass
                            elif current_item['Status Mobileye to Audi_pe'] == 'Not agreed':
                                # condition met, but no update logic required
                                pass
                        case _:
                            warnings.warn(f"Item {current_item.id}: No use case matched - no update performed.")

        if execution_log["items"]:
            full_execution_log.append(execution_log)

    def executed_actions_report(self, full_execution_log):
        """
        Writes the executed actions to a JSON report file.
        :param full_execution_log: list of dictionaries containing action details
        """
        output_dir = Path(self._output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        #path to a report file
        report_path = output_dir / f"Executed_actions_report_{self._formatted_time}.json"
        try:
            with report_path.open('w', encoding='utf-8') as f:
                json.dump(full_execution_log, f, indent=4)
                print(f"Report of executed actions written to {report_path.resolve()}")
        except Exception as e:
            warnings.warn(f"Failed to write execution report: {e}")

def add_arguments(parser: ArgumentParser):
    '''
    This functions handles the arguments for this script
    :param parser: argument parser including arguments to parse
    :type parser: ArgumentParser
    '''
    parser.add_argument('--cb_instance',
                        help='specifies on which instance the updates are made ("Prod", "QS", ...)',
                        type=str)
    parser.add_argument('--tracker_ids_json',
                        help='json including tracker IDs to update ME feedback',
                        type=str)
    parser.add_argument('--baseline',
                        help=' Baseline ID to compare with',
                        type=int,
                        default=None)
    parser.add_argument('--output_dir',
                        help='Path to output directory',
                        type=str)

def main() -> int:
    '''
    This functions updates the ME feedback to codebeamer.
    '''

    # argument parsing
    parser = ArgumentParser(prog='update_ME_feedback',
                            description='Updates the ME feedback to codebeamer')
    add_arguments(parser=parser)
    args = parser.parse_args()

    if not args.tracker_ids_json:
        warnings.warn(f"Error: Please provide --tracker_ids_json to update ME feedback")
        sys.exit(1)
    update_me_feedback = UpdateMEFeedback(cb_instance=args.cb_instance,
                                          tracker_ids_json=args.tracker_ids_json,
                                          baseline=args.baseline,
                                          output_dir=Path(args.output_dir))
    update_me_feedback.update_feedback()


if __name__ == '__main__':
    main()
