import calmpy
import datetime
import json
import os
from pathlib import Path
from argparse import ArgumentParser
import time
import warnings
import zipfile
import xml.etree.ElementTree as ET

class CodebeamerImport:
    """
    CodebeamerImport - A class that will handle the import of reqifz files
    """

    def __init__(self, cb_server: str, reqif_file_path: str, mapping_file: str, project_id: int, output_dir_base: str) -> None:
        """
        Constructs an object of CodebeamerImport that will handle the execution of CCD decisions
        :param cb_server: The url or short name for Codebeamer instance to work with
        :type cb_server: str
        :param reqif_file_path: The path to the reqif file
        :type reqif_file_path: str
        :param mapping_file: The path to the mapping file
        :type mapping_file: str
        :param project_id: The ID of the project
        :type project_id: int
        :param output_dir_base: The path to the output directory
        :type output_dir_base: str
        :return: None
        """
        # save parameters
        self._cb_server = calmpy.Server(url=cb_server, readonly=False)
        self._reqif_file_path = reqif_file_path
        self._mapping_file = mapping_file
        self._project_id = project_id
        self._output_dir_base = output_dir_base

        # get the current time
        self._current_time = time.localtime()

        # format the current time
        self._formatted_time = time.strftime("%Y-%b-%d", self._current_time)
        # validate the mapping file during initialization
        if not self._validate_mapping_file():
            raise ValueError("Mapping file validation failed. Please check the mapping json file.")

    def _validate_mapping_file(self) -> bool:
        """
        validates the mapping json file
        :return: True if the mapping file is valid, False otherwise
        :Type: bool
        """
        project = self._cb_server.get_project(self._project_id)
        # Validate mapping file before importing Reqif file
        response = project.validate_mapping_file_for_reqif_import(self._mapping_file)
        return self._check_all_valid(response)

    def _check_all_valid(self, data) -> bool:
        """
        Recursively checks that all 'valid' flags in the data are True.
        :param data: Dictionary or list
        :return: True if all nested 'valid' fields are True, else False.
        :Type: bool
        """
        if isinstance(data, dict):
            for key, value in data.items():
                if key == "valid" and value is False:
                    return False
                if not self._check_all_valid(value):
                    return False
        elif isinstance(data, list):
            for item in data:
                if not self._check_all_valid(item):
                    return False
        return True

    def get_valid_reqif_file(self):
        """
        Handles both .reqif and .reqifz files.
        Returns the path to a valid .reqif file ready for import
        """
        if not os.path.exists(self._reqif_file_path):
            raise FileNotFoundError(f"File doesn't exist: {self._reqif_file_path}")

        ext = os.path.splitext(self._reqif_file_path)[1].lower()
        if ext == ".reqif":
            with open(self._reqif_file_path, "r", encoding="utf-8") as f:
                first_line = f.readline().strip()
                if not first_line.startswith("<?xml") and "<REQ-IF" not in first_line:
                    raise ValueError("Invalid .reqif file: not XML format.")
            print(f"Valid .reqif file: {self._reqif_file_path}")
            return self._reqif_file_path
        elif ext == ".reqifz":
            if not zipfile.is_zipfile(self._reqif_file_path):
                raise ValueError("The .reqifz file is not a valid zip archive.")
            unzip_dir = "unzipped_reqifz"
            os.makedirs(unzip_dir, exist_ok=True)

            with zipfile.ZipFile(self._reqif_file_path, "r") as zip_ref:
                zip_ref.extractall(unzip_dir)
                reqif_files = [f for f in zip_ref.namelist() if f.endswith(".reqif")]
                if not reqif_files:
                    raise FileNotFoundError("No .reqif file found in .reqifz")
                extracted_reqif = os.path.join(unzip_dir, reqif_files[0])
                print(f"Extracted .reqif from .reqifz: {extracted_reqif}")
                return extracted_reqif
        else:
            raise ValueError("Unsupported file type. Provide .reqif or .reqifz file only.")

    def import_reqif_to_project(self) -> dict:
        """
        Imports a reqif file into the specified project on the Codebeamer instance.
        :return: A dictionary containing the result of the import operation.
        """
        print(f"Importing reqif file...")
        reqif_file = self.get_valid_reqif_file()
        # Get the project object from the Codebeamer server
        project = self._cb_server.get_project(self._project_id)
        try:
            # Import the reqif file into the project
            return project.reqif_import(reqif_file_path=reqif_file, mapping_file=self._mapping_file)
        except calmpy.BackgroundJobFailedException as e:
            print(f"Failed to import ReqIf file... {e}")


    def write_import_status_to_json(self, result: dict) -> None:
        """
        Logs the status of the ReqIF impor<<<<<<<t process to a JSON file
        Args: result (dict): The result of the import operation.
        """
        output_dir = Path(self._output_dir_base)
        if not output_dir.exists():
            output_dir.mkdir(parents=True, exist_ok=True)

        try:
            if not result or not any(result.get("result", [])):
                warnings.warn("Import of .reqifz file has not changed anything. Please check if the provided file is correct.")

            else:
                # Create the directory for the JSON file if it does not exist
                os.makedirs(output_dir, exist_ok=True)

                #Loop through the result to get individual tracker entries
                print(result)
                tracker_entries = []
                for entry in result["result"]:
                    tracker_entries.extend(entry if isinstance(entry, list) else [entry])

                for tracker_entry in tracker_entries:
                    tracker = tracker_entry.get("tracker", {})
                    tracker_id = tracker.get("id")
                    tracker_name = tracker.get("name")
                    #create a filename for json output based on trackers
                    json_filename = f"{tracker_name}.json"
                    filepath=os.path.join(output_dir, json_filename)

                    updates_summary = {
                        "trackerId": tracker_id,
                        "trackerName": tracker_name,
                        "updates": []
                    }

                    items = tracker_entry.get("items", {})
                    updated_items = items.get("updatedItems", []) if isinstance(items, dict) else items

                    for item in updated_items:
                        item_summary = {
                            "itemId": item.get("id"),
                            "description": item.get("description", ""),
                            "changes": []
                        }
                        # to compare old and new values / changes in the item
                        for change in item.get("changes", []):
                            old_value = change.get("oldValue", "").strip()
                            new_value = change.get("newValue", "").strip()
                            if old_value != new_value:
                                item_summary["changes"].append({
                                    "fieldName": change.get("fieldName"),
                                    "oldValue": old_value,
                                    "newValue": new_value
                                })

                        if item_summary["changes"]:
                            # If no changes were collected, add a message
                            updates_summary["updates"].append(item_summary)
                            if not updates_summary["updates"]:
                                updates_summary["message"] = "No changes detected for this tracker."
                    print('updates...',updates_summary)
                    with open(filepath, "w", encoding="utf-8") as f:
                        json.dump(updates_summary, f, indent=2)
                        print(f"Log/Status of import written to: {json_filename}")

        except Exception as e:
            # Print an error message if the result cannot be written to the JSON file
            print(f"Failed to write result to {output_dir}: {str(e)}")


def add_arguments(parser: ArgumentParser) -> None:
    '''
    This function handles the arguments for this script
    :param parser: argument parser including arguments to parse
    :type parser: ArgumentParser
    '''
    parser.add_argument('--cb_server',
                        help='specifies on which instance the updates are made ("Prod", "QS", ...)',
                        type=str)
    parser.add_argument('--reqif_file_path',
                        help='path to reqif',
                        type=str)
    parser.add_argument('--mapping_file',
                        help='path to mapping file',
                        type=str)
    parser.add_argument('--project_id',
                        help='the id of the project',
                        type=int)
    parser.add_argument('--output_dir',
                        help='path to the output directory',
                        type=str)


def main() -> int:
    '''
    This function handles the import of ReqIF
    '''

    # argument parsing
    parser = ArgumentParser(prog='codebeamer_import',
                            description='imports the reqif')
    add_arguments(parser=parser)
    args = parser.parse_args()

    # Create a CodebeamerImport object
    codebeamer_import = CodebeamerImport(cb_server=args.cb_server,
                                         reqif_file_path=args.reqif_file_path,
                                         mapping_file=args.mapping_file,
                                         project_id=args.project_id,
                                         output_dir_base = args.output_dir)

    # Import the reqif file into Codebeamer
    result = codebeamer_import.import_reqif_to_project()

    # Log the status of import reqif result to the JSON file
    codebeamer_import.write_import_status_to_json(result)

if __name__ == '__main__':
    main()
