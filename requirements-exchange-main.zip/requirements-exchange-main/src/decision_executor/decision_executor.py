import sys
import json
import argparse
import logging
import calmpy.exceptions
import pandas as pd
from dataclasses import dataclass, fields, field
from enum import Enum
from altair import Description
from pandas.core.methods.selectn import SelectNSeries
from tqdm import tqdm
from pathlib import Path
from datetime import date
from typing import Dict, List, Tuple
import calmpy
from src.rep_dataclasses.ccb_decision import CCBDecision, Decision

class Status(Enum):
    SUCCESS = 'Successful'
    FAILED = 'Failed'
    SKIPPED = 'Skipped'
    INIT = 'Initial Value'

@dataclass
class ItemCreationStep:
    action: str
    field: str = ""
    value: str = ""
    message: str = ""

@dataclass
class ItemExecution:
    status: Status
    item_id: str = ""
    tracker_id: str = ""
    reference_id: str = ""
    reference_type: str = ""
    summary: str = ""
    description: str = ""
    type_: str = ""
    steps: list = field(default_factory=list)
    error_message: str = ""

    def get_step_str(self):
        return " | ".join(
            f"{s.field}: {s.value}" for s in self.steps
            if s.action == "updated_field"
        )

@dataclass
class DecisionExecutionStep:
    """
    A class that represents a step of decision execution
    """
    status: Status = Status.INIT
    query: str = ''
    server: str = ''

    def __str__(self):
        """Returns a string containing only the non-default field values."""
        s = ', '.join(f'{field.name}={getattr(self, field.name)!r}'
                      for field in fields(self)
                      if getattr(self, field.name) != field.default)
        return f'({s})'

@dataclass
class DecisionExecution:
    """
    A class that represents the execution of a decision with its status and executed steps
    """
    status: Status
    steps: List[DecisionExecutionStep]

    def get_step_str(self):
        """
        Returns a string that contains data of all steps
        """
        return ('/'.join(['{' + str(step) + '}' for step in self.steps])
                if self.steps else 'No steps executed!')

    @staticmethod
    def get_status(steps: list[DecisionExecutionStep]) -> Status:
        """
        Returns aggregated status of steps
        """
        status = Status.FAILED

        if all([step.status == Status.SUCCESS for step in steps]):
            status = Status.SUCCESS

        if all([step.status == Status.SKIPPED for step in steps]):
            status = Status.SKIPPED

        return status

class DecisionExecutor:
    """
    DecisionExecutor - A class that will handle the execution of CCB decisions
    """
    # new items columns in excel for ccb decisions to update field values
    NEW_ITEM_COLUMNS = [
                        'Module Variant_pe',
                        'BsM-E.D_ct',
                        'BsM-E.D comment_ct',
                        'BsM-E.L_ct',
                        'BsM-E.L comment_ct',
                        'BsM-E.T_ct',
                        'BsM-E.T comment_ct',
                        'BsM-O_ct',
                        'BsM-O comment_ct',
                        'BsM-Sa.FuSi_ct',
                        'BsM-Sa.FuSi comment_ct',
                        'Tested by_pe',
                        'Verification Environment_ct',
                        'Verification Method_ct',
                        'Relevance for HW-Module_ct',
                        'Relevance for Testing_pe',
                        'Functional Safety Classification (according ISO26262)_ct',
                        'Change Request_pe',
                        'Foreign ID_ct',
                        'Function_ct',
                        'Foreign ID Mobileye_pe',
                        'Foreign ID_DOORS_pe']

    def __init__(self, cb_server: str, ccb_decisions_path: Path,
                 execution_state_path: Path, output_dir: Path,
                 sv62_to_ch63_field_mapping_path: Path) -> None:
        """
        Constructs an object of DecisionExecutor that will handle the execution of CCD decisions
        :param cb_server: The url or short name for Codebeamer instance to work with
        :type cb_server: str
        :param ccb_decisions_path: path to .xlsx file that contains CCB decision data
        :type ccb_decisions_path: Path
        :param sv62_to_ch63_field_mapping_path: path to .json file that contains SV62 to CH63 field mappings
        :type sv62_to_ch63_field_mapping_path: Path
        :param execution_state_path: path to .json file that contains the synchronization states
        :type execution_state_path: Path
        :param output_dir: path to directory that results of the decision executor are stored
        :type output_dir: Path
        :return: None
        """
        # Prepare date of execution
        self._time_str = str(date.today())

        # Prepare output path
        self._output_dir = output_dir

        # Prepare ccb decisions
        self._ccb_decisions_path = ccb_decisions_path

        # Load ccb decision data
        self._ccb_decision_df = self.__load_xlsx(
            data_file_path=ccb_decisions_path)

        # Load execution state json
        self._execution_state_path = execution_state_path
        self._execution_state = self.__load_json(self._execution_state_path)

        # Load SV62 to CH63 and new items field mapping
        self._sv62_to_ch63_field_mapping_path = sv62_to_ch63_field_mapping_path
        self._sv62_to_ch63 = self.__load_json(
            self._sv62_to_ch63_field_mapping_path)

        # initialize calmpy codebeamer server
        self._cb_server = calmpy.Server(url=cb_server, readonly=False)

    def insert_item_with_hierarchy(self, item_dict: dict, tracker_id: int, reference_item_id: int, reference_is_predecessor: bool = True,
                                   reference_is_parent = None) -> Tuple[Status, calmpy.Item, str]:
        """
        Creates item with provided data for a specified reference id
        :param reference_is_predecessor: information if reference id is the predecessor or successor
        :type reference_is_predecessor: bool
        :param reference_is_parent: information if reference id is the parent
        :type reference_is_parent: bool
        :param reference_item_id: id of item for reference to hierarchy
        :type reference_item_id: int
        :param tracker_id: id of tracker where to insert item to
        :type tracker_id: str
        :param item_dict: data of item to add
        :type item_dict: dict
        :return: item that got added
        :type calmpy.Item
        """
        try:
            new_item = self._cb_server.get_tracker(
                tracker_id=int(tracker_id)).create_item(fields=item_dict)

            # update hierarchy
            status, msg = self.update_parent(reference_item_id=reference_item_id,
                                             item_id=new_item.id,
                                             reference_is_predecessor=reference_is_predecessor,
                                             reference_is_parent=reference_is_parent)
        except calmpy.exceptions.ServerError as e:
            print(e)
            print(f'Problem in creating item with data: {item_dict}')
            return Status.FAILED, None, e
        return status, new_item, msg

    def update_parent(self, reference_item_id: int, item_id: int, reference_is_predecessor: bool = True,
                      reference_is_parent = None) -> Tuple[Status, str]:
        """
        Updates item hierarchy in codebeamer so that item is item after reference item
        :param reference_item_id: id of item that is the predecessor to the item with item_id
        :type reference_item_id: int
        :param item_id: id of item to update the hierarchy for
        :type item_id: int
        :param reference_is_predecessor: information if reference item is predecessor or successor
        :type reference_is_predecessor: bool
        :param reference_is_parent: information if reference id is the parent
        :type reference_is_parent: bool
        :return: Status and message
        :type Tuple[Status, str]
        """
        if reference_is_parent:
            parent_id = reference_item_id
        else:
            reference_item = self._cb_server.get_item(item_id=reference_item_id)
            if reference_item['parent'] is not None:
                parent_id = reference_item['parent'].id
            else:
                return Status.SUCCESS, 'Could not update parent due to no parent available (reference item on top level)'

        # url of children for parent
        children_url = f'{self._cb_server.query.SWAGGER_URL_V3}/items/' + \
            f'{int(parent_id)}/children'

        # get all current item children
        response = self._cb_server.session.make_paged_requests(request_url=children_url,
                                                               request_type='GET',
                                                               is_readonly_operation=True,
                                                               entries=500)

        # check if its more than 1 page
        if response.total > 1:
            print(f'parent {parent_id} has more than 500 children.' +
                  f' Hierarchy of item {item_id} will be ignored')
            return Status.FAILED, f'Item {parent_id} has more than 500 children, update will not work'

        # extract children list
        parent_child_refs = response.all[0].content['itemRefs']

        # convert to list of children ids
        existing_children_ids = [children['id']
                                 for children in parent_child_refs]

        # check if item is already a child
        if item_id not in existing_children_ids:
            if reference_is_parent == None or reference_is_parent == False:
                for idx, child in enumerate(parent_child_refs):
                    if child['id'] == reference_item_id:
                        if reference_is_predecessor:  # reference is predecessor -> insert child after reference item
                            parent_child_refs.insert(
                                idx + 1, {'id': int(item_id), 'type': 'TrackerItemReference'})
                            break
                        else:  # reference is succsessor -> insert child before reference item
                            parent_child_refs.insert(
                                idx, {'id': int(item_id), 'type': 'TrackerItemReference'})
                            break
            else:
                parent_child_refs.append({'id': int(item_id), 'type': 'TrackerItemReference'})

            # transform to query data
            children_data = {'children': parent_child_refs}

            # update hierarchy
            try:
                response = self._cb_server.session.make_single_request(
                    request_url=children_url, request_type='PUT', data=children_data)
            except ...:
                return Status.FAILED, f'ERROR: {item_id} was not set as child of {parent_id}'
            return Status.SUCCESS, f'{item_id} was successfully set as child of {parent_id} (after {reference_item_id})'
        return Status.SUCCESS, f'{item_id} was already a child of {parent_id}'

    def execute_decisions(self):
        """
        Executes all provided ccb decisions
        :return: None
        """
        # Check if there are decisions
        if not self._ccb_decision_df.empty:
            executed_decisions_df = pd.DataFrame(
                columns=(list(self._ccb_decision_df.columns) +
                         ['Status', 'Execution Date', 'Executed Steps']))

            # prepare data to prevent duplicated execution
            deviated_item_ids = []
            obsolete_items_ids = []

            # Iterate over all entries
            for _, row in tqdm(self._ccb_decision_df.iterrows(), total=self._ccb_decision_df.shape[0]):
                # Prepare ccb decision entry
                ccb_decision = CCBDecision.from_series(series=row)

                decision_execution = None
                match ccb_decision.decision:
                    case Decision.SV62_TO_CH63:
                        decision_execution = self.__execute_sv62_to_ch63(
                            ccb_decision=ccb_decision)
                    case Decision.CH63_TO_SV62:
                        decision_execution = self.__execute_ch63_to_sv62(
                            ccb_decision=ccb_decision)
                    case Decision.OBSOLETE:
                        # check if other changes already triggered OBSOLETE execution
                        if ccb_decision.modified_item.item_id_ch63 not in obsolete_items_ids:
                            # execute OBSOLETE
                            decision_execution = self.__execute_obsolete(
                                ccb_decision=ccb_decision)
                            # save item as processed in OBSOLETE
                            obsolete_items_ids.append(
                                ccb_decision.modified_item.item_id_ch63)
                    case Decision.DEVIATE:
                        # check if other changes already triggered DEVIATE execution
                        if ccb_decision.modified_item.item_id_ch63 not in deviated_item_ids:
                            # execute DEVIATE
                            decision_execution = self.__execute_deviate(
                                ccb_decision=ccb_decision)
                            # save item as processed in DEVIATE
                            deviated_item_ids.append(
                                ccb_decision.modified_item.item_id_ch63)
                    case _:
                        msg = f'The decision provided "{ccb_decision.decision}" is not known!'
                        step = DecisionExecutionStep(query=msg,
                                                     server=None,
                                                     status=Status.SKIPPED)
                        decision_execution = DecisionExecution(
                            status=DecisionExecution.get_status(steps=[step]), steps=[step])

                # Execute decision
                executed_decision_dict = row.to_dict()

                if decision_execution is not None:
                    # Add status
                    executed_decision_dict['Status'] = decision_execution.status.name

                    # Add executed steps
                    executed_decision_dict['Executed Steps'] = decision_execution.get_step_str(
                    )
                else:
                    # Add status
                    executed_decision_dict['Status'] = Status.FAILED.name

                # Add execution date
                executed_decision_dict['Execution Date'] = self._time_str

                # Add executed decision to dataframe
                executed_decisions_df.loc[len(
                    executed_decisions_df)] = executed_decision_dict

                # Save executed decision dataframe
                self.__save_df_as_xlsx(df=executed_decisions_df, data_file_path=(
                    Path(self._output_dir) / f'{self._ccb_decisions_path.stem}_processed.xlsx'))

            # Update execution state
            self.__update_execution_state()
        else:
            eprint("There are no CCB decisions to execute.")

    def __load_json(self, config_file_path: Path) -> Dict:
        """
        Loads JSON file.
        :param config_file_path: path to .json file
        :type config_file_path: Path
        :return: Json data
        :type Dict
        """
        with open(config_file_path, 'r', encoding='utf-8') as file:
            return json.load(file)

    def execute_new_items_decisions(self):
        """
        Loads xlsx file and creates new items based on ccb decisions and update fields in cb.
        """
        df = pd.read_excel(self._ccb_decisions_path, sheet_name="new_items")
        reference_is_predecessor = None
        reference_is_parent = None
        ccb_decision_column = "CCB Decision"
        item_placement_info = ""

        #Check if all new item columns and CCB decision column are in excel file
        required_columns = self.NEW_ITEM_COLUMNS + [ccb_decision_column]
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            raise ValueError(f"Missing required columns for new items in Excel file: {missing_columns}")

        report_log = []
        created_item_ids = []
        # loop through required rows
        for i, row in df.iterrows():
            df.columns = df.columns.str.strip()
            parsed_ccb_dict = {}
            reference_id = None
            tracker_id = None
            # fields to create item
            fields = {}
            if 'Type' in df.columns:
                fields['Type'] = row['Type']
                fields['Summary'] = row['Summary']
                fields['Description'] = row['Description']
            # Add info to the report
            report = ItemExecution(
                status=Status.INIT,
                summary=row.get("Summary", ""),
                description=row.get("Description", ""),
                type_=row.get("Type", "")
            )
            try:
                ccb_decision = row[ccb_decision_column]
                if pd.notna(ccb_decision):
                    for entry in ccb_decision.split(";"):
                        if "=" in entry:
                            key, value = entry.split("=", 1)
                            parsed_ccb_dict[key.strip()] = value.strip()
                    # extract requested hierarchy by reference id
                    destination_type = parsed_ccb_dict['destination_type']
                    reference_id = int(parsed_ccb_dict['destination_reference'])
                    tracker_id = self._cb_server.get_item(reference_id).tracker.id
                    if 'Last item (Top Level)' in destination_type:
                        # create Last item (Top Level)
                        item = self._cb_server.get_tracker(
                            tracker_id=int(tracker_id)).create_item(fields=fields)
                        item_placement_info = f"-> Placed as last item in tracker {tracker_id}"
                    else:
                        if 'Predecessor' in destination_type:
                            reference_is_predecessor = True
                            item_placement_info = f"-> Placed after item Id {reference_id} (as Predecessor)"
                        elif 'Successor' in destination_type:
                            reference_is_predecessor = False
                            item_placement_info = f"-> Placed before item Id {reference_id} (as Successor)"
                        else:
                            reference_is_parent = True
                            item_placement_info = f"-> Placed as child of tracker {tracker_id}"
                        # create item
                        status, item, msg = self.insert_item_with_hierarchy(item_dict=fields,
                                                                            tracker_id=tracker_id,
                                                                            reference_item_id=reference_id,
                                                                            reference_is_predecessor=reference_is_predecessor,
                                                                            reference_is_parent=reference_is_parent)
                    print(
                        f"Status: {status.name} | Item ID: {item.id} was successfully created\n"
                        f"-> Tracker ID: {tracker_id}\n"
                        f"{item_placement_info}\n"
                        f"-> Reference ID used: {reference_id if 'Parent' not in destination_type else 'N/A'}\n"
                    )
                    created_item_ids.append(item.id)
                report.steps.append(ItemCreationStep(action="create_item"))
                report.item_id = item.id
                report.tracker_id = tracker_id
                report.reference_id = str(reference_id)
                report.status = Status.SUCCESS
                fields_to_update = {}
                # update field values from NEW_ITEM_COLUMNS
                for new_item_field_name in self.NEW_ITEM_COLUMNS:
                    mapped_field_name = self._sv62_to_ch63.get(new_item_field_name)
                    # skip if the mapping is null or missing
                    if not mapped_field_name:
                        continue
                    # extract module variant_pe value
                    if new_item_field_name == 'Module Variant_pe':
                        module_variant_pe = parsed_ccb_dict['module_variant']
                        if not module_variant_pe or module_variant_pe.strip() == "None" :
                            field_value = None
                        else:
                            # only comma separated string
                            module_variant_pe = [mod_var.strip() for mod_var in module_variant_pe.split(',')]
                            if any("Take over from other instance" in mod_var for mod_var in module_variant_pe):
                                # take value from the column Module Variant_pe
                                base_value = row.get('Module Variant_pe')
                                base_values = []
                                if pd.notna(base_value) and isinstance(base_value, str):
                                    base_values = [v.strip() for v in base_value.split(',')]
                                # remove take over from other instance and keep the rest
                                additional_values = [mod_var for mod_var in module_variant_pe if "Take over from other instance" not in mod_var]
                                field_value = base_values + additional_values
                            else:
                                field_value = module_variant_pe
                    else:
                        field_value = None if pd.isna(row[new_item_field_name]) else row[new_item_field_name]
                    fields_to_update[mapped_field_name] = field_value
                    # only log if the value is changed
                    original_value = item[mapped_field_name] if mapped_field_name in item else None
                    if original_value != field_value:
                        report.steps.append(ItemCreationStep(
                            action="updated_field", field=mapped_field_name, value=str(field_value)
                        ))
                #update all the fields of an item
                item.update_fields(fields=fields_to_update)
            except Exception as e:
                report.status = Status.FAILED
                report.error_message = str(e)
                report.steps.append(ItemCreationStep(action="error", message=str(e)))
            report_log.append(report)
        # write excel Report
        df_report = pd.DataFrame([{
            "Created Item ID": rep.item_id,
            "Tracker ID": rep.tracker_id,
            "Reference ID": rep.reference_id,
            "Status": rep.status.value,
            "Summary": rep.summary,
            "Description": rep.description,
            "Type": rep.type_,
            "Updated Fields": rep.get_step_str(),
            "Error Message": rep.error_message
        } for rep in report_log])
        df_report.to_excel("New_items_execution_report.xlsx", index=False)
        return created_item_ids

    def __load_xlsx(self, data_file_path: Path) -> pd.DataFrame:
        """
        Loads xlsx file and returns pandas Dataframe
        :param data_file_path: Path of xlsx file
        :type data_file_path: Path
        :return: xlsx data
        :type data_file_path: pd.DataFrame
        """
        if data_file_path.suffix == ".xlsx":
            return pd.read_excel(data_file_path)
        else:
            print('Requested requirement input format not accepted!')
            return None

    def __save_df_as_xlsx(self, df: pd.DataFrame, data_file_path: Path):
        """
        Saves Dataframe in given path
        :param df: Dataframe to save
        :type df: pd.DataFrame
        :param data_file_path: Path where Dataframe should be saved
        :type data_file_path: Path
        """
        writer = pd.ExcelWriter(data_file_path, engine='xlsxwriter')
        df.to_excel(writer, sheet_name='Updates', index=False)

        for column in df:
            column_length = max(df[column].astype(
                str).map(len).max(), len(column)) + 5
            col_idx = df.columns.get_loc(column)
            writer.sheets['Updates'].set_column(
                col_idx, col_idx, column_length)

        writer.close()

    def __get_latest_iteration(self) -> Dict:
        """
        Provides last iteration number
        :return: last iteration number
        :type int
        """
        return int(max(self._execution_state, key=lambda x: int(x['Iteration']))['Iteration'])

    def __update_execution_state(self) -> None:
        """
        Updates the execution state with the current iteration and execution date.
        """
        new_execution_state = {
            "Iteration": str(self.__get_latest_iteration() + 1),
            "DateOfExecution": self._time_str,
            "Status": "Success"
        }
        self._execution_state.append(new_execution_state)
        with open(self._execution_state_path, 'w') as file:
            json.dump(self._execution_state, file, indent=4)

    def update_field(self, item_id: int, field_name: str, field_value):
        """
        Updates the specified field in Codebeamer with provided value
        :param item_id: id of item which field will get updated
        :type item_id: int
        :param field_name: name of the field to update
        :type field_name: str
        :param field_value: value to update item field to
        :type field_value: int/str/list
        :return: status of the update operation
        :type Status
        """
        # execute step
        try:
            item = calmpy.Item(server=self._cb_server, item_id=item_id)
            item[field_name] = field_value
            item.update_fields()

            # verify update
            item = calmpy.Item(server=self._cb_server, item_id=item_id)

            if field_name in item:
                if item[field_name] == field_value:
                    return Status.SUCCESS, 'Success'
            return Status.FAILED, 'Positive response from server but value was not updated'
        except calmpy.exceptions.ServerError as e:
            return Status.FAILED, f"An error occurred: {e}"

    def set_item_to_state(self, item_id: int, state_name: str) -> Tuple[Status, str]:
        """
        Updates the 'Status' field of given item in Codebeamer to specified state
        :param item_id: id of item which status will be updated to specified state
        :type item_id: int
        :param state_name: name of the state the item should be updated to
        :type state_name: str
        :return: status of the update operation
        :type Status
        """
        if pd.isna(item_id):
            return Status.FAILED, 'Given item id is empty'

        # Get valid transitions for this item
        request_transition_url = f"{self._cb_server.query.SWAGGER_URL_V3}/items/{int(item_id)}/transitions"

        response_transition = self._cb_server.session.make_single_request(
            request_url=request_transition_url,
            request_type='GET',
            is_readonly_operation=True)

        # Get transition that ends in 'Obsolete' if exists
        state_transition = next((transition.get("toStatus") for transition in response_transition
                                 if transition.get("toStatus")['name'] == state_name), None)

        if state_transition is not None:
            # URL of item
            request_url = f"{self._cb_server.query.SWAGGER_URL_V3}/items/{int(item_id)}"

            # get current data of item
            response_item = self._cb_server.session.make_single_request(
                request_url=request_url,
                request_type='GET',
                is_readonly_operation=True)

            # Update state data
            response_item['status'] = state_transition

            try:
                # Update item
                response = self._cb_server.session.make_single_request(request_url=request_url,
                                                                       request_type='PUT',
                                                                       data=response_item)
            except calmpy.exceptions.ServerError as e:
                return Status.FAILED, '/'.join([failed_response.content['message']
                                                for failed_response in e.failed_responses])

            # check if transition was successfull
            request_transition_url = f"{self._cb_server.query.SWAGGER_URL_V3}/items/{int(item_id)}/transitions"

            response_transition = self._cb_server.session.make_single_request(
                request_url=request_transition_url,
                request_type='GET',
                is_readonly_operation=True)

            current_state = next((transition.get("fromStatus")['name']
                                 for transition in response_transition), None)

            if current_state == state_name:
                return Status.SUCCESS, 'Success'
            else:
                return Status.FAILED, 'Positive feedback from API but result does not match'
        else:
            current_state = next((transition.get("fromStatus")['name']
                                 for transition in response_transition), None)
            return (Status.FAILED,
                    f'There is no valid transition to "{state_name}" from current Status ' +
                    f'"{current_state}" for item {item_id}')

    def copy_sv62_item_to_ch63(self, item_id_to_copy: int, tracker_id: int,
                               reference_item_id: int) -> Tuple[Status, str, int]:
        """
        Generates a copy of provided item
        :param item_id_to_copy: id of item to copy data from
        :type item_id_to_copy: int
        :param tracker_id: id of tracker to insert new item in
        :type tracker_id: int
        :param reference_item_id: id of item used for hierarchy data (parent)
        :type reference_item_id: int
        :return: Return status of operation (SUCCESS, FAILED),
                 a corresponding message and new item id
        :type Tuple[Status, str, int]
        """
        # get data of item to copy
        item = self._cb_server.get_item(item_id=item_id_to_copy)

        # prepare data as dict (with mapping if necessary)
        ignore_fields = ['ID',
                         'Tracker',
                         'Tracker Type_ct',
                         'typeName',
                         'Team',
                         'Owner',
                         'Attachments',
                         'parent',
                         'ordinal',
                         'children',
                         'version',
                         'Business Value',
                         'Submitted at',
                         'Submitted by',
                         'Modified at',
                         'Modified by',
                         'Assigned to',
                         'Status']
        ignore_fields = [field.lower() for field in ignore_fields]

        trackers_ch63 = self._cb_server.get_project(1329).get_trackers()

        if item.tracker in trackers_ch63:  # origin: CH63 tracker
            item_field_dict = {field: item[field]
                               for field in item
                               if item[field] is not None and
                               field.lower() not in ignore_fields}
        else:  # origin: SV62 tracker
            item_field_dict = {self._sv62_to_ch63[field]: item[field]
                               for field in item
                               if item[field] is not None and
                               self._sv62_to_ch63[field] is not None and
                               self._sv62_to_ch63[field].lower() not in ignore_fields}

        new_item = self._cb_server.get_tracker(
            int(tracker_id)).create_item(fields=item_field_dict)

        # update hierarchy based on reference parent
        status, msg = self.__update_parent(reference_item_id=reference_item_id,
                                           item_id=new_item.id)

        return status, msg, new_item.id

    def remove_from_field(self, item_id: int, field_name: str, remove_sub_value: str) -> Tuple[Status, str]:
        """
        Removes a sub value from a field value of an specified item
        (removes sub string from string value or removes entries containing subvalue from list)
        :param item_id: id of item remove sub field value from
        :type item_id: int
        :param field_name: name of field to update
        :type field_name: str
        :param remove_sub_value: value to remove
        :type remove_sub_value: str
        :return: Return status of operation (SUCCESS, FAILED) and
                 a corresponding message
        :type Tuple[Status, str]
        """
        item = self._cb_server.get_item(item_id=item_id)

        field_value = item[field_name]

        if isinstance(field_value, str):
            field_value = field_value.replace(remove_sub_value, '')
        elif isinstance(field_value, list):
            field_value_list = []
            for entry in field_value:
                if remove_sub_value not in entry:
                    field_value_list.append(entry)
            field_value = field_value_list

        return self.update_field(item_id=item_id, field_name=field_name, field_value=field_value)

    def __update_parent(self, reference_item_id: int, item_id: int) -> Tuple[Status, str]:
        reference_item = self._cb_server.get_item(item_id=reference_item_id)
        parent_id = reference_item['parent'].id

        # url of children for parent
        children_url = f'{self._cb_server.query.SWAGGER_URL_V3}/items/' + \
            f'{int(parent_id)}/children'

        # get all current item children
        response = self._cb_server.session.make_paged_requests(request_url=children_url,
                                                               request_type='GET',
                                                               is_readonly_operation=True,
                                                               entries=500)

        # check if its more than 1 page
        if response.total > 1:
            print(f'parent {parent_id} has more than 500 children.' +
                  f' Hierarchy of item {item_id} will be ignored')
            return Status.FAILED, f'Item {parent_id} has more than 500 children, update will not work'

        # extract children list
        parent_child_refs = response.all[0].content['itemRefs']

        # convert to list of children ids
        existing_children_ids = [children['id']
                                 for children in parent_child_refs]

        # check if item is already a child
        if item_id not in existing_children_ids:
            # insert child after reference item
            for idx, child in enumerate(parent_child_refs):
                if child['id'] == reference_item_id:
                    parent_child_refs.insert(
                        idx + 1, {'id': int(item_id), 'type': 'TrackerItemReference'})

            # transform to query data
            children_data = {'children': parent_child_refs}

            # update hierarchy
            try:
                response = self._cb_server.session.make_single_request(
                    request_url=children_url, request_type='PUT', data=children_data)
            except ...:
                return Status.FAILED, f'ERROR: {item_id} was not set as child of {parent_id}'
            return Status.SUCCESS, f'{item_id} was successfully set as child of {parent_id} (after {reference_item_id})'
        return Status.SUCCESS, f'{item_id} was already a child of {parent_id}'

    def __get_ccb_decision_value(self, decision: Decision, participants: str, rational: str) -> str:
        """
        Provides the ccb decision field string in a fixed format
        :param decision: data of ccb decision
        :type decision: Decision
        :param participants: string of participants of ccb
        :type participants: str
        :param rational: rational of ccb for given decision
        :type rational: str
        :return: ccb decision field string
        :type str
        """
        return f'Decision "{decision.value}" was made by "{participants}" because "{rational}"'

    def __execute_sv62_to_ch63(self, ccb_decision: CCBDecision) -> DecisionExecution:
        """
        Executes a decision for "SV62_TO_CH63"
        Steps:
            - Update CH63 item field with SV62 value
            - Update field "CCB_Decision" of CH63 with ccb data
        :param decision: data of ccb decision
        :type decision: Decision
        :return: data for each step that got executed for this decision
        :type DecisionExecution
        """
        steps = []

        # STEP 1 - Update CH63 item field with SV62 value
        # prepare step 1
        item_id = ccb_decision.modified_item.item_id_ch63
        field_name = ccb_decision.modified_item.field_name_ch63
        field_value = ccb_decision.modified_item.field_value_sv62

        step = DecisionExecutionStep(query=f'Update field "{field_name}" of CH63 item "{item_id}"' +
                                     f' with SV62 value "{field_value}"',
                                     server=self._cb_server.URL)

        # execute step 1
        step.status, status_msg = self.update_field(item_id=item_id,
                                                    field_name=field_name,
                                                    field_value=field_value)

        # append step 1
        steps.append(step)

        # check if previous step was successfull
        if step.status == Status.FAILED:
            return DecisionExecution(status=DecisionExecution.get_status(steps=steps), steps=steps)

        # STEP 2 - Update the CCB_Decision field with corresponding CCB data
        # prepare step 2
        item_id = ccb_decision.modified_item.item_id_ch63
        field_name = 'CCB_Decision'
        field_value = self.__get_ccb_decision_value(ccb_decision.decision,
                                                    participants=ccb_decision.participants,
                                                    rational=ccb_decision.rational)

        step = DecisionExecutionStep(query=f'Update field "{field_name}" of CH63 item "{item_id}"' +
                                     f' with CCB data "{field_value}"',
                                     server=self._cb_server.URL)

        # execute step 2
        step.status, status_msg = self.update_field(item_id=item_id,
                                                    field_name=field_name,
                                                    field_value=field_value)

        # append step 2
        steps.append(step)

        return DecisionExecution(status=DecisionExecution.get_status(steps=steps), steps=steps)

    def __execute_ch63_to_sv62(self, ccb_decision: CCBDecision) -> DecisionExecution:
        """
        Executes a decision for "CH63_TO_SV62"
        Steps: None (will be processed in seperate ticket, after alignment with PAG)
        :param decision: data of ccb decision
        :type decision: Decision
        :return: data for each step that got executed for this decision
        :type DecisionExecution
        """
        step = DecisionExecutionStep(query='None - Steps to perform have to be aligned with PAG first',
                                     server=None,
                                     status=Status.SKIPPED)
        return DecisionExecution(status=DecisionExecution.get_status(steps=[step]), steps=[step])

    def __execute_obsolete(self, ccb_decision: CCBDecision) -> DecisionExecution:
        """
        Executes a decision for "OBSOLETE"
        Steps:
            - Update item field 'Status' to state 'Obsolete' (workflow) in CH63
            - Update "CCB_Decision" field of CH63 item with CCB data
        :param decision: data of ccb decision
        :type decision: Decision
        :return: data for each step that got executed for this decision
        :type DecisionExecution
        """
        steps = []

        # STEP 1 - Update item field 'Status' to state 'Obsolete' (workflow) in CH63
        # prepare step 1
        item_id = ccb_decision.modified_item.item_id_ch63

        step = DecisionExecutionStep(query=f'Set Status of CH63 item "{item_id}" to "Obsolete"',
                                     server=self._cb_server.URL)

        # execute step 1
        step.status, message = self.set_item_to_state(
            item_id=item_id, state_name='Obsolete')

        # if failed, add message to query
        if step.status == Status.FAILED:
            step.query += f' --> Failed due to: "{message}"'

        # append step 1
        steps.append(step)

        # check if previous step was successfull
        if step.status == Status.FAILED:
            return DecisionExecution(status=DecisionExecution.get_status(steps=steps), steps=steps)

        # STEP 2 - Update the CCB_Decision field with corresponding CCB data
        # prepare step 2
        item_id = ccb_decision.modified_item.item_id_ch63
        field_name = 'CCB_Decision'
        field_value = self.__get_ccb_decision_value(ccb_decision.decision,
                                                    participants=ccb_decision.participants,
                                                    rational=ccb_decision.rational)

        step = DecisionExecutionStep(query=f'Update field "{field_name}" of CH63 item "{item_id}"' +
                                     f' with CCB data "{field_value}"',
                                     server=self._cb_server.URL)

        # execute step 2
        step.status, status_msg = self.update_field(item_id=item_id,
                                                    field_name=field_name,
                                                    field_value=field_value)

        # append step 2
        steps.append(step)

        return DecisionExecution(status=DecisionExecution.get_status(steps=steps), steps=steps)

    def __execute_deviate(self, ccb_decision: CCBDecision) -> DecisionExecution:
        """
        Executes a decision for "DEVIATE"
        Steps:
            - Create a copy of SV62 item in Audi instance (NEW_ITEM)
            - Remove all CH63 entries from Module_Variant_pe of NEW_ITEM
            - Remove all SV62 entries from Module_Variant_pe of pre-existing item
            - Update field "CCB_Decision" of pre-existing item with ccb data
        :param decision: data of ccb decision
        :type decision: Decision
        :return: data for each step that got executed for this decision
        :type DecisionExecution
        """
        steps = []

        # STEP 1 - Create a copy of SV62 item in Audi instance (NEW_ITEM)
        # prepare step 1
        item_id_to_copy = ccb_decision.modified_item.item_id_sv62

        step = DecisionExecutionStep(query=f'Create copy of SV62 "{item_id_to_copy}" in CH63',
                                     server=self._cb_server.URL)

        # execute step 1
        step.status, message, new_item_id = self.copy_sv62_item_to_ch63(item_id_to_copy=item_id_to_copy,
                                                                        tracker_id=ccb_decision.modified_item.tracker_id_ch63,
                                                                        reference_item_id=ccb_decision.modified_item.item_id_ch63)

        # append step 1
        steps.append(step)

        # check if previous step was successfull
        if step.status == Status.FAILED:
            step.query += f' --> Failed due to: "{message}"'
            return DecisionExecution(status=DecisionExecution.get_status(steps=steps), steps=steps)
        elif step.status == Status.SUCCESS:
            step.query += f' --> New item id: "{new_item_id}"'

        # STEP 2 - Remove all CH63 entries from Module_Variant_pe of NEW_ITEM
        # execute step 2
        remove_sub_string = 'CH63'
        field_name = 'Module Variant_pe'
        step = DecisionExecutionStep(query=f'Remove {remove_sub_string} from {field_name}' +
                                     f' of item "{new_item_id}" in CH63',
                                     server=self._cb_server.URL)

        step.status, message = self.remove_from_field(item_id=new_item_id,
                                                      field_name=field_name,
                                                      remove_sub_value=remove_sub_string)

        # append step 2
        steps.append(step)

        # if failed, add message to query
        if step.status == Status.FAILED:
            step.query += f' --> Failed due to: "{message}"'

        # STEP 3 - Remove all SV62 entries from Module_Variant_pe of pre-existing item
        # execute step 3
        remove_sub_string = 'SV62'
        field_name = 'Module Variant_pe'
        step = DecisionExecutionStep(query=f'Remove {remove_sub_string} from {field_name}' +
                                     f' of item "{ccb_decision.modified_item.item_id_ch63}" in CH63',
                                     server=self._cb_server.URL)

        step.status, message = self.remove_from_field(item_id=ccb_decision.modified_item.item_id_ch63,
                                                      field_name=field_name,
                                                      remove_sub_value=remove_sub_string)

        # append step 3
        steps.append(step)

        # if failed, add message to query
        if step.status == Status.FAILED:
            step.query += f' --> Failed due to: "{message}"'

        # STEP 4 - Update the CCB_Decision field with corresponding CCB data
        # prepare step 4
        item_id = ccb_decision.modified_item.item_id_ch63
        field_name = 'CCB_Decision'
        field_value = self.__get_ccb_decision_value(ccb_decision.decision,
                                                    participants=ccb_decision.participants,
                                                    rational=ccb_decision.rational)

        step = DecisionExecutionStep(query=f'Update field "{field_name}" of CH63 item "{item_id}"' +
                                     f' with CCB data "{field_value}"',
                                     server=self._cb_server.URL)

        # execute step 4
        step.status, status_msg = self.update_field(item_id=item_id,
                                                    field_name=field_name,
                                                    field_value=field_value)

        # append step 4
        steps.append(step)

        # TODO "Deprecated due to Synergy_pe" in old item?

        return DecisionExecution(status=DecisionExecution.get_status(steps=steps), steps=steps)

def eprint(*args, **kwargs):
    """
    Prints a message to sys.stderr
    """
    print(*args, file=sys.stderr, **kwargs)

def create_mappings():
    df = pd.read_excel(
        'C:/Users/t.schnirpel/Documents/Projekte/CH63/AP_3/Mappings/AttributesMapping.xlsx')

    sv62_to_ch63_mapping = {}

    for row in df.iloc[1:].itertuples(index=True):
        sv62_field_name = getattr(row, f'_{4}')
        ch63_field_name = getattr(row, f'_{3}')
        sv62_to_ch63_mapping[sv62_field_name] = ch63_field_name.replace('#', '') if not pd.isna(
            ch63_field_name) else None

    save_path = Path(
        'C:/Users/t.schnirpel/Documents/Projekte/CH63/AP_3/Mappings/SV62_to_CH63_field_mapping.json')
    if not save_path.parent.exists():
        save_path.parent.mkdir(parents=True, exist_ok=True)

    with open(save_path, "w", encoding='utf8') as file:
        json.dump(sv62_to_ch63_mapping, file, indent=4,
                  sort_keys=False, ensure_ascii=False)

def main():
    parser = argparse.ArgumentParser(description='Execution of CCB actions')
    parser.add_argument('--cb_server', type=str,
                        help='Instance the actions should be performed on (e.g. "Prod", "QS")',
                        default='QS')
    parser.add_argument('--ccb_decisions_file', type=str,
                        help='Path to ccb decision .xlsx file')
    parser.add_argument('--sv62_to_ch63_field_mapping', type=str,
                        help='Path to JSON file containing field mappings from SV62 to CH63')
    parser.add_argument('--execution_state_file', type=str,
                        help='Path to execution state JSON file')
    parser.add_argument('--output_dir', type=str,
                        help='Path to output directory')
    args = parser.parse_args()

    decision_executor = DecisionExecutor(cb_server=args.cb_server,
                                         ccb_decisions_path=Path(
                                             args.ccb_decisions_file),
                                         sv62_to_ch63_field_mapping_path=Path(
                                             args.sv62_to_ch63_field_mapping),
                                         execution_state_path=Path(
                                             args.execution_state_file),
                                         output_dir=Path(args.output_dir))

    decision_executor.execute_decisions()
    decision_executor.execute_new_items_decisions()

if __name__ == '__main__':
    main()
