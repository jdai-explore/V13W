import streamlit.web.cli as stcli
import sys
import os

if __name__ == '__main__':
    # get base path (of streamlit)
    if getattr(sys, 'frozen', False):
        base_path = sys._MEIPASS
    else:
        base_path = os.path.dirname(__file__)

    # prepare paths for app and config
    app_path = os.path.join(base_path, 'app.py')

    # run app with streamlit
    sys.argv = ['streamlit', 'run', app_path,
                '--server.port=8001',
                '--server.headless=true',
                '--global.developmentMode=false',
                ]
    sys.exit(stcli.main())
