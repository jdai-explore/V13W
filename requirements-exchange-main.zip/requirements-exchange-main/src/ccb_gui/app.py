import streamlit as st
import pandas as pd
import os
from datetime import date
import time
from pathlib import Path

################### config tab "new items" ###################
# List of required columns for new items tab
NEW_ITEMS_COLS_MANDATORY = [
    'Summary',
    'Description',
    'Parent.name',
    'Type',
    'Status',
    'Module Variant_pe',
    'BsM-E.D_ct',
    'BsM-E.D comment_ct',
    'BsM-E.L_ct',
    'BsM-E.L comment_ct',
    'BsM-E.T_ct',
    'BsM-E.T comment_ct',
    'BsM-O_ct',
    'BsM-O comment_ct',
    'BsM-Sa.FuSi_ct',
    'BsM-Sa.FuSi comment_ct',
    'Tested by_pe',
    'Verification Environment_ct',
    'Verification Method_ct',
    'Relevance for HW-Module_ct',
    'Relevance for Testing_pe',
    'Functional Safety Classification (according ISO26262)_ct',
    'Owner',
    'Change Request_pe',
    'Foreign ID_ct',
    'Function_ct',
    'Foreign ID Mobileye_pe',
    'Foreign ID_DOORS_pe',
]

# Define constants for column widths
TAB_NEW_SV62_COLUMN_WIDTH = 7
TAB_NEW_CCB_DECISION_COLUMN_WIDTH = 3

# Define constants for font sizes
TAB_NEW_HEADER_FONT_SIZE = 6
TAB_NEW_SUBHEADER_FONT_SIZE = 4

################### config tab "new items" ###################

################### start of GUI ###################

# Configure the page layout
st.set_page_config(
    page_title="APP",
    page_icon="??",
    layout="wide",
    initial_sidebar_state="expanded",
)

if 'last_rerun_time' not in st.session_state:
    st.session_state.last_rerun_time = 0

# Apply CSS styles to increase font size of tab titles
css = '''
<style>
    .stTabs [data-baseweb="tab-list"] button [data-testid="stMarkdownContainer"] p {
    font-size:1.5rem;
    }
    hr.custom-hr {
        margin-top: 0.2rem;
        margin-bottom: 0.2rem;
        bortder: none;
        height: 1px;
        background-color: #0000;
    }
</style>
'''
st.markdown(css, unsafe_allow_html=True)

# Set the date in session state
if 'current_date' not in st.session_state:
    st.session_state.current_date = date.today()

# Create a title for the page
st.title("Change Control Board")

# File uploader
with st.expander('Input Upload', expanded=True):
    uploaded_file = st.file_uploader("Choose an Excel file", type="xlsx")

if uploaded_file is not None:
    st.session_state.uploaded_file = uploaded_file

    # Check if the file already exists
    file_path = f'{st.session_state.current_date}-AutoCCBDecisions_{Path(uploaded_file.name).stem}.xlsx'

    try:
        df = pd.read_excel(uploaded_file)
        # Your existing code to process the uploaded file
    except Exception as e:
        st.write(f"An error occurred: {e}")


# Validate the uploaded file
if uploaded_file:
    # PARTICIPANTS SECTION
    # Create a horizontal line
    st.markdown('<hr class="custom-hr">', unsafe_allow_html=True)

    with st.expander('CCB Information', expanded=True):
        participant_select, participant_data = st.columns([1,4])

        with participant_select:
            # Display the title of the participants section
            st.markdown("<font size=6><b>Participants:</b></font>", unsafe_allow_html=True)

            # Create radio buttons for participants
            participants_option = st.radio("Select Participants", ["CCB Participants", "Audi Participants"], index=0, key="participants_radio")

        with participant_data:
            # Display the selected participant's content
            if participants_option == "Audi Participants":
                audi_participant = st.text_input("Audi Participant",
                                                 placeholder="MANDATORY",
                                                 value=st.session_state.audi_participant_input if 'audi_participant_input' in st.session_state else None,
                                                 key="audi_participant_input_module")
                # save participants to session state
                st.session_state.audi_participant_input = audi_participant

            elif participants_option == "CCB Participants":
                participant_col1, participant_col2, participant_col3 = st.columns([1,1,1])

                with participant_col1:
                    ccb_decision_making_body = st.text_input("CCB Decision-Making Body",
                                                             placeholder="MANDATORY",
                                                             value=st.session_state.ccb_participant_body_input if 'ccb_participant_body_input' in st.session_state else None,
                                                             key="ccb_decision_making_body_input")
                    requester = st.text_input("Requester",
                                              value=st.session_state.ccb_participant_requester_input if 'ccb_participant_requester_input' in st.session_state else None,
                                              key="requester_input")

                with participant_col2:
                    organizer = st.text_input("Organizer",
                                              value=st.session_state.ccb_participant_organizer_input if 'ccb_participant_organizer_input' in st.session_state else None,
                                              key="organizer_input")
                    specifier = st.text_input("Specifier",
                                              value=st.session_state.ccb_participant_specifier_input if 'ccb_participant_specifier_input' in st.session_state else None,
                                              key="specifier_input")

                with participant_col3:
                    moderator = st.text_input("Moderator",
                                              value=st.session_state.ccb_participant_moderator_input if 'ccb_participant_moderator_input' in st.session_state else None,
                                              key="moderator_input")
                    recorder = st.text_input("Recorder",
                                             value=st.session_state.ccb_participant_recorder_input if 'ccb_participant_recorder_input' in st.session_state else None,
                                             key="recorder_input")
                # save participants to session state
                st.session_state.ccb_participant_body_input = ccb_decision_making_body
                st.session_state.ccb_participant_requester_input = requester
                st.session_state.ccb_participant_organizer_input = organizer
                st.session_state.ccb_participant_specifier_input = specifier
                st.session_state.ccb_participant_moderator_input = moderator
                st.session_state.ccb_participant_recorder_input = recorder

    st.markdown('<hr class="custom-hr">', unsafe_allow_html=True)

    # Create an empty line
    st.write("")

    # Display the title of the participants section
    st.markdown("<font size=6><b>Decide on:</b></font>", unsafe_allow_html=True)

    # Create tabs
    tab_changes, tab_new = st.tabs(["Changes", "New Items"])

    # Create a tab for modified_Attributes
    with tab_changes:
        try:
            # Load the Excel file into a DataFrame
            df = pd.read_excel(uploaded_file)

            # Load the Excel file into a DataFrame from Sheet2
            df = pd.read_excel(uploaded_file, sheet_name="modified_attributes")

            # Define required columns
            modified_attributes_required_columns = ['CH63-TrackerName', 'CH63-ItemId', 'CH63-FieldID', 'SV62-TrackerName', 
                                                    'SV62-ItemId', 'SV62-FieldID', 'CH63-FieldName', 'CH63-FieldValue', 
                                                    'SV62-FieldValue']
                            
            # Define constants for column widths
            SYNC_COLUMN_WIDTH = 6
            CCB_COLUMN_WIDTH = 4
            SYNC_COLUMN_WIDTH_PERCENTAGE = 60

            # Define constants for column layout
            COLUMN_LAYOUT = {
                "sync_column": SYNC_COLUMN_WIDTH,
                "ccb_column": CCB_COLUMN_WIDTH
            }

            # Define constants for font sizes
            TAB_NEW_HEADER_FONT_SIZE = 6
            TAB_NEW_SUBHEADER_FONT_SIZE = 4

            # Check if the required columns exist in the DataFrame
            if all(col in df.columns for col in modified_attributes_required_columns):
                # Create two columns with different widths
                sync_col, ccb_col = st.columns([SYNC_COLUMN_WIDTH, CCB_COLUMN_WIDTH])

                # SYNC section (60%)
                with sync_col:
                    # Divide SYNC column into two parts, 50-50
                    col1, col2 = st.columns([3, 3])

                    # Audi-CH63-DAS-PROD-ECUS column
                    with col1:
                        st.markdown('<div style="border: 1px solid black; padding: 5px; width: 100%"><b>Audi-CH63-DAS-PROD-ECUS</b></div>', unsafe_allow_html=True)
                        st.write("")

                        # Tracker Name section
                        st.markdown("<font size=4>Tracker Name</font>", unsafe_allow_html=True)
                        tracker_names = df['CH63-TrackerName'].drop_duplicates().tolist()
                        if 'selected_tracker_name' not in st.session_state:
                            st.session_state.selected_tracker_name = tracker_names[0] if tracker_names else ''
                        selected_tracker_name = st.selectbox("", tracker_names, key="tracker_name", label_visibility="collapsed")
                        
                        # Filter the Item IDs based on the selected Tracker Name
                        item_ids = df[df['CH63-TrackerName'] == selected_tracker_name]['CH63-ItemId'].drop_duplicates().tolist()

                        if 'selected_item_id' not in st.session_state:
                            st.session_state.selected_item_id = ''

                        # Update total_item_ids whenever the tracker name changes
                        if 'previous_tracker_name' not in st.session_state or st.session_state.selected_tracker_name != st.session_state.previous_tracker_name:
                            st.session_state.previous_tracker_name = selected_tracker_name
                            st.session_state.total_item_ids = len(df[df['CH63-TrackerName'] == selected_tracker_name]['CH63-ItemId'].drop_duplicates().tolist())
                            # Reset current_index and selected_item_id when tracker name changes
                            st.session_state.current_index = 0
                            st.session_state.selected_item_id = item_ids[0] if item_ids else ''
                        else:
                            try:
                                st.session_state.previous_item_id = st.session_state.selected_item_id
                            except:
                                pass

                        # Initialize the current index
                        if 'current_index' not in st.session_state:
                            st.session_state.current_index = 0

                        # Get the current Item ID and store it in session state
                        if 'selected_item_id' not in st.session_state or st.session_state.selected_item_id not in item_ids:
                            if item_ids:
                                st.session_state.selected_item_id = item_ids[0]
                                st.session_state.current_index = 0
                            else:
                                st.session_state.selected_item_id = ''
                                st.session_state.current_index = 0
                        else:
                            try:
                                st.session_state.current_index = item_ids.index(st.session_state.selected_item_id)
                            except ValueError:
                                st.session_state.current_index = 0
                                if item_ids:
                                    st.session_state.selected_item_id = item_ids[0]

                        # Create a selectbox for item IDs with the current index
                        st.markdown("<font size=4>Item ID</font>", unsafe_allow_html=True)
                        selected_item_id = st.selectbox("", item_ids, index=min(st.session_state.current_index, len(item_ids) - 1), key="item_id_ecus", label_visibility="collapsed")

                        # Update the index and display it (ADD THIS PART)
                        if 'total_item_ids' not in st.session_state:
                            st.session_state.total_item_ids = len(item_ids)

                        if 'item_id_index' not in st.session_state:
                            st.session_state.item_id_index = 1

                        # Get the current index of the selected item ID 
                        st.session_state.total_item_ids = len(item_ids)
                        st.session_state.item_id_index = item_ids.index(selected_item_id) + 1
                        st.session_state.selected_item_id = selected_item_id
                        st.markdown(f"<div style='float: right; font-size: 18px'>{st.session_state.item_id_index}/{st.session_state.total_item_ids}</div>", unsafe_allow_html=True)

                        # Update total_item_ids whenever the tracker name changes
                        if 'previous_tracker_name' not in st.session_state or st.session_state.selected_tracker_name != st.session_state.previous_tracker_name:
                            st.session_state.previous_tracker_name = selected_tracker_name
                            st.session_state.total_item_ids = len(df[df['CH63-TrackerName'] == selected_tracker_name]['CH63-ItemId'].drop_duplicates().tolist())
                        else:
                            try:
                                st.session_state.previous_item_id = st.session_state.selected_item_id
                            except:
                                pass
                        # Perform action when "Next" is clicked
                        def next_callback(field_name_options, selected_row, selected_item_id):
                            try:
                                current_index = st.session_state.field_name_indices[f"{selected_tracker_name}_{selected_item_id}"]
                                next_index = current_index + 1
                                if next_index < len(field_name_options):
                                    st.session_state.field_name_indices[f"{selected_tracker_name}_{selected_item_id}"] = next_index
                                    st.session_state.selected_field_names[f"{selected_tracker_name}_{selected_item_id}"] = field_name_options[next_index]
                                else:
                                    # Do nothing when the last field name is reached
                                    pass
                            except Exception as e:
                                st.error(f"An error occurred: {e}")

                        # Initialize field_name_index and selected_field_name in session_state if it does not exist
                        if 'field_name_indices' not in st.session_state:
                            st.session_state.field_name_indices = {}
                        if 'selected_field_names' not in st.session_state:
                            st.session_state.selected_field_names = {}

                        # Field Name section
                        st.markdown("<font size=4>Field Name</font>", unsafe_allow_html=True)
                        selected_row = df[df['CH63-ItemId'] == selected_item_id]
                        field_name_options = df[(df['CH63-ItemId'] == selected_item_id) & (df['CH63-TrackerName'] == selected_tracker_name)]['CH63-FieldName'].drop_duplicates().tolist()
                        unique_key = f"field_name_ecus_{selected_item_id}"

                        if not field_name_options:
                            st.session_state.field_name_indices[f"{selected_tracker_name}_{selected_item_id}"] = 0
                            st.session_state.selected_field_names[f"{selected_tracker_name}_{selected_item_id}"] = ''

                        # Get the initial index from session_state, or set to 0 if not existing
                        if f"{selected_tracker_name}_{selected_item_id}" not in st.session_state.field_name_indices:
                            st.session_state.field_name_indices[f"{selected_tracker_name}_{selected_item_id}"] = 0

                            # Get the selected field name from the initial field name options, if not empty
                            initial_selected_field_name = ''
                            if field_name_options:
                                initial_selected_field_name = field_name_options[0]
                                
                            st.session_state.selected_field_names[f"{selected_tracker_name}_{selected_item_id}"] = initial_selected_field_name

                        # Create a selectbox with the selected value as the current index
                        selected_field_name = st.selectbox("", field_name_options, index=st.session_state.field_name_indices[f"{selected_tracker_name}_{selected_item_id}"], key="field_name_ecus", label_visibility="collapsed")

                        if 'selected_field_name' not in st.session_state:
                            st.session_state.selected_field_name = selected_field_name
                        else:
                            st.session_state.selected_field_name = selected_field_name

                        # Update the selected_field_name and field_name_index when a new field name is selected from the dropdown list
                        if selected_field_name != st.session_state.selected_field_names[f"{selected_tracker_name}_{selected_item_id}"]:
                            st.session_state.selected_field_names[f"{selected_tracker_name}_{selected_item_id}"] = selected_field_name
                            st.session_state.field_name_indices[f"{selected_tracker_name}_{selected_item_id}"] = field_name_options.index(selected_field_name)

                        # display the count
                        field_name_index = st.session_state.field_name_indices[f"{selected_tracker_name}_{selected_item_id}"]
                        total_field_names = len(field_name_options)
                        html_template = f"""
                            <div style="float: right; font-size: 18px;">{field_name_index + 1}/{total_field_names}</div>
                        """
                        st.markdown(html_template, unsafe_allow_html=True)

                        # Perform action when "Next" is clicked
                        def next_callback(field_name_options, selected_row, selected_item_id):
                            try:
                                current_index = st.session_state.field_name_indices[f"{selected_tracker_name}_{selected_item_id}"]
                                next_index = current_index + 1
                                if next_index < len(field_name_options):
                                    st.session_state.field_name_indices[f"{selected_tracker_name}_{selected_item_id}"] = next_index
                                    st.session_state.selected_field_names[f"{selected_tracker_name}_{selected_item_id}"] = field_name_options[next_index]
                                else:
                                    # Do nothing when the last field name is reached
                                    pass
                            except Exception as e:
                                st.error(f"An error occurred: {e}")
                        # Add Next button
                        if st.button("Next", on_click=next_callback, args=(field_name_options, selected_row, selected_item_id), key='next'):
                            pass

                    # Porsche-SV62-DAS-PROD-ARGUS-SECU column
                    with col2:
                        st.markdown('<div style="border: 1px solid black; padding: 5px; width: 100%""><b>Porsche-SV62-DAS-PROD-ARGUS-SECU</b></div>', unsafe_allow_html=True)
                        st.write("")

                        # Update values when Item ID and Field Name are selected
                        if selected_tracker_name and selected_item_id and selected_field_name:
                            selected_row = df[(df['CH63-TrackerName'] == selected_tracker_name) & 
                                            (df['CH63-ItemId'] == selected_item_id) & 
                                            (df['CH63-FieldName'] == selected_field_name)].iloc[0]
                            sv62_tracker_name = selected_row['SV62-TrackerName']
                            sv62_item_id = selected_row['SV62-ItemId']
                            sv62_field_name = selected_row['SV62-FieldName']

                            # Tracker Name section
                            st.markdown("<font size=4>Tracker Name</font>", unsafe_allow_html=True)
                            sv62_tracker_name_options = df['SV62-TrackerName'].unique().tolist()
                            sv62_tracker_name_index = sv62_tracker_name_options.index(sv62_tracker_name)
                            sv62_tracker_name_box = st.selectbox("", sv62_tracker_name_options, index=sv62_tracker_name_index, key="sv62_tracker_name", disabled=True, label_visibility="collapsed")
                            
                            # Item ID section
                            st.markdown("<font size=4>Item ID</font>", unsafe_allow_html=True)
                            sv62_item_id_options = df[df['SV62-TrackerName'] == sv62_tracker_name_box]['SV62-ItemId'].unique().tolist()
                            sv62_item_id_index = sv62_item_id_options.index(sv62_item_id)
                            sv62_item_id_box = st.selectbox("", sv62_item_id_options, index=sv62_item_id_index, key="sv62_item_id", disabled=True, label_visibility="collapsed")
                            sv62_item_id_index = sv62_item_id_options.index(sv62_item_id) + 1
                            total_sv62_item_ids = len(sv62_item_id_options)
                            st.markdown(f"<div style='float: right; font-size: 18px'>{sv62_item_id_index}/{total_sv62_item_ids}</div>", unsafe_allow_html=True)          

                            # Field Name section
                            st.markdown("<font size=4>Field Name</font>", unsafe_allow_html=True)
                            sv62_field_name_options = df[(df['SV62-TrackerName'] == sv62_tracker_name_box) & 
                                                        (df['SV62-ItemId'] == sv62_item_id_box)]['SV62-FieldName'].unique().tolist()
                            sv62_field_name_index = sv62_field_name_options.index(sv62_field_name)
                            sv62_field_name_box = st.selectbox("", sv62_field_name_options, index=sv62_field_name_index, key="sv62_field_name", disabled=True, label_visibility="collapsed")
                            sv62_field_name_index = sv62_field_name_options.index(sv62_field_name_box) + 1
                            total_sv62_field_names = len(sv62_field_name_options)
                            st.markdown(f"<div style='float: right; font-size: 18px'>{sv62_field_name_index}/{total_sv62_field_names}</div>", unsafe_allow_html=True)

                    # Create a synchronized column to display content in a structured format
                    with sync_col:
                        st.write("")
                        if selected_item_id and selected_field_name:
                            selected_row = df[(df['CH63-ItemId'] == selected_item_id) & (df['CH63-FieldName'] == selected_field_name)].iloc[0]
                        
                            col1, col2 = st.columns([1, 1])
                            with col1:
                                st.markdown('<div style="border: 1px solid black; border-radius: 50px; padding: 5px; width: 80%; text-align: center;"><b>Field Value</b></div>', unsafe_allow_html=True)
                                st.markdown(f"<div style='border: 1px solid black; border-radius: 50px; padding: 5px; width: 80%; text-align: center; display: inline-block; background-color: #C9E4CA; color: #000000'>{selected_row['CH63-FieldValue']}</div>", unsafe_allow_html=True)
                                st.markdown(f"<a href='https://cb.vwgroup.com/cb/issue/{selected_item_id}'>https://cb.vwgroup.com/cb/issue/{selected_item_id}</a>", unsafe_allow_html=True)
                            with col2:
                                st.markdown('<div style="border: 1px solid black; border-radius: 50px; padding: 5px; width: 80%; text-align: center;"><b>Field Value</b></div>', unsafe_allow_html=True)
                                st.markdown(f"<div style='border: 1px solid black; border-radius: 50px; padding: 5px; width: 80%; text-align: center; display: inline-block; background-color: #C9E4CA; color: #000000'>{selected_row['SV62-FieldValue']}</div>", unsafe_allow_html=True)
                                sv62_item_id = selected_row['SV62-ItemId']
                                st.markdown(f"<a href='https://cb.vwgroup.com/cb/issue/{sv62_item_id}'>https://cb.vwgroup.com/cb/issue/{sv62_item_id}</a>", unsafe_allow_html=True)

                            st.markdown('<hr class="custom-hr">', unsafe_allow_html=True)

                        # Add Next and Previous buttons
                            cols = st.columns([5, 1, 1])
                            cols[0].empty()
                            with cols[1]:
                                def previous_callback():
                                    if st.session_state.current_index > 0:
                                        st.session_state.current_index -= 1
                                    st.session_state.selected_item_id = item_ids[st.session_state.current_index]
                                    st.session_state.field_name_index = 0  # Reset field_name_index to 0
                                    updated_tracker_name = df.loc[df['CH63-ItemId'] == st.session_state.selected_item_id, 'CH63-TrackerName'].values[0]
                                    tracker_name_options = df['CH63-TrackerName'].unique().tolist()
                                    st.session_state.selected_tracker_name = updated_tracker_name
                                    st.session_state.previous_tracker_name_index = tracker_name_options.index(updated_tracker_name)

                                if st.button("Previous", on_click=previous_callback):
                                    pass
                            with cols[2]:
                                def next_callback():
                                    if st.session_state.current_index < len(item_ids) - 1:
                                        st.session_state.current_index += 1
                                    st.session_state.selected_item_id = item_ids[st.session_state.current_index]
                                    st.session_state.field_name_index = 0  # Reset field_name_index to 0
                                    updated_tracker_name = df.loc[df['CH63-ItemId'] == st.session_state.selected_item_id, 'CH63-TrackerName'].values[0]
                                    tracker_name_options = df['CH63-TrackerName'].unique().tolist()
                                    st.session_state.selected_tracker_name = updated_tracker_name
                                    st.session_state.previous_tracker_name_index = tracker_name_options.index(updated_tracker_name)

                                if st.button("Next", on_click=next_callback):
                                    pass

                            if os.path.isfile(file_path):
                                excel_file = pd.ExcelFile(file_path)
                                if 'ccb_decision' in excel_file.sheet_names:
                                    existing_df = pd.read_excel(file_path, sheet_name='chages_in_system')
                                    if not existing_df.empty:
                                        last_row = existing_df.tail(1)  
                                        st.session_state.total_updated_fields = len(existing_df)
                                        st.session_state.last_record_tracker_name = last_row['CH63-TrackerName'].values[0]
                                        st.session_state.last_record_item_id = last_row['CH63-ItemId'].values[0]
                                        st.session_state.last_record_field_name = last_row['CH63-FieldName'].values[0]
                                        st.session_state.last_record_porsche_tracker_name = last_row['SV62-TrackerName'].values[0]
                                        st.session_state.last_record_porsche_item_id = last_row['SV62-ItemId'].values[0]
                                        st.session_state.last_record_porsche_field_name = last_row['SV62-FieldID'].values[0]
                                        st.session_state.last_record_decision = last_row['CCB Decision'].values[0]
                                        st.session_state.last_record_rational_notes = last_row['CCB Rational'].values[0]
                                # Display recorded fields below Next and Previous buttons
                                if 'last_record_tracker_name' in st.session_state:
                                    st.write(f"<font size='5'>Total fields updated: {st.session_state.total_updated_fields}/{len(df)}</font>", unsafe_allow_html=True)
                                    st.write(f"<center><font size='6'><b>Latest Update</b></font></center>", unsafe_allow_html=True)
                                    st.write(f"<center><font size='5'><b>Audi-CH63-DAS-PROD-ECUS:</b></font></center>", unsafe_allow_html=True)
                                    st.write(f"<center><font size='4'><b>Tracker Name:</b> {st.session_state.last_record_tracker_name}</font></center>", unsafe_allow_html=True)
                                    st.write(f"<center><font size='4'><b>Item ID:</b> {st.session_state.last_record_item_id}</font></center>", unsafe_allow_html=True)
                                    st.write(f"<center><font size='4'><b>Field Name:</b> {st.session_state.last_record_field_name}</font></center>", unsafe_allow_html=True)

                                    # Porsche-SV62-DAS-PROD-ARGUS-SECU details
                                    st.write(f"<center><font size='5'><b>Porsche-SV62-DAS-PROD-ARGUS-SECU:</b></font></center>", unsafe_allow_html=True)
                                    st.write(f"<center><font size='4'><b>Tracker Name:</b> {st.session_state.last_record_porsche_tracker_name}</font></center>", unsafe_allow_html=True)
                                    st.write(f"<center><font size='4'><b>Item ID:</b> {st.session_state.last_record_porsche_item_id}</font></center>", unsafe_allow_html=True)
                                    st.write(f"<center><font size='4'><b>Field Name:</b> {st.session_state.last_record_porsche_field_name}</font></center>", unsafe_allow_html=True)

                                    # CCB Decision and Rational Notes
                                    st.write(f"<center><font size='4'><b>Decision:</b> {st.session_state.last_record_decision}</font></center>", unsafe_allow_html=True)
                                    st.write(f"<center><font size='4'><b>Rational Notes:</b> {st.session_state.last_record_rational_notes}</font></center>", unsafe_allow_html=True)
            
                # Change Control Board section (40%)
                ccb_refresh = st.session_state.get('ccb_refresh', False)
                
                with ccb_col:
                    st.markdown("<font size=6><b>Change Control Board</b></font>", unsafe_allow_html=True)
                    st.markdown('<hr class="custom-hr">', unsafe_allow_html=True)

                    # Add a "Decision" input field after the "Participants" section
                    st.markdown("<font size=6><b>Decision (Mandatory field)</b></font>", unsafe_allow_html=True)

                    # Sync selections
                    ccb_sync_status = {}

                    # Sync with Porsche Database
                    col1, col2 = st.columns([4, 1])
                    with col1:
                        st.markdown("<font size=4>Sync with Porsche Database</font>", unsafe_allow_html=True)
                    with col2:
                        ccb_sync_status['sync_das_prod_argus_secu_approval'] = st.checkbox("", key='sync_das_prod_argus_secu_approval_checkbox')

                    # Sync with Audi Database
                    col1, col2 = st.columns([4, 1])
                    with col1:
                        st.markdown("<font size=4>Sync with Audi Database</font>", unsafe_allow_html=True)
                    with col2:
                        ccb_sync_status['sync_das_prod_ecus_approval'] = st.checkbox("", key='sync_das_prod_ecus_approval_checkbox')

                    # Audi to deviate current requirement and create a new requirement
                    col1, col2 = st.columns([4, 1])
                    with col1:
                        st.markdown("<font size=4>Audi to deviate current requirement and create a new requirement</font>", unsafe_allow_html=True)
                    with col2:
                        ccb_sync_status['audi_deviate_current_requirement_approval'] = st.checkbox("", key='audi_deviate_current_requirement_approval_checkbox')

                    # Mark entire requirement as Obsolete
                    col1, col2 = st.columns([4, 1])
                    with col1:
                        st.markdown("<font size=4>Mark entire requirement as Obsolete</font>", unsafe_allow_html=True)
                    with col2:
                        ccb_sync_status['mark_entire_requirement_as_obsolete_approval'] = st.checkbox("", key='mark_entire_requirement_as_obsolete_approval_checkbox')

                    # Rational Notes section
                    st.markdown("<font size=6><b>**Rational/Notes**</b></font>",unsafe_allow_html=True)
                    rational_notes = st.text_area("", height=100, value="", key="rational_notes")
                    
                    # Record CCB Decision
                    cols = st.columns([1, 1])

                    css = """
                        <style>
                            .stButton > button {
                                background-color: #ADD8E6;  
                                color: #000;
                                border: 1px solid #87CEEB;
                                border-radius: 0.25rem;
                                padding: 0.3rem 0.5rem;
                            }
                        </style>
                    """

                    st.markdown(css, unsafe_allow_html=True)

                    with cols[0]:
                        def record_ccb_decision_callback():
                            pass

                        record_ccb_decision = st.button("Record CCB Decision", on_click=record_ccb_decision_callback)

                    with cols[1]:
                        def process_completed_callback():
                            pass

                        process_completed = st.button("Process Completed", on_click=process_completed_callback)

                    if 'rerun_once' not in st.session_state:
                        st.session_state.rerun_once = False
                    if record_ccb_decision:
                        if len([option for option in ccb_sync_status.values() if option]) == 1:
                            if participants_option == "CCB Participants":
                                if not ccb_decision_making_body.strip():
                                    st.error("Please update the CCB Decision-Making Body.")
                                elif participants_option == "CCB Participants":
                                    selected_row = df[(df['CH63-TrackerName'] == selected_tracker_name) & 
                                                    (df['CH63-ItemId'] == st.session_state.selected_item_id) & 
                                                    (df['CH63-FieldName'] == st.session_state.selected_field_name)].iloc[0]
                                    new_row = {}
                                    for col in df.columns:
                                        new_row[col] = selected_row[col]
                                    sync_decisions = []
                                    if ccb_sync_status['sync_das_prod_argus_secu_approval']:
                                        sync_decisions.append("Sync with Porsche Database")
                                    if ccb_sync_status['sync_das_prod_ecus_approval']:
                                        sync_decisions.append("Sync with Audi Database")
                                    if ccb_sync_status['audi_deviate_current_requirement_approval']:
                                        sync_decisions.append("Audi to deviate current requirement and create a new requirement")
                                    if ccb_sync_status['mark_entire_requirement_as_obsolete_approval']:
                                        sync_decisions.append("Mark entire requirement as Obsolete")
                                    if sync_decisions:
                                        new_row['CCB Decision'] = ", ".join(sync_decisions)
                                        ccb_participants = ""
                                        if organizer:
                                            ccb_participants += f"Organizer: {organizer}"
                                        if specifier and ccb_participants:
                                            ccb_participants += f", Specifier: {specifier}"
                                        elif specifier:
                                            ccb_participants += f"Specifier: {specifier}"
                                        if requester and ccb_participants:
                                            ccb_participants += f", Requester: {requester}"
                                        elif requester:
                                            ccb_participants += f"Requester: {requester}"
                                        if ccb_decision_making_body and ccb_participants:
                                            ccb_participants += f", CCB Decision-Making Body: {ccb_decision_making_body}"
                                        elif ccb_decision_making_body:
                                            ccb_participants += f"CCB Decision-Making Body: {ccb_decision_making_body}"
                                        if moderator and ccb_participants:
                                            ccb_participants += f", Moderator: {moderator}"
                                        elif moderator:
                                            ccb_participants += f"Moderator: {moderator}"
                                        if recorder and ccb_participants:
                                            ccb_participants += f", Recorder: {recorder}"
                                        elif recorder:
                                            ccb_participants += f"Recorder: {recorder}"
                                        new_row['CCB Participants'] = ccb_participants
                                        new_row['CCB Rational'] = st.session_state.rational_notes
                                    new_row_df = pd.DataFrame([new_row])    
                                    if not os.path.isfile(file_path):
                                        # If the file does not exist, create it with the new row
                                        new_row_df.to_excel(file_path, sheet_name='changes_in_system', index=False)
                                        st.success("CCB Decision recorded successfully.")
                                        time.sleep(0.6)
                                        st.session_state.rerun_once = True
                                    else:
                                        try:
                                            existing_df = pd.read_excel(file_path, sheet_name='changes_in_system')
                                        except ValueError:
                                            existing_df = pd.DataFrame(columns=new_row_df.columns)

                                        # Check for existing rows with the same tracker name, item ID, and field name
                                        existing_row = existing_df[(existing_df['CH63-TrackerName'] == selected_tracker_name) & 
                                                                (existing_df['CH63-ItemId'] == st.session_state.selected_item_id) & 
                                                                (existing_df['CH63-FieldName'] == st.session_state.selected_field_name)]
                                        
                                        if existing_row.empty:
                                            # If no row exists, add a new row
                                            existing_df = pd.concat([existing_df, new_row_df])
                                            
                                            with pd.ExcelWriter(file_path, engine='openpyxl', mode='a', if_sheet_exists='overlay') as writer:
                                                existing_df.to_excel(writer, sheet_name='changes_in_system', index=False)
                                            st.success("CCB Decision recorded successfully.")
                                            time.sleep(0.6)
                                            st.session_state.rerun_once = True
                                        else:
                                            # If a row already exists, do not update the values
                                            st.error("Values already updated.")
                                            time.sleep(0.6)
                                            st.session_state.rerun_once = True
                            
                            elif participants_option == "Audi Participants":
                                if record_ccb_decision:
                                    audi_participant_key = st.session_state.get("audi_participant_key", 0)
                                    audi_participant_key += 1
                                    st.session_state.audi_participant_key = audi_participant_key
                                    if not audi_participant.strip():
                                        st.error("Please enter the Audi Participant names.")
                                        record_ccb_decision_callback = None
                                    else:
                                        selected_row = df[(df['CH63-TrackerName'] == selected_tracker_name) & 
                                                    (df['CH63-ItemId'] == st.session_state.selected_item_id) & 
                                                    (df['CH63-FieldName'] == st.session_state.selected_field_name)].iloc[0]
                                        new_row = {}
                                        for col in df.columns:
                                            new_row[col] = selected_row[col]
                                        new_row['CCB Participants'] = f"Audi Participant: {st.session_state.audi_participant_input}"
                                        new_row['CCB Rational'] = rational_notes
                                        sync_decisions = []
                                        if ccb_sync_status['sync_das_prod_argus_secu_approval']:
                                            sync_decisions.append("Sync with Porsche Database")
                                        if ccb_sync_status['sync_das_prod_ecus_approval']:
                                            sync_decisions.append("Sync with Audi Database")
                                        if ccb_sync_status['audi_deviate_current_requirement_approval']:
                                            sync_decisions.append("Audi to deviate current requirement and create a new requirement")
                                        if ccb_sync_status['mark_entire_requirement_as_obsolete_approval']:
                                            sync_decisions.append("Mark entire requirement as Obsolete")
                                        if sync_decisions:
                                            new_row['CCB Decision'] = ", ".join(sync_decisions)
                                        new_row_df = pd.DataFrame([new_row])
                                        if not os.path.isfile(file_path):
                                            # If the file does not exist, create it with the new row
                                            new_row_df.to_excel(file_path, sheet_name='changes_in_system', index=False)
                                            st.success("CCB Decision recorded successfully.")
                                            time.sleep(0.6)
                                            st.session_state.rerun_once = True
                                        else:
                                            try:
                                                existing_df = pd.read_excel(file_path, sheet_name='changes_in_system')
                                            except ValueError:
                                                existing_df = pd.DataFrame(columns=new_row_df.columns)

                                            # Check for existing rows with the same tracker name, item ID, and field name
                                            existing_row = existing_df[(existing_df['CH63-TrackerName'] == selected_tracker_name) & 
                                                                    (existing_df['CH63-ItemId'] == st.session_state.selected_item_id) & 
                                                                    (existing_df['CH63-FieldName'] == st.session_state.selected_field_name)]
                                            
                                            if existing_row.empty:
                                                # If no row exists, add a new row
                                                existing_df = pd.concat([existing_df, new_row_df])
                                                with pd.ExcelWriter(file_path, engine='openpyxl', mode='a', if_sheet_exists='overlay') as writer:
                                                    existing_df.to_excel(writer, sheet_name='changes_in_system', index=False)
                                                st.success("CCB Decision recorded successfully.")
                                                time.sleep(0.6)
                                                st.session_state.rerun_once = True
                                            else:
                                                # If a row already exists, do not update the values
                                                st.error("Values already updated.")
                                                time.sleep(0.6)
                                                st.session_state.rerun_once = True
                        else:
                            st.error("Please select one option.")  
                    if 'rerun_once' in st.session_state and st.session_state.rerun_once:
                        st.session_state.rerun_once = False
                        st.experimental_rerun()

            else:
                st.write("Error: The uploaded file does not contain all the required columns.")
        except Exception as e:
            st.write(f"An error occurred: {e}") 

    # Create a tab for new_items
    with tab_new:
        # Load the Excel file into a DataFrame
        df_SV62 = pd.read_excel(uploaded_file, sheet_name="EMPTY_SV62")

        # Load the updated item IDs from the Excel sheet
        try:
            updated_item_ids = pd.read_excel(file_path, sheet_name='new_items')['ID'].tolist()
        except FileNotFoundError:
            updated_item_ids = []

        # Create tracker item map
        st.session_state.tab_new_tracker_item_map = {tracker_name: [item_id for item_id in df_SV62[df_SV62['Tracker.name'] == tracker_name]['ID'].to_list()
                                                                    if item_id not in updated_item_ids]
                                                                    for tracker_name in df_SV62['Tracker.name'].unique().tolist()}
        # Remove empty trackers
        st.session_state.tab_new_tracker_item_map = {key: value for key, value in st.session_state.tab_new_tracker_item_map.items() if value}

        # Check if there are new items
        if st.session_state.tab_new_tracker_item_map:
            # Generate/update session state for tracker index
            if 'tab_new_tracker_index' not in st.session_state:
                st.session_state.tab_new_tracker_index = 0
            if st.session_state.tab_new_tracker_index >= len(st.session_state.tab_new_tracker_item_map):
                if len(st.session_state.tab_new_tracker_item_map) > 0:
                    st.session_state.tab_new_tracker_index = 0
                else:
                    st.session_state.tab_new_tracker_index = None

            # Generate/update session state for tracker name
            if 'tab_new_cur_tracker_name' not in st.session_state:
                st.session_state.tab_new_cur_tracker_name = ''
            if st.session_state.tab_new_tracker_index is not None:
                st.session_state.tab_new_cur_tracker_name = list(st.session_state.tab_new_tracker_item_map.keys())[st.session_state.tab_new_tracker_index]
            else:
                st.session_state.tab_new_cur_tracker_name = None

            # Generate/update session state for item index
            if 'tab_new_item_index' not in st.session_state:
                st.session_state.tab_new_item_index = 0
            if st.session_state.tab_new_tracker_index is None or st.session_state.tab_new_cur_tracker_name is None:
                st.session_state.tab_new_item_index = None
            elif st.session_state.tab_new_item_index is None and st.session_state.tab_new_tracker_index is not None and st.session_state.tab_new_cur_tracker_name is not None:
                st.session_state.tab_new_item_index = 0
            elif st.session_state.tab_new_cur_tracker_name in st.session_state.tab_new_tracker_item_map:
                if st.session_state.tab_new_item_index >= len(st.session_state.tab_new_tracker_item_map[st.session_state.tab_new_cur_tracker_name]):
                    st.session_state.tab_new_item_index = 0

            # Reset trackers if needed
            if st.session_state.tab_new_cur_tracker_name not in st.session_state.tab_new_tracker_item_map:
                if len(st.session_state.tab_new_tracker_item_map) > 0:
                    st.session_state.tab_new_tracker_index = 0
                    st.session_state.tab_new_cur_tracker_name = next(iter(st.session_state.tab_new_cur_tracker_name))
                    st.session_state.tab_new_item_index = 0

            # Filter out the updated item IDs from the select box options
            item_ids = [item for item in df_SV62['ID'].tolist() if item not in updated_item_ids]
            tracker_names = st.session_state.tab_new_tracker_item_map.keys()

            # Create two columns with different widths
            data_col, ccb_decision_col = st.columns([TAB_NEW_SV62_COLUMN_WIDTH, TAB_NEW_CCB_DECISION_COLUMN_WIDTH])

            with data_col:
                # Create columns for instance
                instance_name_col, instance_select_col, _ = st.columns([2,16,3])

                with instance_name_col:
                    # Instance Name section
                    st.markdown("<font size=4><b>Instance:</b></font>", unsafe_allow_html=True)

                with instance_select_col:
                    instance_name_box = st.selectbox("", options=['DAS-PROD-ARGUS-SECU'], index=0, disabled=True, label_visibility="collapsed")

                # Create selection columns
                title_col, selection_box_col, button_col = st.columns([2,16,3])

                with title_col:
                    # Tracker Name section
                    st.markdown("<font size=4><b>Tracker:</b></font>", unsafe_allow_html=True)

                    # Item ID section
                    st.markdown("<font size=4><b>ID:</b></font>", unsafe_allow_html=True)

                with selection_box_col:
                    # Create a selectbox to display the tracker options
                    tracker_name_box = st.selectbox("", tracker_names, index=st.session_state.tab_new_tracker_index, label_visibility="collapsed")
                    st.session_state.tab_new_cur_tracker_name = tracker_name_box

                    if st.session_state.tab_new_tracker_item_map[st.session_state.tab_new_cur_tracker_name]:
                        item_id_box = st.selectbox("", st.session_state.tab_new_tracker_item_map[st.session_state.tab_new_cur_tracker_name], index=st.session_state.tab_new_item_index, label_visibility="collapsed")
                        # Store the item_id_box value in session state
                        st.session_state.cur_item_id = item_id_box
                    else:
                        st.session_state.cur_item_id = None
                        st.write("No Item ID available")

                with button_col:
                    # Define a callback function to update the tracker index
                    def next_tracker_callback():
                        # Check if the current tracker is the last one
                        if st.session_state.tab_new_tracker_index < len(tracker_names):
                            # Update the tracker index in session state
                            st.session_state.tab_new_tracker_index = (st.session_state.tab_new_tracker_index + 1) % len(tracker_names)

                            # Reset the item index to 0
                            st.session_state.tab_new_item_index = 0

                    # Create a button to move to the next tracker
                    next_tracker_button = st.button("Next Tracker", on_click=next_tracker_callback, key="next_tracker_button")

                    def next_item_callback():
                        # Update the item index in session state
                        if 'tab_new_item_index' in st.session_state:
                            if st.session_state.tab_new_item_index < len(st.session_state.tab_new_tracker_item_map[st.session_state.tab_new_cur_tracker_name]):
                                st.session_state.tab_new_item_index += 1
                                # Make sure the index is within the valid range
                                st.session_state.tab_new_item_index = st.session_state.tab_new_item_index % len(st.session_state.tab_new_tracker_item_map[st.session_state.tab_new_cur_tracker_name])
                        else:
                            # item id was not safed yet but there are items for current tracker
                            if st.session_state.tab_new_tracker_item_map[st.session_state.tab_new_cur_tracker_name]:
                                st.session_state.tab_new_item_index = 0
                            else: # no item in tracker and no index safed
                                st.write("No items available")

                    next_item_button = st.button("Next Item", on_click=next_item_callback, key="next_item_button")

                if st.session_state.cur_item_id is not None:
                    # filter for current item id
                    item_df = df_SV62[df_SV62['ID'] == st.session_state.cur_item_id]

                    # fill None with codebeamer '--'
                    item_df = item_df.fillna('--')

                    # split data into mandatory and optional
                    item_df_mandatory = item_df[NEW_ITEMS_COLS_MANDATORY]
                    item_df_optional = item_df.drop(columns=NEW_ITEMS_COLS_MANDATORY)

                    # rename columns for better presentation
                    item_df_mandatory.columns = [col.replace('.name', ' Name').replace('.id', ' ID').replace('.type', ' Type') for col in item_df_mandatory.columns]

                    # transpose dataframe
                    item_df_mandatory = item_df_mandatory.T

                    # rename columns in transposed dataframe e.g. index, rows
                    item_df_mandatory.columns = ['Field Value']

                    item_df_mandatory = item_df_mandatory.style.set_table_styles(
                        [
                            {'selector': 'td',
                            'props': [('white-space', 'pre-wrap'),
                                    ('word-break', 'break-word'),
                                    ('max-width', '90%')]}
                        ]
                    )

                    st.write(item_df_mandatory.to_html(header=False), unsafe_allow_html=True)

                    with st.expander('Additional information'):
                        # rename columns for better presentation
                        item_df_optional.columns = [col.replace('.name', ' Name').replace('.id', ' ID').replace('.type', ' Type') for col in item_df_optional.columns]

                        # transpose dataframe
                        item_df_optional = item_df_optional.T

                        # rename columns in transposed dataframe e.g. index, rows
                        item_df_optional.columns = ['Field Value']

                        item_df_optional = item_df_optional.style.set_table_styles(
                                            [
                                                {'selector': 'td',
                                                'props': [('white-space', 'pre-wrap'),
                                                        ('word-break', 'break-word'),
                                                        ('max-width', '90%')]}
                                            ])

                        st.write(item_df_optional.to_html(header=False), unsafe_allow_html=True)


            # Create a column for the Change Control Board module
            with ccb_decision_col:
                # Display the title of the decision section
                st.markdown("<font size=6><b>Decision</b></font>", unsafe_allow_html=True)

                # Create a list of module Variant_pe decisions
                st.markdown("<font size=5><b>Module Variant_pe (MANDATORY)</b></font>", unsafe_allow_html=True)
                selected_decisions = st.multiselect("",
                                                    options=["Take over from other instance",
                                                            "None",
                                                            "HCP2.low",
                                                            "HCP2.TV",
                                                            "SV62-1Box",
                                                            "SV62-2Box",
                                                            "CH63_Main",
                                                            "CH63_Fallback",
                                                            "SDV0.1_ADAS_Basic",
                                                            "SDV0.1_ADAS_Basic_Entry",
                                                            "SDV0.1_Surveillance"],
                                                    label_visibility='collapsed',
                                                    key='multiselect_module_variants',
                                                    placeholder='Chose at least one option (MANDATORY)')

                # Create option to input destination of new item
                st.markdown("<font size=5><b>Destination</b></font>", unsafe_allow_html=True)
                destination_type = st.selectbox("Type",
                                                options=['Last item (Top Level)', 'Predecessor', 'Successor', 'Parent'],
                                                key="tab_new_item_destination_type",
                                                help=('Last item (Top Level) = Adds item on top level (needs to be moved to correct place by you) / ' +
                                                f'Predecessor = Adds item AFTER provided item id / '+
                                                f'Successor = Adds item BEFORE provided item id / '+
                                                f'Parent = Adds item as last child of provided item id'))

                if destination_type != 'Last item (Top Level)':
                    destionation_item_id = st.number_input("Reference Item ID (MANDATORY)",
                                                        format='%d',
                                                        step=1,
                                                        value=None,
                                                        placeholder='MANDATORY',
                                                        key='number_input_destination_item_id',
                                                        help='e.g. for https://cb.vwgroup.com/cb/issue/39339702 provide 39339702')
                else:
                    destionation_item_id = st.number_input("Reference Tracker ID (MANDATORY)",
                                                        format='%d',
                                                        step=1,
                                                        value=None,
                                                        placeholder='MANDATORY',
                                                        key='number_input_destination_item_id',
                                                        help='e.g. for https://cb.vwgroup.com/cb/tracker/92348129 provide 92348129')

                # Create a text area for rational notes
                st.markdown("<font size=5><b>Comment / Reason</b></font>", unsafe_allow_html=True)
                rational_notes = st.text_area("", height=70, value="", key="tab_new_rational_notes", label_visibility='collapsed', placeholder='Type your comment / reason here ...', help='This comment will be added to the added item')

                def record_decision_callback():
                    # counter for errors
                    error_cnt = 0

                    # Check if the participants option is CCB Participants
                    participants = ""
                    if participants_option == "CCB Participants":
                        # Check if the CCB decision-making body is empty
                        if ccb_decision_making_body is None or not ccb_decision_making_body.strip():
                            ccb_decision_col.error("ERROR: Please update the CCB Decision-Making Body field.")
                            error_cnt += 1

                        if organizer:
                            participants += f"Organizer: {organizer}"
                        if specifier:
                            participants += f"{', ' if participants else ''}Specifier: {specifier}"
                        if requester:
                            participants += f"{', ' if participants else ''}Requester: {requester}"
                        if ccb_decision_making_body:
                            participants += f"{', ' if participants else ''}CCB Decision-Making Body: {ccb_decision_making_body}"
                        if moderator:
                            participants += f"{', ' if participants else ''}Moderator: {moderator}"
                        if recorder:
                            participants += f"{', ' if participants else ''}Recorder: {recorder}"
                    elif participants_option == "Audi Participants":
                        # Check if the CCB decision-making body is empty
                        if audi_participant is None:
                            ccb_decision_col.error("ERROR: Please update the Audi Participant field.")
                        participants = f'Audi Participant: {audi_participant}'

                    # Check if at least one module variant is selected
                    if len(selected_decisions) == 0:
                        ccb_decision_col.error("ERROR: Please select at least one Module Variant_pe.")
                        error_cnt += 1

                    # Check if at least one decision is selected
                    if destionation_item_id is None:
                        ccb_decision_col.error("ERROR: Please provide destination reference.")
                        error_cnt += 1

                    # when all checks passed
                    if error_cnt <= 0:
                        # Get the selected row from the dataframe
                        selected_row = df_SV62[(df_SV62['Tracker.name'] == st.session_state.tab_new_cur_tracker_name) &
                                                (df_SV62['Foreign ID_DOORS_pe'].isna()) &
                                                (df_SV62['ID'] == st.session_state.cur_item_id)].iloc[0].to_dict()

                        new_decision = {}

                        # Update the new row with the CCB decision and participants
                        new_decision['CCB Decision'] = 'module_variant=' + ", ".join(selected_decisions) + f';destination_type={destination_type};destination_reference={destionation_item_id}'

                        new_decision['CCB Participants'] = participants
                        new_decision['CCB Rational'] = rational_notes

                        # merge ccb decision data with new item data
                        new_decision = {**new_decision, **selected_row}

                        # Create a new dataframe with the new row
                        new_decision_df = pd.DataFrame([new_decision])

                        # Check if the file exists
                        if not os.path.isfile(file_path):
                            # If the file does not exist, create it with the new row
                            try:
                                new_decision_df.to_excel(file_path, sheet_name='new_items', index=False)
                                ccb_decision_col.success("CCB Decision recorded successfully.")
                                time.sleep(0.6)
                            except:
                                ccb_decision_col.error("Could not write to output file. Please close it if its open.")
                                error_cnt +=1
                        else:
                            # Read the existing dataframe from the file
                            existing_df_sv62 = pd.read_excel(file_path, sheet_name='new_items')

                            # Check for existing rows with the same tracker name, item ID, and field name
                            existing_row_sv62 = existing_df_sv62[(existing_df_sv62['Tracker.name'] == st.session_state.tab_new_cur_tracker_name) &
                                                                (existing_df_sv62['ID']== st.session_state.cur_item_id)]

                            if existing_row_sv62.empty:
                                # If no row exists, add a new row
                                existing_df_sv62 = pd.concat([existing_df_sv62, new_decision_df])

                                try:
                                    # write to disk
                                    with pd.ExcelWriter(file_path, engine='openpyxl', mode='a', if_sheet_exists='overlay') as writer:
                                        existing_df_sv62.to_excel(writer, sheet_name='new_items', index=False)
                                                                    # confirm that decision was recorded to user
                                    ccb_decision_col.success("CCB Decision recorded successfully.")
                                    time.sleep(0.6)
                                except:
                                    ccb_decision_col.error(f"Could not write to output file {file_path}. Please close it if its open.")
                                    error_cnt +=1
                            else:
                                # If a row already exists, do not update the values
                                ccb_decision_col.error("Values already updated.")
                                time.sleep(0.6)

                    if error_cnt <= 0:
                        # reset inputs after successfull decision
                        st.session_state.number_input_destination_item_id = None
                        st.session_state.multiselect_module_variants = []
                        st.session_state.tab_new_rational_notes = None

                # rerun GUI
                st.session_state.rerun_once = True
                record_ccb_decision_button = st.button("Record CCB Decision", on_click=record_decision_callback, key="record_ccb_decision_button")
        else:
            tab_new.info('There are no new items in prodivded input file')
else:
    st.info("Please upload an Excel input file.")
