from dataclasses import dataclass, fields
from enum import Enum
from src.rep_dataclasses.modified_item import ModifiedItem
import pandas as pd


CCB_DECISION_FIELD_MAPPING = {
    'decision': 'CCB Decision',
    'participants': 'CCB Participants',
    'rational': 'CCB Rational',
    'modified_item': 'CCB_DECISION_FIELD_MAPPING_DEFAULT'
}


class Decision(Enum):
    SV62_TO_CH63 = 'Sync with Porsche Database'
    CH63_TO_SV62 = 'Sync with Audi-CH63-DAS-PROD-ECUS'
    OBSOLETE = 'Mark entire requirement as Obsolete'
    DEVIATE = 'Audi to deviate current requirement and create a new requirement'


DECISION_MAPPING = {d.value: d for d in Decision}


@dataclass
class CCBDecision:
    modified_item: ModifiedItem
    decision: Decision
    participants: dict
    rational: str

    @classmethod
    def from_series(cls, series: pd.Series):
        """
        Creates an instance of the dataclass from a pandas Series.

        Parameters:
        - series (pd.Series): The Series containing the data.

        Returns:
        - An instance of the dataclass.
        """
        # Create a dictionary of values by matching Series index to dataclass fields
        field_names = {field.name for field in fields(cls)}
        filtered_data = {key: series[CCB_DECISION_FIELD_MAPPING[key]]
                         for key in field_names if CCB_DECISION_FIELD_MAPPING[key] in series}

        # update decsisions with enum value
        filtered_data['decision'] = DECISION_MAPPING[filtered_data['decision']]

        # add modified item
        filtered_data['modified_item'] = ModifiedItem.from_series(
            series=series)
        return cls(**filtered_data)
