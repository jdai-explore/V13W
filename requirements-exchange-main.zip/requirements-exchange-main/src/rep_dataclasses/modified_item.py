from dataclasses import dataclass, fields
import pandas as pd


MODIFIED_ITEM_FIELD_MAPPING = {
    'tracker_id_ch63': 'CH63-TrackerID',
    'tracker_name_ch63': 'CH63-TrackerName',
    'tracker_baseline_ch63': 'CH63-Baseline',
    'item_id_ch63': 'CH63-ItemId',
    'item_name_ch63': 'CH63-ItemName',
    'field_id_ch63': 'CH63-FieldID',
    'field_name_ch63': 'CH63-FieldName',
    'field_value_ch63': 'CH63-FieldValue',
    'tracker_id_sv62': 'SV62-TrackerID',
    'tracker_name_sv62': 'SV62-TrackerName',
    'tracker_baseline_sv62': 'SV62-Baseline',
    'item_id_sv62': 'SV62-ItemId',
    'item_name_sv62': 'SV62-ItemName',
    'field_id_sv62': 'SV62-FieldID',
    'field_name_sv62': 'SV62-FieldName',
    'field_value_sv62': 'SV62-FieldValue'
}


@dataclass
class ModifiedItem:
    tracker_id_ch63: str
    tracker_name_ch63: str
    tracker_baseline_ch63: str
    item_id_ch63: str
    item_name_ch63: str
    field_id_ch63: str
    field_name_ch63: str
    field_value_ch63: str
    tracker_id_sv62: str
    tracker_name_sv62: str
    tracker_baseline_sv62: str
    item_id_sv62: str
    item_name_sv62: str
    field_id_sv62: str
    field_name_sv62: str
    field_value_sv62: str

    @classmethod
    def from_series(cls, series: pd.Series):
        """
        Creates an instance of the dataclass from a pandas Series.

        Parameters:
        - series (pd.Series): The Series containing the data.

        Returns:
        - An instance of the dataclass.
        """
        # Create a dictionary of values by matching Series index to dataclass fields
        field_names = {field.name for field in fields(cls)}
        filtered_data = {key: series[MODIFIED_ITEM_FIELD_MAPPING[key]]
                         for key in field_names if MODIFIED_ITEM_FIELD_MAPPING[key] in series}
        return cls(**filtered_data)
